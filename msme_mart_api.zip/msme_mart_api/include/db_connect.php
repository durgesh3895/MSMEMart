<?php
$databaseHost = '127.0.0.1';
$databaseName = 'u920553048_masIs';
$databaseUsername = 'u920553048_Nckd8';
$databasePassword = 'ulcZrEDNe8';
 
try {
    $con = new PDO("mysql:host={$databaseHost};dbname={$databaseName}", $databaseUsername, $databasePassword);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} 
catch(PDOException $e) {
  echo $e->getMessage();
}
 
?>