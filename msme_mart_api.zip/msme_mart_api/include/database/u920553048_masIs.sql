-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 04, 2022 at 05:51 AM
-- Server version: 10.5.12-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u920553048_masIs`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`id`, `user_id`, `product_id`, `status`, `created_at`) VALUES
(1, 1, 1, 0, '2022-07-04 04:41:51'),
(2, 1, 41, 0, '2022-07-04 04:41:51'),
(3, 1, 40, 0, '2022-07-04 04:41:51'),
(4, 1, 14, 0, '2022-07-04 04:41:51'),
(5, 10, 14, 1, '2022-07-04 05:18:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `c_image` varchar(20) NOT NULL,
  `c_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `c_name`, `c_image`, `c_status`, `created_at`) VALUES
(1, 'Handicrafts', '1.jpg', 1, '2022-07-02 06:40:22'),
(2, 'Wooden Craft', '2.jpg', 1, '2022-07-02 06:40:30'),
(3, 'Pottery', '3.jpg', 1, '2022-07-02 06:40:36'),
(4, 'Metal Craft', '4.jpg', 1, '2022-07-02 06:40:42'),
(5, 'Glashware', '5.jpg', 1, '2022-07-02 06:40:49'),
(6, 'Fragrance', '6.jpg', 1, '2022-07-02 06:40:55'),
(7, 'Home Decor', '7.jpg', 1, '2022-07-02 06:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_desc` longtext NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_image` varchar(10) NOT NULL,
  `product_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `product_name`, `product_desc`, `product_price`, `product_quantity`, `product_image`, `product_status`, `created_at`) VALUES
(1, '3-in-1 Ganesha Black Pottery Vase', '3-in-1 Ganesha Black Pottery Vase', 4999, 1, '1.jpg', 1, '2022-06-30 04:18:26'),
(2, 'Donga 1 Kg', 'Donga 1 Kg', 159, 5, '2.jpg', 1, '2022-06-30 04:20:20'),
(3, 'Jug', 'Jug', 299, 5, '3.jpg', 1, '2022-06-30 04:23:39'),
(4, 'Water Bottle 0.5 Ltr', 'Water Bottle 0.5 Ltr', 199, 5, '4.jpg', 1, '2022-06-30 04:22:36'),
(5, 'Mandir Diya', 'Mandir Diya', 59, 10, '5.jpg', 1, '2022-06-30 04:23:32'),
(6, 'Hanumanji Terracotta Murti', 'Hanumanji Terracotta Murti', 99, 15, '6.jpg', 1, '2022-06-30 04:24:06'),
(7, 'Table Lamp', 'Table Lamp', 499, 5, '7.jpg', 1, '2022-06-30 04:24:36'),
(8, 'Flower Vase 12 Inches', 'Flower Vase 12 Inches', 399, 10, '8.jpg', 1, '2022-06-30 04:25:06'),
(9, 'Fish Black Pottery Lamp', 'Fish Black Pottery Lamp', 2999, 2, '9.jpg', 1, '2022-06-30 04:25:46'),
(10, 'Almond Oil 30 ml ', 'Almond Oil 30 ml \r\n', 529, 2, '10.jp', 1, '2022-07-02 17:17:17'),
(11, 'Jojoba Oil 30 ml', 'Jojoba Oil 30 ml\r\n', 529, 2, '11.jpg', 1, '2022-07-02 17:17:10'),
(12, 'Hazel Nut Oil 30 ml', 'Hazel Nut Oil 30 ml\r\n', 529, 2, '12.jpg', 1, '2022-07-02 17:17:06'),
(13, 'Apricot Oil 30 ml', 'Apricot Oil 30 ml\r\n', 499, 2, '13.jpg', 1, '2022-07-02 17:17:02'),
(14, 'Argan Oil 30 ml', 'Argan Oil 30 ml\r\n', 499, 2, '14.jpg', 1, '2022-07-02 17:16:59'),
(15, 'Pumpkin Oil 30 ml', 'Pumpkin Oil 30 ml\r\n', 499, 2, '15.jpg', 1, '2022-07-02 17:16:55'),
(16, 'Basil Essential Oil 10 ml', 'Basil Essential Oil 10 ml\r\n', 299, 3, '16.jpg', 1, '2022-07-02 17:16:50'),
(17, 'Lavender Essential Oil 10 ml', 'Lavender Essential Oil 10 ml\r\n', 299, 3, '17.jpg', 1, '2022-07-02 17:16:46'),
(18, 'Lemongrass Essential Oil 10 ml', 'Lemongrass Essential Oil 10 ml\r\n', 299, 3, '18.jpg', 1, '2022-07-02 17:16:42'),
(19, 'Rose Essential Oil 10 ml', 'Rose Essential Oil 10 ml\r\n', 299, 3, '19.jpg', 1, '2022-07-02 17:16:38'),
(20, 'Rosemary Essential Oil 10 ml', 'Rosemary Essential Oil 10 ml\r\n', 299, 3, '20.jpg', 1, '2022-07-02 17:16:34'),
(21, 'Cedarwood Essential Oil 10 ml', 'Cedarwood Essential Oil 10 ml\r\n', 299, 3, '21.jpg', 1, '2022-07-02 17:16:30'),
(22, 'Eucalytptus Essential Oil 10 ml', 'Eucalytptus Essential Oil 10 ml\r\n', 299, 3, '22.jpg', 1, '2022-07-02 17:16:26'),
(23, 'Franincense Essential Oil 10 ml', 'Franincense Essential Oil 10 ml\r\n', 299, 3, '23.jpg', 1, '2022-07-02 17:16:22'),
(24, 'Geranium Essential Oil 10 ml', 'Geranium Essential Oil 10 ml\r\n', 299, 2, '24.jpg', 1, '2022-07-02 17:16:18'),
(25, 'Green Bottled Attar 5 ml', 'Green Bottled Attar 5 ml\r\n', 499, 1, '25.jpg', 1, '2022-07-02 17:16:15'),
(26, 'Brown Bottled Attar 5 ml', 'Brown Bottled Attar 5 ml\r\n', 499, 1, '26.jpg', 1, '2022-07-02 17:16:11'),
(27, 'Harsingar Attar 5 ml', 'Harsingar Attar 5 ml\r\n', 599, 3, '27.jpg', 1, '2022-07-02 17:16:07'),
(28, 'Henna Attar 5 ml', 'Henna Attar 5 ml\r\n', 599, 3, '28.jgp', 1, '2022-07-02 17:16:03'),
(29, 'Kewra Attar 5 ml', 'Kewra Attar 5 ml\r\n', 599, 2, '29.jpg', 1, '2022-07-02 17:15:59'),
(30, 'Mehndi Attar 5 ml', 'Mehndi Attar 5 ml\r\n', 599, 2, '30.jpg', 1, '2022-07-02 17:15:53'),
(31, 'Mitti Attar 5 ml', 'Mitti Attar 5 ml\r\n', 599, 3, '31.jpf', 1, '2022-07-02 17:15:49'),
(32, 'Mogra Attar 5 ml', 'Mogra Attar 5 ml\r\n', 599, 3, '32.jpg', 1, '2022-07-02 17:15:45'),
(33, 'Motiya Attar 5 ml', 'Motiya Attar 5 ml\r\n', 599, 3, '33.jpg', 1, '2022-07-02 17:15:41'),
(34, 'Sandalwood Attar 5 ml', 'Sandalwood Attar 5 ml\r\n', 599, 3, '34.jpg', 1, '2022-07-02 17:15:37'),
(35, 'Shamama Attar 5 ml', 'Shamama Attar 5 ml\r\n', 599, 3, '35.jpg', 1, '2022-07-02 17:15:33'),
(36, 'Bela Attar 5 ml', 'Bela Attar 5 ml\r\n', 599, 5, '36.jpg', 1, '2022-07-02 17:15:29'),
(37, 'Rose Attar 5 ml', 'Rose Attar 5 ml\r\n', 599, 3, '37.jpg', 1, '2022-07-02 17:15:25'),
(38, 'Millions Attar 10 ml', 'Millions Attar 10 ml\r\n', 499, 2, '38.jpg', 1, '2022-07-02 17:15:21'),
(39, 'Internity Attar 12 ml', 'Internity Attar 12 ml\r\n', 499, 2, '39.jpg', 1, '2022-07-02 17:15:16'),
(40, 'Attar in Black Case 10 ml', 'Attar in Black Case 10 ml\r\n', 499, 12, '40.jpg', 1, '2022-07-02 17:15:12'),
(41, 'Attar in Red Case 10 ml', 'Attar in Red Case 10 ml\r\n', 499, 2, '41.jpg', 1, '2022-07-02 17:15:08'),
(42, 'Car Fragrance 10 ml', 'Car Fragrance 10 ml\r\n', 299, 10, '42.jpg', 1, '2022-07-02 17:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `password` varchar(100) NOT NULL,
  `district` varchar(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `first_name`, `last_name`, `mobile`, `password`, `district`, `address`, `role`, `status`, `created_at`) VALUES
(1, 'Durgesh', 'Chaudhary', '9554817161', '0e7517141fb53f21ee439b355b5a1d0a', 'Siddharthnagar', '7th Floor, summit building, Gomti Nagar, Lucknow, Uttar Pradesh 226001', 'Admin', 1, '2022-07-04 05:31:07'),
(2, 'Rahul', 'Chaudhary', '7007381844', 'b12a43efea07a05e85e826d5299166fe', 'Siddharthnagar', 'Village- Niyanw Post Shohratgarh, District Siddharthnagr Uttar Pradesg-272205', 'User', 1, '2022-06-22 10:50:55'),
(5, 'Rijo', 'Mathew', '9005032644', '2d02e02c922db2efacad73774fe9acf1', 'Lucknow', '7th Floor, summit building, Gomti Nagar, Lucknow, Uttar Pradesh 226001', 'Admin', 1, '2022-07-02 12:07:01'),
(6, 'Ahmad', 'Dan', '9044956669', 'e4ad6430e548d8609e9ac1d617c14579', 'Ambedkar Nagar', '7th Floor, summit building, Gomti Nagar, Lucknow, Uttar Pradesh 226001', 'User', 1, '2022-07-02 12:07:12'),
(7, 'Amit', 'Gupta', '6390005456', '93373bdb9c4755b2faf8a801e0aed9f7', 'Lucknow', 'Rajajipuram', 'User', 1, '2022-07-02 12:09:17'),
(8, 'Chandan', 'Rai', '8090270208', '0e7517141fb53f21ee439b355b5a1d0a', 'Lucknow', 'Engineering College Lucknow', 'User', 1, '2022-07-04 05:29:50'),
(9, 'Durgesh', 'Chaudhary', '1234567890', '703dadfc6e5ce7a2eea402fe584c7842', 'Lucknow', 'Polytechnic chauraha', 'User', 1, '2022-07-04 05:08:59'),
(10, 'Chandu', 'Rai', '1122334455', '0e7517141fb53f21ee439b355b5a1d0a', 'Lucknow', 'Gomti nagar Lucknow', 'User', 1, '2022-07-04 05:17:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wishlist`
--

CREATE TABLE `tbl_wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_wishlist`
--

INSERT INTO `tbl_wishlist` (`id`, `user_id`, `product_id`) VALUES
(2, 1, 8),
(3, 1, 5),
(5, 1, 3),
(8, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_actions`
--

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_actions`
--

INSERT INTO `wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(11, 'wpforms_admin_addons_cache_update', 'complete', '2022-06-03 04:41:59', '2022-06-03 04:41:59', '{\"tasks_meta_id\":2}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654231319;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654231319;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-03 04:51:19', '2022-06-03 04:51:19', 0, NULL),
(12, 'wpforms_admin_builder_templates_cache_update', 'complete', '2022-06-03 04:41:59', '2022-06-03 04:41:59', '{\"tasks_meta_id\":3}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654231319;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654231319;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-03 04:51:19', '2022-06-03 04:51:19', 0, NULL),
(13, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2022-06-03 04:42:01', '2022-06-03 04:42:01', '{\"tasks_meta_id\":null}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654231321;s:18:\"\0*\0first_timestamp\";i:1653495311;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654231321;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-03 04:51:19', '2022-06-03 04:51:19', 0, NULL),
(351, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-03 07:40:20', '2022-06-03 07:40:20', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654242020;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654242020;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-03 07:49:48', '2022-06-03 07:49:48', 0, NULL),
(409, 'wpforms_admin_addons_cache_update', 'complete', '2022-06-10 04:51:19', '2022-06-10 04:51:19', '{\"tasks_meta_id\":2}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654836679;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654836679;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-10 04:52:23', '2022-06-10 04:52:23', 0, NULL),
(410, 'wpforms_admin_builder_templates_cache_update', 'complete', '2022-06-10 04:51:19', '2022-06-10 04:51:19', '{\"tasks_meta_id\":3}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654836679;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654836679;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-10 04:52:23', '2022-06-10 04:52:23', 0, NULL),
(411, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2022-06-10 04:51:19', '2022-06-10 04:51:19', '{\"tasks_meta_id\":null}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654836679;s:18:\"\0*\0first_timestamp\";i:1653495311;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654836679;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-10 04:52:23', '2022-06-10 04:52:23', 0, NULL),
(422, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-04 07:49:48', '2022-06-04 07:49:48', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654328988;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654328988;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-04 08:36:55', '2022-06-04 08:36:55', 0, NULL),
(489, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-05 08:36:55', '2022-06-05 08:36:55', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654418215;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654418215;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-05 08:46:19', '2022-06-05 08:46:19', 0, NULL),
(561, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-06 08:46:19', '2022-06-06 08:46:19', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654505179;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654505179;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-06 08:56:12', '2022-06-06 08:56:12', 0, NULL),
(599, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-07 08:56:12', '2022-06-07 08:56:12', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654592172;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654592172;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-07 08:56:53', '2022-06-07 08:56:53', 0, NULL),
(626, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-08 08:56:53', '2022-06-08 08:56:53', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654678613;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654678613;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-08 08:57:18', '2022-06-08 08:57:18', 0, NULL),
(691, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-09 08:57:18', '2022-06-09 08:57:18', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654765038;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654765038;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-09 09:30:12', '2022-06-09 09:30:12', 0, NULL),
(754, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-10 09:30:12', '2022-06-10 09:30:12', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654853412;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654853412;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-10 09:41:13', '2022-06-10 09:41:13', 0, NULL),
(791, 'wpforms_admin_addons_cache_update', 'complete', '2022-06-17 04:52:23', '2022-06-17 04:52:23', '{\"tasks_meta_id\":2}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655441543;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655441543;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-17 05:08:20', '2022-06-17 05:08:20', 0, NULL),
(792, 'wpforms_admin_builder_templates_cache_update', 'complete', '2022-06-17 04:52:23', '2022-06-17 04:52:23', '{\"tasks_meta_id\":3}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655441543;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655441543;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-17 05:08:20', '2022-06-17 05:08:20', 0, NULL),
(793, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2022-06-17 04:52:23', '2022-06-17 04:52:23', '{\"tasks_meta_id\":null}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655441543;s:18:\"\0*\0first_timestamp\";i:1653495311;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655441543;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-17 05:08:20', '2022-06-17 05:08:20', 0, NULL),
(808, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-11 09:41:13', '2022-06-11 09:41:13', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1654940473;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1654940473;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-11 09:44:24', '2022-06-11 09:44:24', 0, NULL),
(880, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-12 09:44:24', '2022-06-12 09:44:24', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655027064;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655027064;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-12 09:55:35', '2022-06-12 09:55:35', 0, NULL),
(919, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-13 09:55:35', '2022-06-13 09:55:35', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655114135;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655114135;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-13 10:25:49', '2022-06-13 10:25:49', 0, NULL),
(966, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-14 10:25:49', '2022-06-14 10:25:49', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655202349;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655202349;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-14 10:26:02', '2022-06-14 10:26:02', 0, NULL),
(1045, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-15 10:26:02', '2022-06-15 10:26:02', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655288762;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655288762;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-15 10:26:55', '2022-06-15 10:26:55', 0, NULL),
(1104, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-16 10:26:55', '2022-06-16 10:26:55', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655375215;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655375215;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-16 15:52:13', '2022-06-16 15:52:13', 0, NULL),
(1113, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-17 15:52:13', '2022-06-17 15:52:13', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655481133;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655481133;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-17 15:53:01', '2022-06-17 15:53:01', 0, NULL),
(1117, 'wpforms_admin_addons_cache_update', 'complete', '2022-06-24 05:08:20', '2022-06-24 05:08:20', '{\"tasks_meta_id\":2}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656047300;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656047300;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-24 11:53:23', '2022-06-24 11:53:23', 0, NULL),
(1118, 'wpforms_admin_builder_templates_cache_update', 'complete', '2022-06-24 05:08:20', '2022-06-24 05:08:20', '{\"tasks_meta_id\":3}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656047300;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656047300;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-24 11:53:23', '2022-06-24 11:53:23', 0, NULL),
(1119, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2022-06-24 05:08:20', '2022-06-24 05:08:20', '{\"tasks_meta_id\":null}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656047300;s:18:\"\0*\0first_timestamp\";i:1653495311;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656047300;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-06-24 11:53:24', '2022-06-24 11:53:24', 0, NULL),
(1139, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-18 15:53:01', '2022-06-18 15:53:01', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655567581;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655567581;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-18 17:23:13', '2022-06-18 17:23:13', 0, NULL),
(1183, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-19 17:23:13', '2022-06-19 17:23:13', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655659393;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655659393;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-19 17:42:56', '2022-06-19 17:42:56', 0, NULL),
(1190, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-20 17:42:56', '2022-06-20 17:42:56', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655746976;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655746976;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-20 19:38:29', '2022-06-20 19:38:29', 0, NULL),
(1234, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-21 19:38:29', '2022-06-21 19:38:29', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655840309;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655840309;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-21 20:45:11', '2022-06-21 20:45:11', 0, NULL),
(1305, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-22 20:45:11', '2022-06-22 20:45:11', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1655930711;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1655930711;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-22 20:45:40', '2022-06-22 20:45:40', 0, NULL),
(1341, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-23 20:45:40', '2022-06-23 20:45:40', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656017140;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656017140;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-23 22:19:53', '2022-06-23 22:19:53', 0, NULL),
(1366, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-24 22:19:53', '2022-06-24 22:19:53', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656109193;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656109193;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-25 11:51:06', '2022-06-25 11:51:06', 0, NULL),
(1370, 'wpforms_admin_addons_cache_update', 'complete', '2022-07-01 11:53:23', '2022-07-01 11:53:23', '{\"tasks_meta_id\":2}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656676403;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656676403;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-07-01 11:54:35', '2022-07-01 11:54:35', 0, NULL),
(1371, 'wpforms_admin_builder_templates_cache_update', 'complete', '2022-07-01 11:53:23', '2022-07-01 11:53:23', '{\"tasks_meta_id\":3}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656676403;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656676403;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-07-01 11:54:35', '2022-07-01 11:54:35', 0, NULL),
(1372, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2022-07-01 11:53:24', '2022-07-01 11:53:24', '{\"tasks_meta_id\":null}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656676404;s:18:\"\0*\0first_timestamp\";i:1653495311;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656676404;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 1, '2022-07-01 11:54:35', '2022-07-01 11:54:35', 0, NULL),
(1375, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-26 11:51:06', '2022-06-26 11:51:06', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656244266;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656244266;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-26 12:04:27', '2022-06-26 12:04:27', 0, NULL),
(1429, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-27 12:04:27', '2022-06-27 12:04:27', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656331467;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656331467;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-27 12:13:21', '2022-06-27 12:13:21', 0, NULL),
(1479, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-28 12:13:21', '2022-06-28 12:13:21', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656418401;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656418401;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-28 14:39:03', '2022-06-28 14:39:03', 0, NULL),
(1487, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-29 14:39:03', '2022-06-29 14:39:03', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656513543;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656513543;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-29 16:23:11', '2022-06-29 16:23:11', 0, NULL),
(1494, 'wpforms_process_forms_locator_scan', 'complete', '2022-06-30 16:23:11', '2022-06-30 16:23:11', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656606191;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656606191;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-06-30 18:37:05', '2022-06-30 18:37:05', 0, NULL),
(1501, 'wpforms_process_forms_locator_scan', 'complete', '2022-07-01 18:37:05', '2022-07-01 18:37:05', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656700625;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656700625;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-07-01 18:39:27', '2022-07-01 18:39:27', 0, NULL),
(1519, 'wpforms_admin_addons_cache_update', 'pending', '2022-07-08 11:54:35', '2022-07-08 11:54:35', '{\"tasks_meta_id\":2}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1657281275;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1657281275;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(1520, 'wpforms_admin_builder_templates_cache_update', 'pending', '2022-07-08 11:54:35', '2022-07-08 11:54:35', '{\"tasks_meta_id\":3}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1657281275;s:18:\"\0*\0first_timestamp\";i:1654231319;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1657281275;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(1521, 'wpforms_email_summaries_fetch_info_blocks', 'pending', '2022-07-08 11:54:35', '2022-07-08 11:54:35', '{\"tasks_meta_id\":null}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1657281275;s:18:\"\0*\0first_timestamp\";i:1653495311;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1657281275;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(1535, 'aioseo_cache_prune', 'complete', '2022-07-02 18:39:27', '2022-07-02 18:39:27', '[]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656787167;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656787167;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 1, 1, '2022-07-02 18:44:24', '2022-07-02 18:44:24', 0, NULL),
(1536, 'wpforms_process_forms_locator_scan', 'complete', '2022-07-02 18:39:27', '2022-07-02 18:39:27', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656787167;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656787167;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-07-02 18:44:24', '2022-07-02 18:44:24', 0, NULL),
(1555, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 04:51:06', '2022-07-02 04:51:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656737466;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656737466;}', 1, 1, '2022-07-02 05:09:22', '2022-07-02 05:09:22', 0, NULL),
(1556, 'aioseo_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 1, 1, '2022-07-02 04:36:17', '2022-07-02 04:36:17', 0, NULL),
(1557, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 05:24:22', '2022-07-02 05:24:22', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656739462;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656739462;}', 1, 1, '2022-07-02 05:32:04', '2022-07-02 05:32:04', 0, NULL),
(1558, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 05:47:04', '2022-07-02 05:47:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656740824;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656740824;}', 1, 1, '2022-07-02 06:05:13', '2022-07-02 06:05:13', 0, NULL),
(1559, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 06:20:13', '2022-07-02 06:20:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656742813;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656742813;}', 1, 1, '2022-07-02 06:27:33', '2022-07-02 06:27:33', 0, NULL),
(1560, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 06:42:33', '2022-07-02 06:42:33', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656744153;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656744153;}', 1, 1, '2022-07-02 06:49:13', '2022-07-02 06:49:13', 0, NULL),
(1561, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 07:04:13', '2022-07-02 07:04:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656745453;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656745453;}', 1, 1, '2022-07-02 07:11:13', '2022-07-02 07:11:13', 0, NULL),
(1562, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 07:26:13', '2022-07-02 07:26:13', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656746773;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656746773;}', 1, 1, '2022-07-02 07:33:16', '2022-07-02 07:33:16', 0, NULL),
(1563, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 07:48:16', '2022-07-02 07:48:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656748096;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656748096;}', 1, 1, '2022-07-02 07:55:04', '2022-07-02 07:55:04', 0, NULL),
(1564, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 08:10:04', '2022-07-02 08:10:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656749404;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656749404;}', 1, 1, '2022-07-02 08:17:14', '2022-07-02 08:17:14', 0, NULL),
(1565, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 08:32:14', '2022-07-02 08:32:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656750734;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656750734;}', 1, 1, '2022-07-02 08:38:59', '2022-07-02 08:38:59', 0, NULL),
(1566, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 08:53:59', '2022-07-02 08:53:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656752039;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656752039;}', 1, 1, '2022-07-02 09:00:46', '2022-07-02 09:00:46', 0, NULL),
(1567, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 09:15:46', '2022-07-02 09:15:46', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656753346;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656753346;}', 1, 1, '2022-07-02 09:22:39', '2022-07-02 09:22:39', 0, NULL),
(1568, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 09:37:39', '2022-07-02 09:37:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656754659;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656754659;}', 1, 1, '2022-07-02 09:44:31', '2022-07-02 09:44:31', 0, NULL),
(1569, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 09:59:31', '2022-07-02 09:59:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656755971;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656755971;}', 1, 1, '2022-07-02 10:38:57', '2022-07-02 10:38:57', 0, NULL),
(1570, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 10:53:57', '2022-07-02 10:53:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656759237;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656759237;}', 1, 1, '2022-07-02 11:00:37', '2022-07-02 11:00:37', 0, NULL),
(1571, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 11:15:37', '2022-07-02 11:15:37', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656760537;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656760537;}', 1, 1, '2022-07-02 11:22:32', '2022-07-02 11:22:32', 0, NULL),
(1572, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 11:37:32', '2022-07-02 11:37:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656761852;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656761852;}', 1, 1, '2022-07-02 11:44:15', '2022-07-02 11:44:15', 0, NULL),
(1573, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 11:59:15', '2022-07-02 11:59:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656763155;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656763155;}', 1, 1, '2022-07-02 14:05:19', '2022-07-02 14:05:19', 0, NULL),
(1574, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 14:20:19', '2022-07-02 14:20:19', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656771619;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656771619;}', 1, 1, '2022-07-02 14:26:45', '2022-07-02 14:26:45', 0, NULL),
(1575, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 14:41:45', '2022-07-02 14:41:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656772905;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656772905;}', 1, 1, '2022-07-02 14:48:39', '2022-07-02 14:48:39', 0, NULL),
(1576, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 15:03:39', '2022-07-02 15:03:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656774219;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656774219;}', 1, 1, '2022-07-02 15:10:44', '2022-07-02 15:10:44', 0, NULL),
(1577, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 15:25:44', '2022-07-02 15:25:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656775544;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656775544;}', 1, 1, '2022-07-02 15:32:34', '2022-07-02 15:32:34', 0, NULL),
(1578, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 15:47:34', '2022-07-02 15:47:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656776854;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656776854;}', 1, 1, '2022-07-02 15:54:29', '2022-07-02 15:54:29', 0, NULL),
(1579, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 16:09:29', '2022-07-02 16:09:29', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656778169;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656778169;}', 1, 1, '2022-07-02 16:27:32', '2022-07-02 16:27:32', 0, NULL),
(1580, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 16:42:32', '2022-07-02 16:42:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656780152;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656780152;}', 1, 1, '2022-07-02 16:49:08', '2022-07-02 16:49:08', 0, NULL),
(1581, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 17:04:08', '2022-07-02 17:04:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656781448;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656781448;}', 1, 1, '2022-07-02 17:08:27', '2022-07-02 17:08:27', 0, NULL),
(1582, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 17:23:27', '2022-07-02 17:23:27', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656782607;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656782607;}', 1, 1, '2022-07-02 17:32:58', '2022-07-02 17:32:58', 0, NULL),
(1583, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 17:47:58', '2022-07-02 17:47:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656784078;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656784078;}', 1, 1, '2022-07-02 18:06:08', '2022-07-02 18:06:08', 0, NULL),
(1584, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 18:21:08', '2022-07-02 18:21:08', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656786068;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656786068;}', 1, 1, '2022-07-02 18:28:02', '2022-07-02 18:28:02', 0, NULL),
(1585, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 18:43:02', '2022-07-02 18:43:02', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656787382;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656787382;}', 1, 1, '2022-07-02 18:44:24', '2022-07-02 18:44:24', 0, NULL),
(1586, 'aioseo_cache_prune', 'complete', '2022-07-03 18:44:24', '2022-07-03 18:44:24', '[]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656873864;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656873864;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 1, 1, '2022-07-03 18:46:37', '2022-07-03 18:46:37', 0, NULL),
(1587, 'wpforms_process_forms_locator_scan', 'complete', '2022-07-03 18:44:24', '2022-07-03 18:44:24', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656873864;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656873864;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 1, '2022-07-03 18:46:37', '2022-07-03 18:46:37', 0, NULL),
(1588, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 18:59:24', '2022-07-02 18:59:24', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656788364;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656788364;}', 1, 1, '2022-07-02 19:00:50', '2022-07-02 19:00:50', 0, NULL),
(1589, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 19:15:50', '2022-07-02 19:15:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656789350;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656789350;}', 1, 1, '2022-07-02 19:22:55', '2022-07-02 19:22:55', 0, NULL),
(1590, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 19:37:55', '2022-07-02 19:37:55', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656790675;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656790675;}', 1, 1, '2022-07-02 19:44:50', '2022-07-02 19:44:50', 0, NULL),
(1591, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 19:59:50', '2022-07-02 19:59:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656791990;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656791990;}', 1, 1, '2022-07-02 20:18:00', '2022-07-02 20:18:00', 0, NULL),
(1592, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 20:33:00', '2022-07-02 20:33:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656793980;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656793980;}', 1, 1, '2022-07-02 20:40:03', '2022-07-02 20:40:03', 0, NULL),
(1593, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 20:55:03', '2022-07-02 20:55:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656795303;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656795303;}', 1, 1, '2022-07-02 21:02:16', '2022-07-02 21:02:16', 0, NULL),
(1594, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 21:17:16', '2022-07-02 21:17:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656796636;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656796636;}', 1, 1, '2022-07-02 21:24:30', '2022-07-02 21:24:30', 0, NULL),
(1595, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 21:39:30', '2022-07-02 21:39:30', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656797970;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656797970;}', 1, 1, '2022-07-02 21:46:42', '2022-07-02 21:46:42', 0, NULL),
(1596, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 22:01:42', '2022-07-02 22:01:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656799302;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656799302;}', 1, 1, '2022-07-02 22:08:40', '2022-07-02 22:08:40', 0, NULL),
(1597, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 22:23:40', '2022-07-02 22:23:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656800620;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656800620;}', 1, 1, '2022-07-02 22:30:44', '2022-07-02 22:30:44', 0, NULL),
(1598, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 22:45:44', '2022-07-02 22:45:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656801944;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656801944;}', 1, 1, '2022-07-02 22:52:53', '2022-07-02 22:52:53', 0, NULL),
(1599, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 23:07:53', '2022-07-02 23:07:53', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656803273;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656803273;}', 1, 1, '2022-07-02 23:12:45', '2022-07-02 23:12:45', 0, NULL),
(1600, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 23:27:45', '2022-07-02 23:27:45', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656804465;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656804465;}', 1, 1, '2022-07-02 23:31:31', '2022-07-02 23:31:31', 0, NULL),
(1601, 'aioseo_image_sitemap_scan', 'complete', '2022-07-02 23:46:31', '2022-07-02 23:46:31', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656805591;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656805591;}', 1, 1, '2022-07-02 23:48:11', '2022-07-02 23:48:11', 0, NULL),
(1602, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 00:03:11', '2022-07-03 00:03:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656806591;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656806591;}', 1, 1, '2022-07-03 00:10:16', '2022-07-03 00:10:16', 0, NULL),
(1603, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 00:25:16', '2022-07-03 00:25:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656807916;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656807916;}', 1, 1, '2022-07-03 00:32:21', '2022-07-03 00:32:21', 0, NULL),
(1604, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 00:47:20', '2022-07-03 00:47:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656809240;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656809240;}', 1, 1, '2022-07-03 01:04:34', '2022-07-03 01:04:34', 0, NULL),
(1605, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 01:19:34', '2022-07-03 01:19:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656811174;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656811174;}', 1, 1, '2022-07-03 01:27:56', '2022-07-03 01:27:56', 0, NULL),
(1606, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 01:42:56', '2022-07-03 01:42:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656812576;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656812576;}', 1, 1, '2022-07-03 01:46:11', '2022-07-03 01:46:11', 0, NULL),
(1607, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 02:01:11', '2022-07-03 02:01:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656813671;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656813671;}', 1, 1, '2022-07-03 02:01:32', '2022-07-03 02:01:32', 0, NULL),
(1608, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 02:16:32', '2022-07-03 02:16:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656814592;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656814592;}', 1, 1, '2022-07-03 02:18:35', '2022-07-03 02:18:35', 0, NULL),
(1609, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 02:33:35', '2022-07-03 02:33:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656815615;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656815615;}', 1, 1, '2022-07-03 02:35:20', '2022-07-03 02:35:20', 0, NULL),
(1610, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 02:50:20', '2022-07-03 02:50:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656816620;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656816620;}', 1, 1, '2022-07-03 02:57:59', '2022-07-03 02:57:59', 0, NULL),
(1611, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 03:12:59', '2022-07-03 03:12:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656817979;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656817979;}', 1, 1, '2022-07-03 03:14:50', '2022-07-03 03:14:50', 0, NULL),
(1612, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 03:29:50', '2022-07-03 03:29:50', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656818990;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656818990;}', 1, 1, '2022-07-03 03:46:06', '2022-07-03 03:46:06', 0, NULL),
(1613, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 04:01:06', '2022-07-03 04:01:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656820866;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656820866;}', 1, 1, '2022-07-03 04:09:35', '2022-07-03 04:09:35', 0, NULL),
(1614, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 04:24:35', '2022-07-03 04:24:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656822275;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656822275;}', 1, 1, '2022-07-03 04:38:28', '2022-07-03 04:38:28', 0, NULL),
(1615, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 04:53:28', '2022-07-03 04:53:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656824008;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656824008;}', 1, 1, '2022-07-03 05:05:00', '2022-07-03 05:05:00', 0, NULL),
(1616, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 05:20:00', '2022-07-03 05:20:00', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656825600;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656825600;}', 1, 1, '2022-07-03 05:32:56', '2022-07-03 05:32:56', 0, NULL),
(1617, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 05:47:56', '2022-07-03 05:47:56', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656827276;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656827276;}', 1, 1, '2022-07-03 05:48:48', '2022-07-03 05:48:48', 0, NULL),
(1618, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 06:03:48', '2022-07-03 06:03:48', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656828228;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656828228;}', 1, 1, '2022-07-03 06:10:58', '2022-07-03 06:10:58', 0, NULL),
(1619, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 06:25:58', '2022-07-03 06:25:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656829558;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656829558;}', 1, 1, '2022-07-03 06:31:14', '2022-07-03 06:31:14', 0, NULL),
(1620, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 06:46:14', '2022-07-03 06:46:14', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656830774;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656830774;}', 1, 1, '2022-07-03 06:47:32', '2022-07-03 06:47:32', 0, NULL),
(1621, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 07:02:32', '2022-07-03 07:02:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656831752;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656831752;}', 1, 1, '2022-07-03 07:07:59', '2022-07-03 07:07:59', 0, NULL),
(1622, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 07:22:59', '2022-07-03 07:22:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656832979;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656832979;}', 1, 1, '2022-07-03 07:23:59', '2022-07-03 07:23:59', 0, NULL),
(1623, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 07:38:59', '2022-07-03 07:38:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656833939;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656833939;}', 1, 1, '2022-07-03 07:52:43', '2022-07-03 07:52:43', 0, NULL),
(1624, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 08:07:43', '2022-07-03 08:07:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656835663;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656835663;}', 1, 1, '2022-07-03 08:15:41', '2022-07-03 08:15:41', 0, NULL),
(1625, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 08:30:41', '2022-07-03 08:30:41', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656837041;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656837041;}', 1, 1, '2022-07-03 08:35:43', '2022-07-03 08:35:43', 0, NULL),
(1626, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 08:50:43', '2022-07-03 08:50:43', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656838243;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656838243;}', 1, 1, '2022-07-03 08:59:42', '2022-07-03 08:59:42', 0, NULL),
(1627, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 09:14:42', '2022-07-03 09:14:42', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656839682;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656839682;}', 1, 1, '2022-07-03 09:21:51', '2022-07-03 09:21:51', 0, NULL),
(1628, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 09:36:51', '2022-07-03 09:36:51', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656841011;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656841011;}', 1, 1, '2022-07-03 09:41:59', '2022-07-03 09:41:59', 0, NULL),
(1629, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 09:56:59', '2022-07-03 09:56:59', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656842219;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656842219;}', 1, 1, '2022-07-03 10:06:17', '2022-07-03 10:06:17', 0, NULL),
(1630, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 10:21:17', '2022-07-03 10:21:17', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656843677;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656843677;}', 1, 1, '2022-07-03 10:28:26', '2022-07-03 10:28:26', 0, NULL),
(1631, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 10:43:26', '2022-07-03 10:43:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656845006;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656845006;}', 1, 1, '2022-07-03 10:43:47', '2022-07-03 10:43:47', 0, NULL),
(1632, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 10:58:47', '2022-07-03 10:58:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656845927;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656845927;}', 1, 1, '2022-07-03 11:01:44', '2022-07-03 11:01:44', 0, NULL);
INSERT INTO `wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(1633, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 11:16:44', '2022-07-03 11:16:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656847004;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656847004;}', 1, 1, '2022-07-03 11:24:04', '2022-07-03 11:24:04', 0, NULL),
(1634, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 11:39:04', '2022-07-03 11:39:04', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656848344;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656848344;}', 1, 1, '2022-07-03 11:46:16', '2022-07-03 11:46:16', 0, NULL),
(1635, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 12:01:16', '2022-07-03 12:01:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656849676;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656849676;}', 1, 1, '2022-07-03 12:08:39', '2022-07-03 12:08:39', 0, NULL),
(1636, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 12:23:39', '2022-07-03 12:23:39', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656851019;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656851019;}', 1, 1, '2022-07-03 12:24:25', '2022-07-03 12:24:25', 0, NULL),
(1637, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 12:39:25', '2022-07-03 12:39:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656851965;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656851965;}', 1, 1, '2022-07-03 12:41:57', '2022-07-03 12:41:57', 0, NULL),
(1638, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 12:56:57', '2022-07-03 12:56:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656853017;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656853017;}', 1, 1, '2022-07-03 13:04:20', '2022-07-03 13:04:20', 0, NULL),
(1639, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 13:19:20', '2022-07-03 13:19:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656854360;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656854360;}', 1, 1, '2022-07-03 13:26:44', '2022-07-03 13:26:44', 0, NULL),
(1640, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 13:41:44', '2022-07-03 13:41:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656855704;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656855704;}', 1, 1, '2022-07-03 13:47:05', '2022-07-03 13:47:05', 0, NULL),
(1641, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 14:02:05', '2022-07-03 14:02:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656856925;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656856925;}', 1, 1, '2022-07-03 14:07:12', '2022-07-03 14:07:12', 0, NULL),
(1642, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 14:22:12', '2022-07-03 14:22:12', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656858132;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656858132;}', 1, 1, '2022-07-03 14:22:47', '2022-07-03 14:22:47', 0, NULL),
(1643, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 14:37:47', '2022-07-03 14:37:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656859067;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656859067;}', 1, 1, '2022-07-03 14:48:02', '2022-07-03 14:48:02', 0, NULL),
(1644, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 15:03:02', '2022-07-03 15:03:02', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656860582;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656860582;}', 1, 1, '2022-07-03 15:11:38', '2022-07-03 15:11:38', 0, NULL),
(1645, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 15:26:38', '2022-07-03 15:26:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656861998;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656861998;}', 1, 1, '2022-07-03 15:37:06', '2022-07-03 15:37:06', 0, NULL),
(1646, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 15:52:06', '2022-07-03 15:52:06', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656863526;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656863526;}', 1, 1, '2022-07-03 16:02:38', '2022-07-03 16:02:38', 0, NULL),
(1647, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 16:17:38', '2022-07-03 16:17:38', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656865058;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656865058;}', 1, 1, '2022-07-03 16:27:57', '2022-07-03 16:27:57', 0, NULL),
(1648, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 16:42:57', '2022-07-03 16:42:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656866577;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656866577;}', 1, 1, '2022-07-03 16:53:16', '2022-07-03 16:53:16', 0, NULL),
(1649, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 17:08:16', '2022-07-03 17:08:16', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656868096;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656868096;}', 1, 1, '2022-07-03 17:31:05', '2022-07-03 17:31:05', 0, NULL),
(1650, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 17:46:05', '2022-07-03 17:46:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656870365;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656870365;}', 1, 1, '2022-07-03 17:56:05', '2022-07-03 17:56:05', 0, NULL),
(1651, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 18:11:05', '2022-07-03 18:11:05', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656871865;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656871865;}', 1, 1, '2022-07-03 18:34:11', '2022-07-03 18:34:11', 0, NULL),
(1652, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 18:49:11', '2022-07-03 18:49:11', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656874151;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656874151;}', 1, 1, '2022-07-03 18:57:15', '2022-07-03 18:57:15', 0, NULL),
(1653, 'aioseo_cache_prune', 'pending', '2022-07-04 18:46:37', '2022-07-04 18:46:37', '[]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656960397;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656960397;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(1654, 'wpforms_process_forms_locator_scan', 'pending', '2022-07-04 18:46:37', '2022-07-04 18:46:37', '{\"tasks_meta_id\":1}', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1656960397;s:18:\"\0*\0first_timestamp\";i:1653626519;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1656960397;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(1655, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 19:12:15', '2022-07-03 19:12:15', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656875535;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656875535;}', 1, 1, '2022-07-03 19:24:44', '2022-07-03 19:24:44', 0, NULL),
(1656, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 19:39:44', '2022-07-03 19:39:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656877184;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656877184;}', 1, 1, '2022-07-03 19:50:18', '2022-07-03 19:50:18', 0, NULL),
(1657, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 20:05:18', '2022-07-03 20:05:18', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656878718;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656878718;}', 1, 1, '2022-07-03 20:41:20', '2022-07-03 20:41:20', 0, NULL),
(1658, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 20:56:20', '2022-07-03 20:56:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656881780;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656881780;}', 1, 1, '2022-07-03 21:06:32', '2022-07-03 21:06:32', 0, NULL),
(1659, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 21:21:32', '2022-07-03 21:21:32', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656883292;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656883292;}', 1, 1, '2022-07-03 21:31:40', '2022-07-03 21:31:40', 0, NULL),
(1660, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 21:46:40', '2022-07-03 21:46:40', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656884800;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656884800;}', 1, 1, '2022-07-03 21:56:48', '2022-07-03 21:56:48', 0, NULL),
(1661, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 22:11:48', '2022-07-03 22:11:48', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656886308;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656886308;}', 1, 1, '2022-07-03 22:21:58', '2022-07-03 22:21:58', 0, NULL),
(1662, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 22:36:58', '2022-07-03 22:36:58', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656887818;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656887818;}', 1, 1, '2022-07-03 22:47:03', '2022-07-03 22:47:03', 0, NULL),
(1663, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 23:02:03', '2022-07-03 23:02:03', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656889323;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656889323;}', 1, 1, '2022-07-03 23:37:20', '2022-07-03 23:37:20', 0, NULL),
(1664, 'aioseo_image_sitemap_scan', 'complete', '2022-07-03 23:52:20', '2022-07-03 23:52:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656892340;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656892340;}', 1, 1, '2022-07-04 00:02:35', '2022-07-04 00:02:35', 0, NULL),
(1665, 'aioseo_image_sitemap_scan', 'complete', '2022-07-04 00:17:35', '2022-07-04 00:17:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656893855;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656893855;}', 1, 1, '2022-07-04 00:27:47', '2022-07-04 00:27:47', 0, NULL),
(1666, 'aioseo_image_sitemap_scan', 'complete', '2022-07-04 00:42:47', '2022-07-04 00:42:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656895367;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656895367;}', 1, 1, '2022-07-04 00:52:44', '2022-07-04 00:52:44', 0, NULL),
(1667, 'aioseo_image_sitemap_scan', 'complete', '2022-07-04 01:07:44', '2022-07-04 01:07:44', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656896864;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656896864;}', 1, 1, '2022-07-04 01:17:35', '2022-07-04 01:17:35', 0, NULL),
(1668, 'aioseo_image_sitemap_scan', 'complete', '2022-07-04 01:32:35', '2022-07-04 01:32:35', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656898355;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656898355;}', 1, 1, '2022-07-04 01:42:34', '2022-07-04 01:42:34', 0, NULL),
(1669, 'aioseo_image_sitemap_scan', 'complete', '2022-07-04 01:57:34', '2022-07-04 01:57:34', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656899854;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656899854;}', 1, 1, '2022-07-04 02:45:20', '2022-07-04 02:45:20', 0, NULL),
(1670, 'aioseo_image_sitemap_scan', 'complete', '2022-07-04 03:00:20', '2022-07-04 03:00:20', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656903620;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656903620;}', 1, 1, '2022-07-04 04:03:37', '2022-07-04 04:03:37', 0, NULL),
(1671, 'aioseo_image_sitemap_scan', 'pending', '2022-07-04 04:18:37', '2022-07-04 04:18:37', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1656908317;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1656908317;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_claims`
--

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) UNSIGNED NOT NULL,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_groups`
--

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_groups`
--

INSERT INTO `wp_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'aioseo'),
(2, 'action-scheduler-migration'),
(3, 'wpforms'),
(4, 'woocommerce-db-updates'),
(5, 'wc-admin-data');

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_logs`
--

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_logs`
--

INSERT INTO `wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(11, 11, 'action created', '2022-05-27 04:41:59', '2022-05-27 04:41:59'),
(12, 12, 'action created', '2022-05-27 04:41:59', '2022-05-27 04:41:59'),
(17, 13, 'action created', '2022-05-27 04:42:01', '2022-05-27 04:42:01'),
(1022, 351, 'action created', '2022-06-02 07:40:20', '2022-06-02 07:40:20'),
(1194, 11, 'action started via WP Cron', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1195, 11, 'action complete via WP Cron', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1196, 409, 'action created', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1197, 12, 'action started via WP Cron', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1198, 12, 'action complete via WP Cron', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1199, 410, 'action created', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1200, 13, 'action started via WP Cron', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1201, 13, 'action complete via WP Cron', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1202, 411, 'action created', '2022-06-03 04:51:19', '2022-06-03 04:51:19'),
(1233, 351, 'action started via WP Cron', '2022-06-03 07:49:48', '2022-06-03 07:49:48'),
(1234, 351, 'action complete via WP Cron', '2022-06-03 07:49:48', '2022-06-03 07:49:48'),
(1235, 422, 'action created', '2022-06-03 07:49:48', '2022-06-03 07:49:48'),
(1434, 422, 'action started via WP Cron', '2022-06-04 08:36:55', '2022-06-04 08:36:55'),
(1435, 422, 'action complete via WP Cron', '2022-06-04 08:36:55', '2022-06-04 08:36:55'),
(1436, 489, 'action created', '2022-06-04 08:36:55', '2022-06-04 08:36:55'),
(1650, 489, 'action started via WP Cron', '2022-06-05 08:46:19', '2022-06-05 08:46:19'),
(1651, 489, 'action complete via WP Cron', '2022-06-05 08:46:19', '2022-06-05 08:46:19'),
(1652, 561, 'action created', '2022-06-05 08:46:19', '2022-06-05 08:46:19'),
(1764, 561, 'action started via WP Cron', '2022-06-06 08:56:12', '2022-06-06 08:56:12'),
(1765, 561, 'action complete via WP Cron', '2022-06-06 08:56:12', '2022-06-06 08:56:12'),
(1766, 599, 'action created', '2022-06-06 08:56:12', '2022-06-06 08:56:12'),
(1845, 599, 'action started via WP Cron', '2022-06-07 08:56:53', '2022-06-07 08:56:53'),
(1846, 599, 'action complete via WP Cron', '2022-06-07 08:56:53', '2022-06-07 08:56:53'),
(1847, 626, 'action created', '2022-06-07 08:56:53', '2022-06-07 08:56:53'),
(2040, 626, 'action started via WP Cron', '2022-06-08 08:57:18', '2022-06-08 08:57:18'),
(2041, 626, 'action complete via WP Cron', '2022-06-08 08:57:18', '2022-06-08 08:57:18'),
(2042, 691, 'action created', '2022-06-08 08:57:18', '2022-06-08 08:57:18'),
(2229, 691, 'action started via WP Cron', '2022-06-09 09:30:12', '2022-06-09 09:30:12'),
(2230, 691, 'action complete via WP Cron', '2022-06-09 09:30:12', '2022-06-09 09:30:12'),
(2231, 754, 'action created', '2022-06-09 09:30:12', '2022-06-09 09:30:12'),
(2340, 409, 'action started via WP Cron', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2341, 409, 'action complete via WP Cron', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2342, 791, 'action created', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2343, 410, 'action started via WP Cron', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2344, 410, 'action complete via WP Cron', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2345, 792, 'action created', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2346, 411, 'action started via WP Cron', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2347, 411, 'action complete via WP Cron', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2348, 793, 'action created', '2022-06-10 04:52:23', '2022-06-10 04:52:23'),
(2391, 754, 'action started via WP Cron', '2022-06-10 09:41:13', '2022-06-10 09:41:13'),
(2392, 754, 'action complete via WP Cron', '2022-06-10 09:41:13', '2022-06-10 09:41:13'),
(2393, 808, 'action created', '2022-06-10 09:41:13', '2022-06-10 09:41:13'),
(2607, 808, 'action started via WP Cron', '2022-06-11 09:44:24', '2022-06-11 09:44:24'),
(2608, 808, 'action complete via WP Cron', '2022-06-11 09:44:24', '2022-06-11 09:44:24'),
(2609, 880, 'action created', '2022-06-11 09:44:24', '2022-06-11 09:44:24'),
(2724, 880, 'action started via WP Cron', '2022-06-12 09:55:35', '2022-06-12 09:55:35'),
(2725, 880, 'action complete via WP Cron', '2022-06-12 09:55:35', '2022-06-12 09:55:35'),
(2726, 919, 'action created', '2022-06-12 09:55:35', '2022-06-12 09:55:35'),
(2865, 919, 'action started via WP Cron', '2022-06-13 10:25:49', '2022-06-13 10:25:49'),
(2866, 919, 'action complete via WP Cron', '2022-06-13 10:25:49', '2022-06-13 10:25:49'),
(2867, 966, 'action created', '2022-06-13 10:25:49', '2022-06-13 10:25:49'),
(3102, 966, 'action started via WP Cron', '2022-06-14 10:26:02', '2022-06-14 10:26:02'),
(3103, 966, 'action complete via WP Cron', '2022-06-14 10:26:02', '2022-06-14 10:26:02'),
(3104, 1045, 'action created', '2022-06-14 10:26:02', '2022-06-14 10:26:02'),
(3279, 1045, 'action started via WP Cron', '2022-06-15 10:26:55', '2022-06-15 10:26:55'),
(3280, 1045, 'action complete via WP Cron', '2022-06-15 10:26:55', '2022-06-15 10:26:55'),
(3281, 1104, 'action created', '2022-06-15 10:26:55', '2022-06-15 10:26:55'),
(3306, 1104, 'action started via WP Cron', '2022-06-16 15:52:13', '2022-06-16 15:52:13'),
(3307, 1104, 'action complete via WP Cron', '2022-06-16 15:52:13', '2022-06-16 15:52:13'),
(3308, 1113, 'action created', '2022-06-16 15:52:13', '2022-06-16 15:52:13'),
(3318, 791, 'action started via WP Cron', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3319, 791, 'action complete via WP Cron', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3320, 1117, 'action created', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3321, 792, 'action started via WP Cron', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3322, 792, 'action complete via WP Cron', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3323, 1118, 'action created', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3324, 793, 'action started via WP Cron', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3325, 793, 'action complete via WP Cron', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3326, 1119, 'action created', '2022-06-17 05:08:20', '2022-06-17 05:08:20'),
(3384, 1113, 'action started via WP Cron', '2022-06-17 15:53:01', '2022-06-17 15:53:01'),
(3385, 1113, 'action complete via WP Cron', '2022-06-17 15:53:01', '2022-06-17 15:53:01'),
(3386, 1139, 'action created', '2022-06-17 15:53:01', '2022-06-17 15:53:01'),
(3516, 1139, 'action started via WP Cron', '2022-06-18 17:23:13', '2022-06-18 17:23:13'),
(3517, 1139, 'action complete via WP Cron', '2022-06-18 17:23:13', '2022-06-18 17:23:13'),
(3518, 1183, 'action created', '2022-06-18 17:23:13', '2022-06-18 17:23:13'),
(3537, 1183, 'action started via WP Cron', '2022-06-19 17:42:56', '2022-06-19 17:42:56'),
(3538, 1183, 'action complete via WP Cron', '2022-06-19 17:42:56', '2022-06-19 17:42:56'),
(3539, 1190, 'action created', '2022-06-19 17:42:56', '2022-06-19 17:42:56'),
(3669, 1190, 'action started via WP Cron', '2022-06-20 19:38:29', '2022-06-20 19:38:29'),
(3670, 1190, 'action complete via WP Cron', '2022-06-20 19:38:29', '2022-06-20 19:38:29'),
(3671, 1234, 'action created', '2022-06-20 19:38:29', '2022-06-20 19:38:29'),
(3882, 1234, 'action started via WP Cron', '2022-06-21 20:45:11', '2022-06-21 20:45:11'),
(3883, 1234, 'action complete via WP Cron', '2022-06-21 20:45:11', '2022-06-21 20:45:11'),
(3884, 1305, 'action created', '2022-06-21 20:45:11', '2022-06-21 20:45:11'),
(3990, 1305, 'action started via WP Cron', '2022-06-22 20:45:40', '2022-06-22 20:45:40'),
(3991, 1305, 'action complete via WP Cron', '2022-06-22 20:45:40', '2022-06-22 20:45:40'),
(3992, 1341, 'action created', '2022-06-22 20:45:40', '2022-06-22 20:45:40'),
(4065, 1341, 'action started via WP Cron', '2022-06-23 22:19:53', '2022-06-23 22:19:53'),
(4066, 1341, 'action complete via WP Cron', '2022-06-23 22:19:53', '2022-06-23 22:19:53'),
(4067, 1366, 'action created', '2022-06-23 22:19:53', '2022-06-23 22:19:53'),
(4077, 1117, 'action started via WP Cron', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4078, 1117, 'action complete via WP Cron', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4079, 1370, 'action created', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4080, 1118, 'action started via WP Cron', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4081, 1118, 'action complete via WP Cron', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4082, 1371, 'action created', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4083, 1119, 'action started via WP Cron', '2022-06-24 11:53:23', '2022-06-24 11:53:23'),
(4084, 1119, 'action complete via WP Cron', '2022-06-24 11:53:24', '2022-06-24 11:53:24'),
(4085, 1372, 'action created', '2022-06-24 11:53:24', '2022-06-24 11:53:24'),
(4092, 1366, 'action started via WP Cron', '2022-06-25 11:51:06', '2022-06-25 11:51:06'),
(4093, 1366, 'action complete via WP Cron', '2022-06-25 11:51:06', '2022-06-25 11:51:06'),
(4094, 1375, 'action created', '2022-06-25 11:51:06', '2022-06-25 11:51:06'),
(4254, 1375, 'action started via WP Cron', '2022-06-26 12:04:27', '2022-06-26 12:04:27'),
(4255, 1375, 'action complete via WP Cron', '2022-06-26 12:04:27', '2022-06-26 12:04:27'),
(4256, 1429, 'action created', '2022-06-26 12:04:27', '2022-06-26 12:04:27'),
(4404, 1429, 'action started via WP Cron', '2022-06-27 12:13:21', '2022-06-27 12:13:21'),
(4405, 1429, 'action complete via WP Cron', '2022-06-27 12:13:21', '2022-06-27 12:13:21'),
(4406, 1479, 'action created', '2022-06-27 12:13:21', '2022-06-27 12:13:21'),
(4428, 1479, 'action started via WP Cron', '2022-06-28 14:39:03', '2022-06-28 14:39:03'),
(4429, 1479, 'action complete via WP Cron', '2022-06-28 14:39:03', '2022-06-28 14:39:03'),
(4430, 1487, 'action created', '2022-06-28 14:39:03', '2022-06-28 14:39:03'),
(4449, 1487, 'action started via WP Cron', '2022-06-29 16:23:11', '2022-06-29 16:23:11'),
(4450, 1487, 'action complete via WP Cron', '2022-06-29 16:23:11', '2022-06-29 16:23:11'),
(4451, 1494, 'action created', '2022-06-29 16:23:11', '2022-06-29 16:23:11'),
(4470, 1494, 'action started via WP Cron', '2022-06-30 18:37:05', '2022-06-30 18:37:05'),
(4471, 1494, 'action complete via WP Cron', '2022-06-30 18:37:05', '2022-06-30 18:37:05'),
(4472, 1501, 'action created', '2022-06-30 18:37:05', '2022-06-30 18:37:05'),
(4524, 1370, 'action started via WP Cron', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4525, 1370, 'action complete via WP Cron', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4526, 1519, 'action created', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4527, 1371, 'action started via WP Cron', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4528, 1371, 'action complete via WP Cron', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4529, 1520, 'action created', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4530, 1372, 'action started via WP Cron', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4531, 1372, 'action complete via WP Cron', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4532, 1521, 'action created', '2022-07-01 11:54:35', '2022-07-01 11:54:35'),
(4574, 1535, 'action created', '2022-07-01 18:39:27', '2022-07-01 18:39:27'),
(4575, 1501, 'action started via WP Cron', '2022-07-01 18:39:27', '2022-07-01 18:39:27'),
(4576, 1501, 'action complete via WP Cron', '2022-07-01 18:39:27', '2022-07-01 18:39:27'),
(4577, 1536, 'action created', '2022-07-01 18:39:27', '2022-07-01 18:39:27'),
(4633, 1555, 'action created', '2022-07-02 04:36:06', '2022-07-02 04:36:06'),
(4635, 1556, 'action created', '2022-07-02 04:36:17', '2022-07-02 04:36:17'),
(4636, 1556, 'action started via Async Request', '2022-07-02 04:36:17', '2022-07-02 04:36:17'),
(4637, 1556, 'action complete via Async Request', '2022-07-02 04:36:17', '2022-07-02 04:36:17'),
(4638, 1555, 'action started via WP Cron', '2022-07-02 05:09:22', '2022-07-02 05:09:22'),
(4639, 1557, 'action created', '2022-07-02 05:09:22', '2022-07-02 05:09:22'),
(4640, 1555, 'action complete via WP Cron', '2022-07-02 05:09:22', '2022-07-02 05:09:22'),
(4641, 1557, 'action started via WP Cron', '2022-07-02 05:32:04', '2022-07-02 05:32:04'),
(4642, 1558, 'action created', '2022-07-02 05:32:04', '2022-07-02 05:32:04'),
(4643, 1557, 'action complete via WP Cron', '2022-07-02 05:32:04', '2022-07-02 05:32:04'),
(4644, 1558, 'action started via WP Cron', '2022-07-02 06:05:13', '2022-07-02 06:05:13'),
(4645, 1559, 'action created', '2022-07-02 06:05:13', '2022-07-02 06:05:13'),
(4646, 1558, 'action complete via WP Cron', '2022-07-02 06:05:13', '2022-07-02 06:05:13'),
(4647, 1559, 'action started via WP Cron', '2022-07-02 06:27:33', '2022-07-02 06:27:33'),
(4648, 1560, 'action created', '2022-07-02 06:27:33', '2022-07-02 06:27:33'),
(4649, 1559, 'action complete via WP Cron', '2022-07-02 06:27:33', '2022-07-02 06:27:33'),
(4650, 1560, 'action started via WP Cron', '2022-07-02 06:49:13', '2022-07-02 06:49:13'),
(4651, 1561, 'action created', '2022-07-02 06:49:13', '2022-07-02 06:49:13'),
(4652, 1560, 'action complete via WP Cron', '2022-07-02 06:49:13', '2022-07-02 06:49:13'),
(4653, 1561, 'action started via WP Cron', '2022-07-02 07:11:13', '2022-07-02 07:11:13'),
(4654, 1562, 'action created', '2022-07-02 07:11:13', '2022-07-02 07:11:13'),
(4655, 1561, 'action complete via WP Cron', '2022-07-02 07:11:13', '2022-07-02 07:11:13'),
(4656, 1562, 'action started via WP Cron', '2022-07-02 07:33:16', '2022-07-02 07:33:16'),
(4657, 1563, 'action created', '2022-07-02 07:33:16', '2022-07-02 07:33:16'),
(4658, 1562, 'action complete via WP Cron', '2022-07-02 07:33:16', '2022-07-02 07:33:16'),
(4659, 1563, 'action started via WP Cron', '2022-07-02 07:55:04', '2022-07-02 07:55:04'),
(4660, 1564, 'action created', '2022-07-02 07:55:04', '2022-07-02 07:55:04'),
(4661, 1563, 'action complete via WP Cron', '2022-07-02 07:55:04', '2022-07-02 07:55:04'),
(4662, 1564, 'action started via WP Cron', '2022-07-02 08:17:14', '2022-07-02 08:17:14'),
(4663, 1565, 'action created', '2022-07-02 08:17:14', '2022-07-02 08:17:14'),
(4664, 1564, 'action complete via WP Cron', '2022-07-02 08:17:14', '2022-07-02 08:17:14'),
(4665, 1565, 'action started via WP Cron', '2022-07-02 08:38:59', '2022-07-02 08:38:59'),
(4666, 1566, 'action created', '2022-07-02 08:38:59', '2022-07-02 08:38:59'),
(4667, 1565, 'action complete via WP Cron', '2022-07-02 08:38:59', '2022-07-02 08:38:59'),
(4668, 1566, 'action started via WP Cron', '2022-07-02 09:00:46', '2022-07-02 09:00:46'),
(4669, 1567, 'action created', '2022-07-02 09:00:46', '2022-07-02 09:00:46'),
(4670, 1566, 'action complete via WP Cron', '2022-07-02 09:00:46', '2022-07-02 09:00:46'),
(4671, 1567, 'action started via WP Cron', '2022-07-02 09:22:39', '2022-07-02 09:22:39'),
(4672, 1568, 'action created', '2022-07-02 09:22:39', '2022-07-02 09:22:39'),
(4673, 1567, 'action complete via WP Cron', '2022-07-02 09:22:39', '2022-07-02 09:22:39'),
(4674, 1568, 'action started via WP Cron', '2022-07-02 09:44:31', '2022-07-02 09:44:31'),
(4675, 1569, 'action created', '2022-07-02 09:44:31', '2022-07-02 09:44:31'),
(4676, 1568, 'action complete via WP Cron', '2022-07-02 09:44:31', '2022-07-02 09:44:31'),
(4677, 1569, 'action started via WP Cron', '2022-07-02 10:38:57', '2022-07-02 10:38:57'),
(4678, 1570, 'action created', '2022-07-02 10:38:57', '2022-07-02 10:38:57'),
(4679, 1569, 'action complete via WP Cron', '2022-07-02 10:38:57', '2022-07-02 10:38:57'),
(4680, 1570, 'action started via WP Cron', '2022-07-02 11:00:37', '2022-07-02 11:00:37'),
(4681, 1571, 'action created', '2022-07-02 11:00:37', '2022-07-02 11:00:37'),
(4682, 1570, 'action complete via WP Cron', '2022-07-02 11:00:37', '2022-07-02 11:00:37'),
(4683, 1571, 'action started via WP Cron', '2022-07-02 11:22:32', '2022-07-02 11:22:32'),
(4684, 1572, 'action created', '2022-07-02 11:22:32', '2022-07-02 11:22:32'),
(4685, 1571, 'action complete via WP Cron', '2022-07-02 11:22:32', '2022-07-02 11:22:32'),
(4686, 1572, 'action started via WP Cron', '2022-07-02 11:44:15', '2022-07-02 11:44:15'),
(4687, 1573, 'action created', '2022-07-02 11:44:15', '2022-07-02 11:44:15'),
(4688, 1572, 'action complete via WP Cron', '2022-07-02 11:44:15', '2022-07-02 11:44:15'),
(4689, 1573, 'action started via WP Cron', '2022-07-02 14:05:19', '2022-07-02 14:05:19'),
(4690, 1574, 'action created', '2022-07-02 14:05:19', '2022-07-02 14:05:19'),
(4691, 1573, 'action complete via WP Cron', '2022-07-02 14:05:19', '2022-07-02 14:05:19'),
(4692, 1574, 'action started via WP Cron', '2022-07-02 14:26:45', '2022-07-02 14:26:45'),
(4693, 1575, 'action created', '2022-07-02 14:26:45', '2022-07-02 14:26:45'),
(4694, 1574, 'action complete via WP Cron', '2022-07-02 14:26:45', '2022-07-02 14:26:45'),
(4695, 1575, 'action started via WP Cron', '2022-07-02 14:48:39', '2022-07-02 14:48:39'),
(4696, 1576, 'action created', '2022-07-02 14:48:39', '2022-07-02 14:48:39'),
(4697, 1575, 'action complete via WP Cron', '2022-07-02 14:48:39', '2022-07-02 14:48:39'),
(4698, 1576, 'action started via WP Cron', '2022-07-02 15:10:44', '2022-07-02 15:10:44'),
(4699, 1577, 'action created', '2022-07-02 15:10:44', '2022-07-02 15:10:44'),
(4700, 1576, 'action complete via WP Cron', '2022-07-02 15:10:44', '2022-07-02 15:10:44'),
(4701, 1577, 'action started via WP Cron', '2022-07-02 15:32:34', '2022-07-02 15:32:34'),
(4702, 1578, 'action created', '2022-07-02 15:32:34', '2022-07-02 15:32:34'),
(4703, 1577, 'action complete via WP Cron', '2022-07-02 15:32:34', '2022-07-02 15:32:34'),
(4704, 1578, 'action started via WP Cron', '2022-07-02 15:54:29', '2022-07-02 15:54:29'),
(4705, 1579, 'action created', '2022-07-02 15:54:29', '2022-07-02 15:54:29'),
(4706, 1578, 'action complete via WP Cron', '2022-07-02 15:54:29', '2022-07-02 15:54:29'),
(4707, 1579, 'action started via WP Cron', '2022-07-02 16:27:32', '2022-07-02 16:27:32'),
(4708, 1580, 'action created', '2022-07-02 16:27:32', '2022-07-02 16:27:32'),
(4709, 1579, 'action complete via WP Cron', '2022-07-02 16:27:32', '2022-07-02 16:27:32'),
(4710, 1580, 'action started via WP Cron', '2022-07-02 16:49:08', '2022-07-02 16:49:08'),
(4711, 1581, 'action created', '2022-07-02 16:49:08', '2022-07-02 16:49:08'),
(4712, 1580, 'action complete via WP Cron', '2022-07-02 16:49:08', '2022-07-02 16:49:08'),
(4713, 1581, 'action started via WP Cron', '2022-07-02 17:08:27', '2022-07-02 17:08:27'),
(4714, 1582, 'action created', '2022-07-02 17:08:27', '2022-07-02 17:08:27'),
(4715, 1581, 'action complete via WP Cron', '2022-07-02 17:08:27', '2022-07-02 17:08:27'),
(4716, 1582, 'action started via WP Cron', '2022-07-02 17:32:58', '2022-07-02 17:32:58'),
(4717, 1583, 'action created', '2022-07-02 17:32:58', '2022-07-02 17:32:58'),
(4718, 1582, 'action complete via WP Cron', '2022-07-02 17:32:58', '2022-07-02 17:32:58'),
(4719, 1583, 'action started via WP Cron', '2022-07-02 18:06:07', '2022-07-02 18:06:07'),
(4720, 1584, 'action created', '2022-07-02 18:06:08', '2022-07-02 18:06:08'),
(4721, 1583, 'action complete via WP Cron', '2022-07-02 18:06:08', '2022-07-02 18:06:08'),
(4722, 1584, 'action started via WP Cron', '2022-07-02 18:28:02', '2022-07-02 18:28:02'),
(4723, 1585, 'action created', '2022-07-02 18:28:02', '2022-07-02 18:28:02'),
(4724, 1584, 'action complete via WP Cron', '2022-07-02 18:28:02', '2022-07-02 18:28:02'),
(4725, 1535, 'action started via WP Cron', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4726, 1535, 'action complete via WP Cron', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4727, 1586, 'action created', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4728, 1536, 'action started via WP Cron', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4729, 1536, 'action complete via WP Cron', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4730, 1587, 'action created', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4731, 1585, 'action started via WP Cron', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4732, 1588, 'action created', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4733, 1585, 'action complete via WP Cron', '2022-07-02 18:44:24', '2022-07-02 18:44:24'),
(4734, 1588, 'action started via WP Cron', '2022-07-02 19:00:50', '2022-07-02 19:00:50'),
(4735, 1589, 'action created', '2022-07-02 19:00:50', '2022-07-02 19:00:50'),
(4736, 1588, 'action complete via WP Cron', '2022-07-02 19:00:50', '2022-07-02 19:00:50'),
(4737, 1589, 'action started via WP Cron', '2022-07-02 19:22:55', '2022-07-02 19:22:55'),
(4738, 1590, 'action created', '2022-07-02 19:22:55', '2022-07-02 19:22:55'),
(4739, 1589, 'action complete via WP Cron', '2022-07-02 19:22:55', '2022-07-02 19:22:55'),
(4740, 1590, 'action started via WP Cron', '2022-07-02 19:44:50', '2022-07-02 19:44:50'),
(4741, 1591, 'action created', '2022-07-02 19:44:50', '2022-07-02 19:44:50'),
(4742, 1590, 'action complete via WP Cron', '2022-07-02 19:44:50', '2022-07-02 19:44:50'),
(4743, 1591, 'action started via WP Cron', '2022-07-02 20:18:00', '2022-07-02 20:18:00'),
(4744, 1592, 'action created', '2022-07-02 20:18:00', '2022-07-02 20:18:00'),
(4745, 1591, 'action complete via WP Cron', '2022-07-02 20:18:00', '2022-07-02 20:18:00'),
(4746, 1592, 'action started via WP Cron', '2022-07-02 20:40:03', '2022-07-02 20:40:03'),
(4747, 1593, 'action created', '2022-07-02 20:40:03', '2022-07-02 20:40:03'),
(4748, 1592, 'action complete via WP Cron', '2022-07-02 20:40:03', '2022-07-02 20:40:03'),
(4749, 1593, 'action started via WP Cron', '2022-07-02 21:02:16', '2022-07-02 21:02:16'),
(4750, 1594, 'action created', '2022-07-02 21:02:16', '2022-07-02 21:02:16'),
(4751, 1593, 'action complete via WP Cron', '2022-07-02 21:02:16', '2022-07-02 21:02:16'),
(4752, 1594, 'action started via WP Cron', '2022-07-02 21:24:30', '2022-07-02 21:24:30'),
(4753, 1595, 'action created', '2022-07-02 21:24:30', '2022-07-02 21:24:30'),
(4754, 1594, 'action complete via WP Cron', '2022-07-02 21:24:30', '2022-07-02 21:24:30'),
(4755, 1595, 'action started via WP Cron', '2022-07-02 21:46:42', '2022-07-02 21:46:42'),
(4756, 1596, 'action created', '2022-07-02 21:46:42', '2022-07-02 21:46:42'),
(4757, 1595, 'action complete via WP Cron', '2022-07-02 21:46:42', '2022-07-02 21:46:42'),
(4758, 1596, 'action started via WP Cron', '2022-07-02 22:08:40', '2022-07-02 22:08:40'),
(4759, 1597, 'action created', '2022-07-02 22:08:40', '2022-07-02 22:08:40'),
(4760, 1596, 'action complete via WP Cron', '2022-07-02 22:08:40', '2022-07-02 22:08:40'),
(4761, 1597, 'action started via WP Cron', '2022-07-02 22:30:44', '2022-07-02 22:30:44'),
(4762, 1598, 'action created', '2022-07-02 22:30:44', '2022-07-02 22:30:44'),
(4763, 1597, 'action complete via WP Cron', '2022-07-02 22:30:44', '2022-07-02 22:30:44'),
(4764, 1598, 'action started via WP Cron', '2022-07-02 22:52:53', '2022-07-02 22:52:53'),
(4765, 1599, 'action created', '2022-07-02 22:52:53', '2022-07-02 22:52:53'),
(4766, 1598, 'action complete via WP Cron', '2022-07-02 22:52:53', '2022-07-02 22:52:53'),
(4767, 1599, 'action started via WP Cron', '2022-07-02 23:12:45', '2022-07-02 23:12:45'),
(4768, 1600, 'action created', '2022-07-02 23:12:45', '2022-07-02 23:12:45'),
(4769, 1599, 'action complete via WP Cron', '2022-07-02 23:12:45', '2022-07-02 23:12:45'),
(4770, 1600, 'action started via WP Cron', '2022-07-02 23:31:31', '2022-07-02 23:31:31'),
(4771, 1601, 'action created', '2022-07-02 23:31:31', '2022-07-02 23:31:31'),
(4772, 1600, 'action complete via WP Cron', '2022-07-02 23:31:31', '2022-07-02 23:31:31'),
(4773, 1601, 'action started via WP Cron', '2022-07-02 23:48:11', '2022-07-02 23:48:11'),
(4774, 1602, 'action created', '2022-07-02 23:48:11', '2022-07-02 23:48:11'),
(4775, 1601, 'action complete via WP Cron', '2022-07-02 23:48:11', '2022-07-02 23:48:11'),
(4776, 1602, 'action started via WP Cron', '2022-07-03 00:10:16', '2022-07-03 00:10:16'),
(4777, 1603, 'action created', '2022-07-03 00:10:16', '2022-07-03 00:10:16'),
(4778, 1602, 'action complete via WP Cron', '2022-07-03 00:10:16', '2022-07-03 00:10:16'),
(4779, 1603, 'action started via WP Cron', '2022-07-03 00:32:20', '2022-07-03 00:32:20'),
(4780, 1604, 'action created', '2022-07-03 00:32:21', '2022-07-03 00:32:21'),
(4781, 1603, 'action complete via WP Cron', '2022-07-03 00:32:21', '2022-07-03 00:32:21'),
(4782, 1604, 'action started via WP Cron', '2022-07-03 01:04:34', '2022-07-03 01:04:34'),
(4783, 1605, 'action created', '2022-07-03 01:04:34', '2022-07-03 01:04:34'),
(4784, 1604, 'action complete via WP Cron', '2022-07-03 01:04:34', '2022-07-03 01:04:34'),
(4785, 1605, 'action started via WP Cron', '2022-07-03 01:27:56', '2022-07-03 01:27:56'),
(4786, 1606, 'action created', '2022-07-03 01:27:56', '2022-07-03 01:27:56'),
(4787, 1605, 'action complete via WP Cron', '2022-07-03 01:27:56', '2022-07-03 01:27:56'),
(4788, 1606, 'action started via WP Cron', '2022-07-03 01:46:11', '2022-07-03 01:46:11'),
(4789, 1607, 'action created', '2022-07-03 01:46:11', '2022-07-03 01:46:11'),
(4790, 1606, 'action complete via WP Cron', '2022-07-03 01:46:11', '2022-07-03 01:46:11'),
(4791, 1607, 'action started via WP Cron', '2022-07-03 02:01:32', '2022-07-03 02:01:32'),
(4792, 1608, 'action created', '2022-07-03 02:01:32', '2022-07-03 02:01:32'),
(4793, 1607, 'action complete via WP Cron', '2022-07-03 02:01:32', '2022-07-03 02:01:32'),
(4794, 1608, 'action started via WP Cron', '2022-07-03 02:18:35', '2022-07-03 02:18:35'),
(4795, 1609, 'action created', '2022-07-03 02:18:35', '2022-07-03 02:18:35'),
(4796, 1608, 'action complete via WP Cron', '2022-07-03 02:18:35', '2022-07-03 02:18:35'),
(4797, 1609, 'action started via WP Cron', '2022-07-03 02:35:19', '2022-07-03 02:35:19'),
(4798, 1610, 'action created', '2022-07-03 02:35:20', '2022-07-03 02:35:20'),
(4799, 1609, 'action complete via WP Cron', '2022-07-03 02:35:20', '2022-07-03 02:35:20'),
(4800, 1610, 'action started via WP Cron', '2022-07-03 02:57:59', '2022-07-03 02:57:59'),
(4801, 1611, 'action created', '2022-07-03 02:57:59', '2022-07-03 02:57:59'),
(4802, 1610, 'action complete via WP Cron', '2022-07-03 02:57:59', '2022-07-03 02:57:59'),
(4803, 1611, 'action started via WP Cron', '2022-07-03 03:14:50', '2022-07-03 03:14:50'),
(4804, 1612, 'action created', '2022-07-03 03:14:50', '2022-07-03 03:14:50'),
(4805, 1611, 'action complete via WP Cron', '2022-07-03 03:14:50', '2022-07-03 03:14:50'),
(4806, 1612, 'action started via WP Cron', '2022-07-03 03:46:06', '2022-07-03 03:46:06'),
(4807, 1613, 'action created', '2022-07-03 03:46:06', '2022-07-03 03:46:06'),
(4808, 1612, 'action complete via WP Cron', '2022-07-03 03:46:06', '2022-07-03 03:46:06'),
(4809, 1613, 'action started via WP Cron', '2022-07-03 04:09:35', '2022-07-03 04:09:35'),
(4810, 1614, 'action created', '2022-07-03 04:09:35', '2022-07-03 04:09:35'),
(4811, 1613, 'action complete via WP Cron', '2022-07-03 04:09:35', '2022-07-03 04:09:35'),
(4812, 1614, 'action started via WP Cron', '2022-07-03 04:38:28', '2022-07-03 04:38:28'),
(4813, 1615, 'action created', '2022-07-03 04:38:28', '2022-07-03 04:38:28'),
(4814, 1614, 'action complete via WP Cron', '2022-07-03 04:38:28', '2022-07-03 04:38:28'),
(4815, 1615, 'action started via WP Cron', '2022-07-03 05:05:00', '2022-07-03 05:05:00'),
(4816, 1616, 'action created', '2022-07-03 05:05:00', '2022-07-03 05:05:00'),
(4817, 1615, 'action complete via WP Cron', '2022-07-03 05:05:00', '2022-07-03 05:05:00'),
(4818, 1616, 'action started via WP Cron', '2022-07-03 05:32:56', '2022-07-03 05:32:56'),
(4819, 1617, 'action created', '2022-07-03 05:32:56', '2022-07-03 05:32:56'),
(4820, 1616, 'action complete via WP Cron', '2022-07-03 05:32:56', '2022-07-03 05:32:56'),
(4821, 1617, 'action started via WP Cron', '2022-07-03 05:48:48', '2022-07-03 05:48:48'),
(4822, 1618, 'action created', '2022-07-03 05:48:48', '2022-07-03 05:48:48'),
(4823, 1617, 'action complete via WP Cron', '2022-07-03 05:48:48', '2022-07-03 05:48:48'),
(4824, 1618, 'action started via WP Cron', '2022-07-03 06:10:58', '2022-07-03 06:10:58'),
(4825, 1619, 'action created', '2022-07-03 06:10:58', '2022-07-03 06:10:58'),
(4826, 1618, 'action complete via WP Cron', '2022-07-03 06:10:58', '2022-07-03 06:10:58'),
(4827, 1619, 'action started via WP Cron', '2022-07-03 06:31:14', '2022-07-03 06:31:14'),
(4828, 1620, 'action created', '2022-07-03 06:31:14', '2022-07-03 06:31:14'),
(4829, 1619, 'action complete via WP Cron', '2022-07-03 06:31:14', '2022-07-03 06:31:14'),
(4830, 1620, 'action started via WP Cron', '2022-07-03 06:47:32', '2022-07-03 06:47:32'),
(4831, 1621, 'action created', '2022-07-03 06:47:32', '2022-07-03 06:47:32'),
(4832, 1620, 'action complete via WP Cron', '2022-07-03 06:47:32', '2022-07-03 06:47:32'),
(4833, 1621, 'action started via WP Cron', '2022-07-03 07:07:59', '2022-07-03 07:07:59'),
(4834, 1622, 'action created', '2022-07-03 07:07:59', '2022-07-03 07:07:59'),
(4835, 1621, 'action complete via WP Cron', '2022-07-03 07:07:59', '2022-07-03 07:07:59'),
(4836, 1622, 'action started via WP Cron', '2022-07-03 07:23:59', '2022-07-03 07:23:59'),
(4837, 1623, 'action created', '2022-07-03 07:23:59', '2022-07-03 07:23:59'),
(4838, 1622, 'action complete via WP Cron', '2022-07-03 07:23:59', '2022-07-03 07:23:59'),
(4839, 1623, 'action started via WP Cron', '2022-07-03 07:52:43', '2022-07-03 07:52:43'),
(4840, 1624, 'action created', '2022-07-03 07:52:43', '2022-07-03 07:52:43'),
(4841, 1623, 'action complete via WP Cron', '2022-07-03 07:52:43', '2022-07-03 07:52:43'),
(4842, 1624, 'action started via WP Cron', '2022-07-03 08:15:41', '2022-07-03 08:15:41'),
(4843, 1625, 'action created', '2022-07-03 08:15:41', '2022-07-03 08:15:41'),
(4844, 1624, 'action complete via WP Cron', '2022-07-03 08:15:41', '2022-07-03 08:15:41'),
(4845, 1625, 'action started via WP Cron', '2022-07-03 08:35:43', '2022-07-03 08:35:43'),
(4846, 1626, 'action created', '2022-07-03 08:35:43', '2022-07-03 08:35:43'),
(4847, 1625, 'action complete via WP Cron', '2022-07-03 08:35:43', '2022-07-03 08:35:43'),
(4848, 1626, 'action started via WP Cron', '2022-07-03 08:59:42', '2022-07-03 08:59:42'),
(4849, 1627, 'action created', '2022-07-03 08:59:42', '2022-07-03 08:59:42'),
(4850, 1626, 'action complete via WP Cron', '2022-07-03 08:59:42', '2022-07-03 08:59:42'),
(4851, 1627, 'action started via WP Cron', '2022-07-03 09:21:51', '2022-07-03 09:21:51'),
(4852, 1628, 'action created', '2022-07-03 09:21:51', '2022-07-03 09:21:51'),
(4853, 1627, 'action complete via WP Cron', '2022-07-03 09:21:51', '2022-07-03 09:21:51'),
(4854, 1628, 'action started via WP Cron', '2022-07-03 09:41:59', '2022-07-03 09:41:59'),
(4855, 1629, 'action created', '2022-07-03 09:41:59', '2022-07-03 09:41:59'),
(4856, 1628, 'action complete via WP Cron', '2022-07-03 09:41:59', '2022-07-03 09:41:59'),
(4857, 1629, 'action started via WP Cron', '2022-07-03 10:06:17', '2022-07-03 10:06:17'),
(4858, 1630, 'action created', '2022-07-03 10:06:17', '2022-07-03 10:06:17'),
(4859, 1629, 'action complete via WP Cron', '2022-07-03 10:06:17', '2022-07-03 10:06:17'),
(4860, 1630, 'action started via WP Cron', '2022-07-03 10:28:26', '2022-07-03 10:28:26'),
(4861, 1631, 'action created', '2022-07-03 10:28:26', '2022-07-03 10:28:26'),
(4862, 1630, 'action complete via WP Cron', '2022-07-03 10:28:26', '2022-07-03 10:28:26'),
(4863, 1631, 'action started via WP Cron', '2022-07-03 10:43:47', '2022-07-03 10:43:47'),
(4864, 1632, 'action created', '2022-07-03 10:43:47', '2022-07-03 10:43:47'),
(4865, 1631, 'action complete via WP Cron', '2022-07-03 10:43:47', '2022-07-03 10:43:47'),
(4866, 1632, 'action started via WP Cron', '2022-07-03 11:01:44', '2022-07-03 11:01:44'),
(4867, 1633, 'action created', '2022-07-03 11:01:44', '2022-07-03 11:01:44'),
(4868, 1632, 'action complete via WP Cron', '2022-07-03 11:01:44', '2022-07-03 11:01:44'),
(4869, 1633, 'action started via WP Cron', '2022-07-03 11:24:04', '2022-07-03 11:24:04'),
(4870, 1634, 'action created', '2022-07-03 11:24:04', '2022-07-03 11:24:04'),
(4871, 1633, 'action complete via WP Cron', '2022-07-03 11:24:04', '2022-07-03 11:24:04'),
(4872, 1634, 'action started via WP Cron', '2022-07-03 11:46:16', '2022-07-03 11:46:16'),
(4873, 1635, 'action created', '2022-07-03 11:46:16', '2022-07-03 11:46:16'),
(4874, 1634, 'action complete via WP Cron', '2022-07-03 11:46:16', '2022-07-03 11:46:16'),
(4875, 1635, 'action started via WP Cron', '2022-07-03 12:08:39', '2022-07-03 12:08:39'),
(4876, 1636, 'action created', '2022-07-03 12:08:39', '2022-07-03 12:08:39'),
(4877, 1635, 'action complete via WP Cron', '2022-07-03 12:08:39', '2022-07-03 12:08:39'),
(4878, 1636, 'action started via WP Cron', '2022-07-03 12:24:25', '2022-07-03 12:24:25'),
(4879, 1637, 'action created', '2022-07-03 12:24:25', '2022-07-03 12:24:25'),
(4880, 1636, 'action complete via WP Cron', '2022-07-03 12:24:25', '2022-07-03 12:24:25'),
(4881, 1637, 'action started via WP Cron', '2022-07-03 12:41:57', '2022-07-03 12:41:57'),
(4882, 1638, 'action created', '2022-07-03 12:41:57', '2022-07-03 12:41:57'),
(4883, 1637, 'action complete via WP Cron', '2022-07-03 12:41:57', '2022-07-03 12:41:57'),
(4884, 1638, 'action started via WP Cron', '2022-07-03 13:04:20', '2022-07-03 13:04:20'),
(4885, 1639, 'action created', '2022-07-03 13:04:20', '2022-07-03 13:04:20'),
(4886, 1638, 'action complete via WP Cron', '2022-07-03 13:04:20', '2022-07-03 13:04:20'),
(4887, 1639, 'action started via WP Cron', '2022-07-03 13:26:44', '2022-07-03 13:26:44'),
(4888, 1640, 'action created', '2022-07-03 13:26:44', '2022-07-03 13:26:44'),
(4889, 1639, 'action complete via WP Cron', '2022-07-03 13:26:44', '2022-07-03 13:26:44'),
(4890, 1640, 'action started via WP Cron', '2022-07-03 13:47:05', '2022-07-03 13:47:05'),
(4891, 1641, 'action created', '2022-07-03 13:47:05', '2022-07-03 13:47:05'),
(4892, 1640, 'action complete via WP Cron', '2022-07-03 13:47:05', '2022-07-03 13:47:05'),
(4893, 1641, 'action started via WP Cron', '2022-07-03 14:07:12', '2022-07-03 14:07:12'),
(4894, 1642, 'action created', '2022-07-03 14:07:12', '2022-07-03 14:07:12'),
(4895, 1641, 'action complete via WP Cron', '2022-07-03 14:07:12', '2022-07-03 14:07:12'),
(4896, 1642, 'action started via WP Cron', '2022-07-03 14:22:47', '2022-07-03 14:22:47'),
(4897, 1643, 'action created', '2022-07-03 14:22:47', '2022-07-03 14:22:47'),
(4898, 1642, 'action complete via WP Cron', '2022-07-03 14:22:47', '2022-07-03 14:22:47'),
(4899, 1643, 'action started via WP Cron', '2022-07-03 14:48:02', '2022-07-03 14:48:02'),
(4900, 1644, 'action created', '2022-07-03 14:48:02', '2022-07-03 14:48:02'),
(4901, 1643, 'action complete via WP Cron', '2022-07-03 14:48:02', '2022-07-03 14:48:02'),
(4902, 1644, 'action started via WP Cron', '2022-07-03 15:11:38', '2022-07-03 15:11:38'),
(4903, 1645, 'action created', '2022-07-03 15:11:38', '2022-07-03 15:11:38'),
(4904, 1644, 'action complete via WP Cron', '2022-07-03 15:11:38', '2022-07-03 15:11:38'),
(4905, 1645, 'action started via WP Cron', '2022-07-03 15:37:06', '2022-07-03 15:37:06'),
(4906, 1646, 'action created', '2022-07-03 15:37:06', '2022-07-03 15:37:06'),
(4907, 1645, 'action complete via WP Cron', '2022-07-03 15:37:06', '2022-07-03 15:37:06'),
(4908, 1646, 'action started via WP Cron', '2022-07-03 16:02:38', '2022-07-03 16:02:38'),
(4909, 1647, 'action created', '2022-07-03 16:02:38', '2022-07-03 16:02:38'),
(4910, 1646, 'action complete via WP Cron', '2022-07-03 16:02:38', '2022-07-03 16:02:38'),
(4911, 1647, 'action started via WP Cron', '2022-07-03 16:27:57', '2022-07-03 16:27:57'),
(4912, 1648, 'action created', '2022-07-03 16:27:57', '2022-07-03 16:27:57'),
(4913, 1647, 'action complete via WP Cron', '2022-07-03 16:27:57', '2022-07-03 16:27:57'),
(4914, 1648, 'action started via WP Cron', '2022-07-03 16:53:16', '2022-07-03 16:53:16'),
(4915, 1649, 'action created', '2022-07-03 16:53:16', '2022-07-03 16:53:16'),
(4916, 1648, 'action complete via WP Cron', '2022-07-03 16:53:16', '2022-07-03 16:53:16'),
(4917, 1649, 'action started via WP Cron', '2022-07-03 17:31:04', '2022-07-03 17:31:04'),
(4918, 1650, 'action created', '2022-07-03 17:31:05', '2022-07-03 17:31:05'),
(4919, 1649, 'action complete via WP Cron', '2022-07-03 17:31:05', '2022-07-03 17:31:05'),
(4920, 1650, 'action started via WP Cron', '2022-07-03 17:56:05', '2022-07-03 17:56:05'),
(4921, 1651, 'action created', '2022-07-03 17:56:05', '2022-07-03 17:56:05'),
(4922, 1650, 'action complete via WP Cron', '2022-07-03 17:56:05', '2022-07-03 17:56:05'),
(4923, 1651, 'action started via WP Cron', '2022-07-03 18:34:11', '2022-07-03 18:34:11'),
(4924, 1652, 'action created', '2022-07-03 18:34:11', '2022-07-03 18:34:11'),
(4925, 1651, 'action complete via WP Cron', '2022-07-03 18:34:11', '2022-07-03 18:34:11'),
(4926, 1586, 'action started via WP Cron', '2022-07-03 18:46:37', '2022-07-03 18:46:37'),
(4927, 1586, 'action complete via WP Cron', '2022-07-03 18:46:37', '2022-07-03 18:46:37'),
(4928, 1653, 'action created', '2022-07-03 18:46:37', '2022-07-03 18:46:37'),
(4929, 1587, 'action started via WP Cron', '2022-07-03 18:46:37', '2022-07-03 18:46:37'),
(4930, 1587, 'action complete via WP Cron', '2022-07-03 18:46:37', '2022-07-03 18:46:37'),
(4931, 1654, 'action created', '2022-07-03 18:46:37', '2022-07-03 18:46:37'),
(4932, 1652, 'action started via WP Cron', '2022-07-03 18:57:15', '2022-07-03 18:57:15'),
(4933, 1655, 'action created', '2022-07-03 18:57:15', '2022-07-03 18:57:15'),
(4934, 1652, 'action complete via WP Cron', '2022-07-03 18:57:15', '2022-07-03 18:57:15'),
(4935, 1655, 'action started via WP Cron', '2022-07-03 19:24:44', '2022-07-03 19:24:44'),
(4936, 1656, 'action created', '2022-07-03 19:24:44', '2022-07-03 19:24:44'),
(4937, 1655, 'action complete via WP Cron', '2022-07-03 19:24:44', '2022-07-03 19:24:44'),
(4938, 1656, 'action started via WP Cron', '2022-07-03 19:50:18', '2022-07-03 19:50:18'),
(4939, 1657, 'action created', '2022-07-03 19:50:18', '2022-07-03 19:50:18'),
(4940, 1656, 'action complete via WP Cron', '2022-07-03 19:50:18', '2022-07-03 19:50:18'),
(4941, 1657, 'action started via WP Cron', '2022-07-03 20:41:20', '2022-07-03 20:41:20'),
(4942, 1658, 'action created', '2022-07-03 20:41:20', '2022-07-03 20:41:20'),
(4943, 1657, 'action complete via WP Cron', '2022-07-03 20:41:20', '2022-07-03 20:41:20'),
(4944, 1658, 'action started via WP Cron', '2022-07-03 21:06:32', '2022-07-03 21:06:32'),
(4945, 1659, 'action created', '2022-07-03 21:06:32', '2022-07-03 21:06:32'),
(4946, 1658, 'action complete via WP Cron', '2022-07-03 21:06:32', '2022-07-03 21:06:32'),
(4947, 1659, 'action started via WP Cron', '2022-07-03 21:31:40', '2022-07-03 21:31:40'),
(4948, 1660, 'action created', '2022-07-03 21:31:40', '2022-07-03 21:31:40'),
(4949, 1659, 'action complete via WP Cron', '2022-07-03 21:31:40', '2022-07-03 21:31:40'),
(4950, 1660, 'action started via WP Cron', '2022-07-03 21:56:48', '2022-07-03 21:56:48'),
(4951, 1661, 'action created', '2022-07-03 21:56:48', '2022-07-03 21:56:48'),
(4952, 1660, 'action complete via WP Cron', '2022-07-03 21:56:48', '2022-07-03 21:56:48'),
(4953, 1661, 'action started via WP Cron', '2022-07-03 22:21:58', '2022-07-03 22:21:58'),
(4954, 1662, 'action created', '2022-07-03 22:21:58', '2022-07-03 22:21:58'),
(4955, 1661, 'action complete via WP Cron', '2022-07-03 22:21:58', '2022-07-03 22:21:58'),
(4956, 1662, 'action started via WP Cron', '2022-07-03 22:47:03', '2022-07-03 22:47:03'),
(4957, 1663, 'action created', '2022-07-03 22:47:03', '2022-07-03 22:47:03'),
(4958, 1662, 'action complete via WP Cron', '2022-07-03 22:47:03', '2022-07-03 22:47:03'),
(4959, 1663, 'action started via WP Cron', '2022-07-03 23:37:20', '2022-07-03 23:37:20'),
(4960, 1664, 'action created', '2022-07-03 23:37:20', '2022-07-03 23:37:20'),
(4961, 1663, 'action complete via WP Cron', '2022-07-03 23:37:20', '2022-07-03 23:37:20'),
(4962, 1664, 'action started via WP Cron', '2022-07-04 00:02:35', '2022-07-04 00:02:35'),
(4963, 1665, 'action created', '2022-07-04 00:02:35', '2022-07-04 00:02:35'),
(4964, 1664, 'action complete via WP Cron', '2022-07-04 00:02:35', '2022-07-04 00:02:35'),
(4965, 1665, 'action started via WP Cron', '2022-07-04 00:27:47', '2022-07-04 00:27:47'),
(4966, 1666, 'action created', '2022-07-04 00:27:47', '2022-07-04 00:27:47'),
(4967, 1665, 'action complete via WP Cron', '2022-07-04 00:27:47', '2022-07-04 00:27:47'),
(4968, 1666, 'action started via WP Cron', '2022-07-04 00:52:44', '2022-07-04 00:52:44'),
(4969, 1667, 'action created', '2022-07-04 00:52:44', '2022-07-04 00:52:44'),
(4970, 1666, 'action complete via WP Cron', '2022-07-04 00:52:44', '2022-07-04 00:52:44'),
(4971, 1667, 'action started via WP Cron', '2022-07-04 01:17:35', '2022-07-04 01:17:35'),
(4972, 1668, 'action created', '2022-07-04 01:17:35', '2022-07-04 01:17:35'),
(4973, 1667, 'action complete via WP Cron', '2022-07-04 01:17:35', '2022-07-04 01:17:35'),
(4974, 1668, 'action started via WP Cron', '2022-07-04 01:42:34', '2022-07-04 01:42:34'),
(4975, 1669, 'action created', '2022-07-04 01:42:34', '2022-07-04 01:42:34'),
(4976, 1668, 'action complete via WP Cron', '2022-07-04 01:42:34', '2022-07-04 01:42:34'),
(4977, 1669, 'action started via WP Cron', '2022-07-04 02:45:20', '2022-07-04 02:45:20'),
(4978, 1670, 'action created', '2022-07-04 02:45:20', '2022-07-04 02:45:20'),
(4979, 1669, 'action complete via WP Cron', '2022-07-04 02:45:20', '2022-07-04 02:45:20'),
(4980, 1670, 'action started via WP Cron', '2022-07-04 04:03:37', '2022-07-04 04:03:37'),
(4981, 1671, 'action created', '2022-07-04 04:03:37', '2022-07-04 04:03:37'),
(4982, 1670, 'action complete via WP Cron', '2022-07-04 04:03:37', '2022-07-04 04:03:37');

-- --------------------------------------------------------

--
-- Table structure for table `wp_aioseo_cache`
--

CREATE TABLE `wp_aioseo_cache` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aioseo_notifications`
--

CREATE TABLE `wp_aioseo_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_id` bigint(20) UNSIGNED DEFAULT NULL,
  `notification_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `button1_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button1_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button2_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button2_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dismissed` tinyint(1) NOT NULL DEFAULT 0,
  `new` tinyint(1) NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_aioseo_notifications`
--

INSERT INTO `wp_aioseo_notifications` (`id`, `slug`, `title`, `content`, `type`, `level`, `notification_id`, `notification_name`, `start`, `end`, `button1_label`, `button1_action`, `button2_label`, `button2_action`, `dismissed`, `new`, `created`, `updated`) VALUES
(1, '629056974f211', 'Advanced WooCommerce Support', 'We have detected you are running WooCommerce. Upgrade to AIOSEO Pro to unlock our advanced eCommerce SEO features, including SEO for Product Categories and more.', 'info', '[\"all\"]', NULL, 'woo-upsell', '2022-05-27 04:41:59', NULL, 'Upgrade to Pro', 'https://shareasale.com/r.cfm?b=1491200&u=3107422&m=94778&urllink=https%3A%2F%2Faioseo.com%2Flite-upgrade%2F%3Futm_source%3DWordPress%26%23038%3Butm_campaign%3Dliteplugin%26%23038%3Butm_medium%3Dwoo-notification-upsell', NULL, NULL, 0, 0, '2022-05-27 04:41:59', '2022-05-27 04:41:59'),
(2, '6296e926d689f', '📣 Introducing Crawl Cleanup and Import URLs to Your Sitemap!', 'AIOSEO 4.2.1 now allows you to manage Search Engine crawl quota by removing query args (URL parameters) from selected URLs and disabling unnecessary RSS feeds.\r\n<br><br>\r\nYou can also import bulk URLs from a CSV file to add more pages to your sitemap.\r\n<br><br>\r\nUpdate to AIOSEO 4.2.1 to take advantage of these powerful SEO features today!', 'success', '[\"4-x\",\"lite\"]', 327, NULL, '2022-06-28 14:12:59', NULL, 'Learn More', 'https://aioseo.com/introducing-crawl-cleanup-and-importing-urls-from-a-csv-file-to-your-sitemap/?utm_source=WordPress&utm_campaign=crawl-cleanup-v4-lite&utm_medium=plugin-notification&utm_content=Learn More', 'Get AIOSEO Pro', 'https://aioseo.com/pricing/?utm_source=WordPress&utm_campaign=crawl-cleanup-v4-lite&utm_medium=plugin-notification&utm_content=Get%20AIOSEO%20Pro', 0, 1, '2022-06-01 04:20:54', '2022-07-02 04:36:17'),
(3, '6296e926f11e6', '📢 Introducing 2 New Features! — Dashboard Widgets And Shorter URLs 📢', 'We’ve added 2 new dashboard widgets. One to help you set up your website for better SEO and the other to show you an overview of how optimized your posts are.\r\n<br><br>\r\nAnother feature you’ll love is the Strip Category Base Prefix feature that enables you to create shorter URLs by removing the category base.\r\n<br><br>\r\nUpgrade to AIOSEO 4.2.0 Pro today and enjoy these powerful features on your website!!', 'success', '[\"4-x\",\"lite\"]', 308, NULL, '2022-05-31 21:15:05', NULL, 'Learn More', 'https://aioseo.com/new-dashboard-widgets-and-strip-category-base-feature/?utm_source=WordPress&utm_campaign=dashboard-widgets-strip-category-base-v4-lite&utm_medium=plugin-notification&utm_content=Learn More', 'Get AIOSEO Pro', 'https://aioseo.com/lite-upgrade/?utm_source=WordPress&utm_campaign=dashboard-widgets-strip-category-base-v4-lite&utm_medium=plugin-notification&utm_content=Get AIOSEO Pro', 0, 1, '2022-06-01 04:20:54', '2022-06-21 04:24:47'),
(4, '62b2b131ddce7', 'AIOSEO 4.2.2 is HERE with some great new features! 🎉', 'Connect your WordPress user profile directly to your social media accounts for improved SEO.\r\n<br><br>\r\nOur new Translations API enables third-party translation apps to hook into AIOSEO’s data for multilingual SEO.\r\n<br><br>\r\nUpdate to AIOSEO 4.2.2 now and enjoy more SEO opportunities!', 'success', '[\"4-x\",\"lite\"]', 338, NULL, '2022-06-28 14:12:59', NULL, 'Learn More', 'https://aioseo.com/announcing-our-new-user-social-profile-tab-and-translation-api-in-aioseo-4-2-2/?utm_source=WordPress&utm_campaign=social-profiles-translations-api-v4-lite&utm_medium=plugin-notification&utm_content=Learn More', 'Get AIOSEO Pro', 'https://aioseo.com/lite-upgrade/?utm_source=WordPress&utm_campaign=social-profiles-translations-api-v4-lite&utm_medium=plugin-notification&utm_content=Get AIOSEO Pro', 0, 1, '2022-06-22 06:05:37', '2022-07-02 04:36:17'),
(5, '62b47983c982b', 'AIOSEO is Turning 15 YEARS OLD!! 🥳 🥳', '<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAADYCAMAAADyHUVLAAACOlBMVEUAAAABTp7ppw79/frnpiitjHPpQTSDrr/IjyE2NGQxYp3dsSLsly0GTN0cOHH1vzlJjtvkkAWTtcHFhWLXWSeolXXwpBTmczPzvTBAJCxVbaCtWzf92zrlVDPnzHf71zzrpB7h48RwnuCArsXnaS3LmYI0ME/9+/PeZzn3GKqbn6IATp6oK55ifbL79PCivtNEJBn974IATp77+f8APZ0YUJ/2QTMBXKj41nDmzHOloYbw8v1fdZV6h44AXpf/3i7d5PRmi79Qfbf6xygnJ1bJuXuCn8u5roG1xeA7crLR2+/E0einu9o+PnNrgY/wfEL9wgTXwnh0lcSPlYrl6vg6X4380ilKJAkQCTeZm4j4krN+PAqTqtCEjYzy4Mb9sAMYY6w8apaujF0Bqvb+hX35PyHMYCRKbpWchmhcLg3wsAQrY5bHm0kcXJacs9RUc5RNTogqZ6yJfnFna32CSnbXoTz8sR39z5FjTX+8RVVlYqPTQ0JVZ4V5c3r9oATsj1szTY7tn2ihSGe2kk74skpyPyNtMwznjKzaazIdGkX8kgT/0AjQhaxYW5zce0eMbaX9Vk/7oJm2VyIAIZ6teKb1uYf+cGidSyDsbg8Hb7kMQIYFAAw5DAgGoOr58u6hcV+FXVzv17yJSis3gcwIgMj1rnnRvaM9W5ykdhllufr16Nvrw6sHk9uZV1FiP0ja1MxjWWMKLGoGHVQ5JjVWp+u5PzbOLiDCrpattbp4kKrkSQMM4/v/+3UQpDypT5GWAAAAMnRSTlMAnv4y/hT6/P7+MPon/f1B/v6U/Yz+vZ9iTIH7x8eJlIde/cZF/p6NZfb20f7qusfYsy2IE9oAAC1mSURBVHja7NrRS9tAHAfwtBAtTSEWRhZCaKPsTfrQH7kdk+lhxwbCBhnDvo24wZx0DibroIMuD9tb8g/kaQp78Gn4VJjFP26pdzZdMSrD1PO8j5X+7pqH0G9yv2upIkmSJEmSJEmSJEmUqrOioisSB3StQotaXZE44HRMWti2InHAiBy6dBFbVaQbppqO5mmOOWohhIjdRFQ164VaQuGDXow6HS8atRGTEF7OKhflRsNSztc8OeGmf1ZMzTPMUVuvE8LNWeXBWm811MxAOLoWHdZDbEKE7urW+nojHd1z0lptNpscXYumpyu0hQjeRCwrvUH0qqGkknmO9jO6oSp0xSL8rKQ5U42gxFEEU1QlYRLSJoSYyp3gBEGR69VArxNCE6nr/F45/0l1KtM7maIf+I7CK71uj9JI/k7ZNb1cEIhlBIb179T9IPD94uQkrfNllctX2PSy7kHa7H9kF7BADkth2McoQceA3xcDP/KDtxhhCsHTl5A8b7X2cI5guXBZJKatsluEaXtfdvogmNI+IADXpSME+0EQJYFU+8AgeP0KEq1nLcjZJZHUSIUlQxctT/sG4lkDAPd4/hixYSn0o8gLwh+AgGJp7bX2IGd4+cJEbLLIKp0kPK0PCIFoUPJw//w8Yu//52roRVEUhPHmxCFZZprIIkm/4a0R0u7suELGMQpk/ug5psPvcRgl/GrcY0HMMpfsRFS617VNlQ5tEmkfQThnrQMDRmeB0DskpoHMHC5kNHTC2DpbvqJdEI67uoJoNX46iGPf87wwjl/AzShfcIc8KTrso2CdRDsuCAa5K4/esHI8tz2MwyAcDgd0jnLTo3JXUDKYpG1U0oEn4hYLDmFab3hqAJMWNmBWvR0vq9m7LHNcV0hnE+6GT78H24MDmLS11DrNqguzUFYy1KIH6RJma+JtsWDyqsdbMLYGUzAkunNzPcgftpQMuq2mA2NXwE3vpIUlDBRC569OXx++6+a+bmXus6Z/G1cT8VPIpI1fwGR1i96gC7ljgVyuIHYcHLlqIBjOhW7zg6IFQmwi+zh0zSeQQyAIwL21gJqeyD7wugFC1xsIAhc+PF69rf6ybwW7cYNA9J9GgwTI+Ia4ISFOHHzwyQfL8sfkI/qb5QEu3u5uqnZdqVvlNd4YGGBmHjNAmuzF02vSB4ZSYfTPWEq9MNfC7xuzuJQQ3qJVUr0ppC7uWJQ8EHOFYCd/hocg71fPL4MzxOIqQgRTUsrqaXhXfCP6mRB6RIgaitfEcC181EEFT+IaQgSvVrrljbcQpntCxCeEEF8OMkHqayJE8KyUx770vuiEKKluCEHVPSHichCTlo5IXBAhq1Lzgy1JtAdguhZ/PCx/1mVWze23ERLsD7j9dUvET2/iKHCU+gJCBLlbPoS4d9my0aeEAU8lntctxHetn2Od6Tk2b0xSP6csBRIuBD8rC47SsHiREMFGTudRmLmZPtM2gwlBWtlv9+dkxpf4THWgp+wyG3od02nlxC/X/62uKnj+dMLlESGigq4A/NIwzyvRsi9dP6vW11NWsDdejSlhRtbS8qBAliAr1dK82EWNdi7NLJ6vbaOtixuR1wULDpzaWd18OgapZqYOYeJ+TgX3hMTi6ruYEl1iuCdkYOaf2e5a3w/2PLZRpaVtUy1BRh6ttOOP2XelWbxGCHs18ckgn01IuYKdtCigkRdtqkH9rru2/OxJnFvE8YK4koAVrI87ALWEoqlg0LV3izNelUxcJ2qfjNlP468pbj9Ph8KnhCxYO9bpqd8UuM9xVgDlHw9RbzmJORnGWlqKulYGOoWIfTFCBGs13hThQ6JGiKrpbF5m2rzfyJudKlwmQzuF9bfWlqWYMHszENfVIq3PYpq1VDqm+A0LXDmnUCeoDAtajG9xYpR0gxDeI+7zZx5syM+2Z4HFeOi3LCvtfiEU23QrRD8jJFlZEfzByOD3uucsxPnTr0UBP3nKUxI04GHhrhpWSxYDo1oGEiitcyPklGF4wjnuJULI3mSsNUircJ89EYL3QNnSYlkqpk5Y5gwBx761RBI1BOxS873UHyImA0JGzsgW2Jl5rRlQwJYaaSqW4Cy+9IOUhinLxo88r1EBtySsE0dsEGe5WylusB/romj5lJCOnu+sDFtJgBObAKoM0QZpDVP3bJCWkQ7VgKkY5muEsA+5TyyEuBtCFhVfJSS4PkJx9BCkfkyIChYh0Wo2fNdSzWixFskaJlqnEGICLlV65w+GkM/RUB0gSlqMjZBcp5IGBYJ3jGF3fxCSMiFw+JzrMbPUjRCIBRR3NOfnE0LU/cXw2IvIVucHF9CgczPIQR26xZjZcJhQFL+oYjwsh3ISCt0RQkLp1wihLWimDtCgZVjpESGWYElqvoQahcDakhAiQTr+gEfRKypYYYjbZkKpnHhw8ZH6ICRhwRmNBARHaKIbQmRIZrNwxB6kPQhRHsWAXSpt4OsXEaIUavHU1cdIBBBNMHb8GIPU+Qk7GVUJkS6uDtv1pD26QAU06uKLiPywukpIG7MhvErIeEPIgkSxK3jknhBYefIlibrUdrTUHJOf4JxrewQv2mL1ghBrreZUw4vmPkgJPBzW4KZSz2dC0AEr2XGVPlIWV53wEPtfEeL2bTNB9ktJiewlqzODXecQ1DhRtGH3ogesVzat5VSDmqoCBDR68gBC+FpCBJ1TlsAyt9plEx5FCN7XALWrQUzwlRJoqYQsCt11SsNxrUiInrKH5KKBBUQ1dTVCeI1IBYbrckiNENEICaOgB4SQgGOgV+HgCSGUgs3QhEn32mAgWTzsEM5IW1pnjc18IqSZPScrEY3iJ0LwCIwIc/Zpp4711ZQl2NnzDn/E+PIpIWVV2n2bNYLBH4QkCnkf/xi0nmGERfCFH4RwoW/aVqSFkahFSGrRSFQih+BSDdIqIRs9J4Q00iS5JxHS7RJ1tt4Ak4qvy6HpY0zajzhxoDsIgRj75Hmsc4vM2wxD3ZGyEpEu6XseFmoA7XJ6lZCEy1m3xplp0nBGu4fcE1KXgK67HIxohEC9JCXiP6yUYVHIT0lZzrkdkjIEiYAQlRBEjTawuvZQdqCQPzG0/iUhgyrb+1NCuIAAdADaAka+wTD4bnVA5Oh2dFAHIRGqFXvxXht98cUCw7N5/djbvbm8RgiWZfphTc2NdZLbCLEHIUo2cRxwwQedIoRJl8qlbiG2FfrF0JeqYEi0CGnjKM/HwXfiCV5Jqi6KTogrhKhOiCWKENXqGSE+xfxv79FfCWnFatuk2uF2g4BzR4QQVWPCzoT3KgYL7cgRJQ2LxxtCKKDwGiHs1EZAuxkJIWiYzDbk99WYGSJ4/2YmxKY5UibPJsYBSnwrUltt36M2I1cJ8jH6EWnWACuJUmXG5j4MSzxPKa5UUCfkJU4r5eEwb1OrSc8YxU9DKzLPMY77E0KOoHBE2BDOTOWnRR/mj1NNEiYZ2mF2NQXGpGnjIs9LFsMGX3VaYtzJmKXq0QB2Db9MyN73IWY+vtf3XsZHF6k6dvHeUiuBXuCKc9V5utsefbou8KiWMwbr5g8c3vxDQo7QTMQ8upv/EIEczO7Dn81+rOydmV2tNvmmLL3+43dOfQsU/TueXm51vQavXbp/9tpTQRTQXftdjz4Unj7mWYneDbk8aFfPCI8IQQGwWof2RgXtmHhnx9nse9XEIxVPGwhZNfPLhJTIjvyOf+J2/LQleH5ACCzT56t6v9KXI6vjS3UBH7jVX0EIaelGZvF+oCVqnRYSjwjJWEMjon06ahi03ulKRZiHgEvONb91QkmpNLzlbzl8ZDA/iJBaXKw8wW1UgX58JUbvVMD+dAkhUNwpFax+V5gnF0PBFH9QYiM1rPpaOBuUSsSCLiKEBA6QNgT1pkg/fDFrB5x2FRpirtPRb9x/SH4tQtAYXVz5q6QCcT++K6iDC875mCvODrt6+jb6dYQA4g3PWQ8gCm5qqNb8RfPKhBcTAog3+9e/fhOts7jKZOAlQr7wHP/OH+x84YuQ/xxfhPxj+CLkH8MXIf8Yvgj5x/BFyD+G3yNEiP/kbv6dvfN7TeSK4jhIK0L6UNlCoWXfWih9PHvvzIMQ/AHij0AHMSmoJbKp3Ww2SeOPiMZErEEFcZvtNmTJQ3BJLMlDtuRl+/f1nvnhmZk6Go3ptt1+oW1m5s51vJ/5nnPunWnyz9UUQIgEh/+pWPSufrVGY6dSqlR2FjUo9yGuy77z/bHmrR3CK82q2+3OSeJf1WblnogwXaN2/ud+pd1dgHzWrEk5yVAuJ1VLUyDh1HLCWcGApiyYFNCVh/dAtwLy4SfCGTblapXbEOH0zs9kIlyO+TQFGLWine+DR24D5KOHFhQvTk5OJFTztsvWhfUt/ceSG60FRMkGxP9IlQGEdqL+B6LpCyuPk+9RL9Ak1QZM0OXRJcCzDeUQNFVzxlny4PSv6EYBgX8HEMurZfcK5Cu31R/fa1JNUmtMMMdRqnPM2bqyC3yZAzSqbuSIV3y6dvZfcgj/2xzyBfEgICqRF0hkwoX0UqkewNb6Pux7PcvAeaPSlKQScDZYW5Pv4BAOfMTvHLNu2JtZWzscp6MOOx1UaTaHYWF/mRrPG8hHxIOAkEfUu91ZvJNKHWkt3nS9W6CqKU4SDjkb8NkdwsH8EgKVxZYte7PbHGdTFt6yFni5sH6uos+YN7UIze8FyEPJphwRQYvg3T4uYqU6eoB97e0DlKoip+9I7h39fxsuTnYIH+EQzpgcCAsFZdyVD2qKAiqqb2EHLIvNEkEYDjm1zmM/EMRuAnlmfF7QEG7QKXSOVfLZmaznRinX1D5kf0M5YJfHvR6/ByBfEQnyyIsTExB3A5yBHKdSx0a6W2wIbwg1KwaQoqd7AHx6h3AWXYr51HaxbRlYxodK+pbUt6XjwyKZZZf8WrN4Rh6+FhfWjy8xgHBcO+5fiurHI/rRZELbYdnpVy+LxEUmXDsFLr6YqB5LFfxKfYB1YZC9lBob5g3kQzKIrfLVYxbdF05AjtRa6/hY/HfHLVWrUs6NmQcx9eve18CndQiOKe7RFQv+uq3/GFGBxPStMAuYmhljyVlG3xNn2TgdT27rXT8ydaYr6DM+C7gtsZxeo0MabqkJMu4pdr3L6jHMnsfzdwgZxE5EA0IWcQTS4/xIZBK8vFLODXLJrTPkcHC4zKbPIZwtiQEi+eXMSCCBgKWZL8y4BUgEsCVpCVDDnckgAyCEqrQuSIsAyAEquRqHSqkk0Hi9ReBci9Y9PncgZBC7TlQg4y2iGbfXE4mk10l1nqNDKgJIDYBtFeik8Q6xAKHxIcUdHKL9QEQSjFuALNn60SLetrGZMYIcxIbowaK+t8+16W6uulh153CGVSzqOfMSv/H8gFCJ5UwEgaBq4Ci0CDLZQwcfaTkECUJxQTkEzsdUWSQLEM6MG5+UHAnEb2/mz1t4JqkfswFko7cYDr/lA7dtK0CeeheTITrEXctJNbdaPj4/2rvUY9bevIF8Io3Ric4DU7SzN496vR6mkZ56v5SqtVrtjxKwgqIc8jEOCUeDJGvIosBPsgMh2S2AQJzkz6oB0XDUMEIaBKMMLGr0PQ1tLlMTo1ASRqkt4i2Ik2Hg9+GQT6VbaOLvqC++3oG9TqqnOoI1arnXwBYfF4D013ThS5r0iIBwljANYDwS948FEotE4klyUpQcYuuBLMKCPmtazxoN4rht1SKHZ5gHmyJOLDaquRqmDlTvGAP15byBPJzEYmISAY7O7uN1HuNwLq/vSpJrYR0YG5dD7CKHsMgwJ2SiwEAOJx2B+BMyMIjiGUbM4WYgvu08MMhqPVCUMtr7owwBJsw5yCrc3twoAFoEI1aupNaVez1kcg9V1odu6VaaMFvve3bUmuNoDwoLrh+k2ivP6u6zkU0nAyEPJcQWWi6YdAASk7UWlKfjQEBG9eALqh70kWGID9W8JG0WuLHFG2/dAketBCoQJgJ1p9M75vMG8tGtgTiI/kzK8w6G1s5PV+23Uq397efK45kcwimgLJlmelYgNLpGi/jwngcEQn6x17WICOSYwW8YsQiPXXx/8zEwVv2j2qgY1S7wxeJzzOzvCkiNO1nkeu36VP0UEEsJyKTafiW5W62WS9mfxSE0+r6g6QGWDQiFfAMZ5WlTlUU9ZP1E2d48TDXaSCHCwuY3Um19meEERK1ePN0bBvxdAgEnIGtrAwBewmrku59E4ZFOu6VXrZYHq95ZHJKxhHsqg0bN1EEXxaSEqYe46QLiljwu+02bMWLlMPvd2tzw/CBJXtc6wOWeALIHj7u0BDH/HDI7EPlsDYmwqroovOt900n10SLnAsjG/hiH+JbCpIzPBGSbwoku2ucEhIwXNgNhnJDSPvOmX0aWuiMdgWyuvvr2XNxmV64vjzsdEbIuYVn9cvLcgTy8a8g6PRVIzgCBQGHjvP0m9WW69baWbi2EVvvAnechwdETQ9PgTwSSYNTtVECAKISH62RxJx6soHietvAuaz9ICXV6+nRQLHOdvpt5CAJxEhPLodcylADYobedPn/QT7eEPl8J1T2Lk54YImfOcec4h0wOWZAdDwRYxLKP0zbEHGpe0oLystUSpUpa+P+X346eAzQqALIarec+U59D2SsskgWhwccXT35PCwke7V0BpF5kAFM9D7Gk5DydFbcDoaBPix+U1GlePpTpHOsJ275xNS82LSrKFRrkVfpBqvPSdcB4o+qusMHafIHQ49vJyk0CMmB4wwhdB59Eb9Kt9pWyEiqvHjI+7RND08KScctSJWxfy5K53ULJIAGx9kAOshbKxoGMo0EOlZDn6Uvpbfv8l87nTz27ABV3ronZ8/p63iGLksjsM3UY4J0yENf38cdqiv8x3Xq5qoRCZWVhcWqHAOR9NO3j6mHDIASEbneujbdpvRCBOPVAj8CGxS4tujho2bu6siBySKt93nmQTl9tFAFKTT4QqVOetcq6c8yqjANyuqbqbFBw3SxHg09u2h78e8zlckgpAJ/+mfpwvON5hpIjTksnvm2ZoQJ+amBZOolHbT0kZfvcZmLNu94tr4Su2iIOq+G4+HXQuA2v4R6AfDEWBK32jtO1yuMUthZcr8Q1X7kUodVuKKT8DHzat07M45lcSgQSGf+YxcVYJhAIR3xDQgEdCPUQDiS2/bZxp8qNTnQEslsvr6y4kMfNzc3+hfpVGcD13YHMHrNqzgbpe64acDq4HmTxAaGifPBBSNF41JWVsncf+NQOyftnXn6Pg+Pyu/1TWTRpPtGRR3FDWD2keAWQC/XGuz4TwUDGsHA6XyBkkdlTCIfNOj5iZky/+k1FGfJQRFpfZ3w6h9C9a5bDWhY1oMVEExDfSKAoqnwdlrGolUjp5bKiIJHoxcVF9GAzjzMv/CfL+T2/BuScQhxV7B9sAYdKFdtwJpBsiPTR7WIW6ZZDu7O8lyXH7Q8MIyOBRJKjxpuAxMhKI1arqPLCeg0cxL2hlXJdEXJdpdtP22nXLmQxRmNpObND7miRGjg4hP7aRlOrjDkw2F/31hGHUu+GVlyVGd5cZHnbSIczo2fqNivFZbC+5BC1eoQWR2h2Q8vCo3VQF0CE3VEbHo+njGumspiji4p3v9/fmR8Q0id3KnqP9vBoLVeiNw4XCxi50CWheh/4DG+dBGPmccyw0UDCsGTxhwxWIPFfw2Yi/oD1WuixiN+x5mWbq+WQGoB1LRQZ7gb8rNfd7uvZgcye153ft+aCBy59Ai8ZPEC3yWNvHU1S3gU+hUMSTB9TeVhb+WIJcFxclMPDZv4wAzsQBoG4z2gQke02yJvXfEdrayFUxpSoxWBlt7AF2HRH/bqVnz2VuQKh6frsBunh0ucIUGzrT+rO/MVpIIrj4H2AiCKigiDigT+oTGcMGJE0lpprrZRqKytrEC1WtOyqeGs98EbBVbFa8UREF896/nfOy8R909S0TWyrftdjOzOZrvPpm5eZzHvum7n17NlN+w83Xq3sdIRMuXmgEJi6acO2LNtIK7B6F9VGNgCEk/ObZRVKmoEwSrKOV7/TxMcXuN/S9p730NbtZ6/7dykTLp7xH+qeO+UvBDb2KD5kZctFCCMtdPKunKa20UzOTNu/FdaGcWIMGTgnRSF+GdY3AAk2CwIBfJR69c27ONSWfE8IkFu7Nm0VRCbtG/aRwgwtPqWvWGwg0d0IGkj8eAru4A+AhUSLwsUy8YfcIAgEm4UAwfqg5P2tsH/B6f1Hd8Hdyf4DZ+SE0vyw0xF4mHul24ccUPMj3mKhWMsqSuIoPFg+CASbhQEJ78YIe3SLTfbdOMqdx8zd4MmbO4GDNoTFAhLLRnAbK756EHoeBAIKBxIqXKk7Yc0YucjNY9qTbYQ0WbQgAo+q2mpWJCBIZMrvJ6x/LqVDd4DgfkBOD2+2e/+BfRsRR5wwt4f1/EC8xAHHT+393YOQf05dspARrRNs23DU4/GYlc/nU3EzOVxAIrgE+efUDSDYCBajPZxzgUe+3gRkxvIFHeU6CRjJ3lPn/rkJq1tAFC24jdWL0NuH+Xyp1Axkwdr82sntLQTe/YiPBPKdrPsneXQFCKNpeZ+3Z6rnSxxIPvAOA3muBZ2mZzoCcSlTvnJ9+Sd5RABihANRpLOnvVMqX7p8OQgEprFSh0AEgOEjF754QP5JHl2wEDnkwemJgeCENTgYBAI8OgSCXuwIADlOeioWG4idUD1lw4CI6hYWovzqIqf3EEgKeCAQpBQFiGDC3TsexuqycK8qbv96Nsm/sqHJnMysaKCTMCm8XnyRHgiH/vLgYHDKms5LL0cEAps1GDfVG1FF100a81pf8RsQ2qJJVw0EgNT9QcVpLDqQE3hesQdiRClbqqoZerQBwcOnnsLbCbXIYcL6kFSwLmYsAUSmFAfIqb1cvds2+XVQyjJj2UYvL+nyjAVAUl786IdhKKzHAgI3v3fv/pFTZ82/5Ien0vGbtl2gTF+MdKwRU4j0W3A3NSjGHoAcLxaLb6GwBH4lOhDy4PVn8ieizcLnCdSQ4pQ7l2JrQkka+RKd9FnKQL7kA4HNxadXM7eKT5XpUBgLyIvXs8kfyE0HldVHqBwS2H7jQvGFBVbUPGf4tF6npL9Cn54/p5w7/raYyVwtDqdKfuHayZGBvBBnpFxu70pk+zDVRFDch4+fYdjZwZTl2pYn2wwCUaMDUf8KkEve2D96qLwtjhavZjLF5wXhV2IB+ewS4r74/Jrr84toSBhBILJUw5+hRrT2Q+vm8MMdAPJfWEh98P6op/tvny4qcl29Wrz/qHRZTGPLoybjdz+//jz7M8CAv4BObAuRZbliYHRb5dLAZEKB/IL2fwI5N8oRgDwWRaH7vk8vRQdCXI/GbBOKX3A6UWyEhQDByEFK9XQ6qVDWAkjuPwbCyKLirQyo8rKSGXozdssj8/wR+vSoQIhimq5LxNlOTmd2FywEo5oYo1yY45ILb3ChmElAoPo3QMJXdgwUCgSvxLYMi1mgL2wQRcfBZ4DuHXs5lkiMVSvnK9yJDF72ffqMqEBAFL81X792owHBFDMa/x04EB3Y3KDBrJVQNO6PTagKAAlkt0RhBQ0BgvVMfu922TEjWhi/qxKqZCpvEkOZzPlj9+Dl1dH7g3nw6TO4JkcEIuvFi1hTVk434ctMa3L6F9jcE/Ioj/gvkt5oKUnHGTGz2fR49B801huBMM48WzYMJ81xIRK/A15hlJMKbQbip8V04EoXkOhZLtF/MutrhKBMvyytRzOQUWEg3Cyq98BAOJlKxiNSHB29/G7VGsO2jTVzZsQEEvu2VxuhQuCi/RLxwVVBIhdMMue94qy8Q738UrfMS/DmjKtMmQyEmk5OFS8MXSLid+Cf9iW0GQgdP+6bc1xKHfGDJBxK4T397+X4dlUoypNFRo54HqQy9Pj9vepY4vH5TKZarWZAt4rF0VWGptm2beUsZ05sICweEJNfiEEbEhAhAeRXY4UmxZi7TiIgpxGInCQTxyp4bt52g0Coa6jyefg7xnj/xFSbV6vyo/coWgQGUn32/sOnHeeHEm8ymT1DQ2M+kLnfLQ4CtMbW7Dn9sBAmAwFJZ/8tN7Bek4AQbisdAYErmokIY5NlB4G4duPCyHWwfzr+pthfVs7P2IkePoQ/h0c9IEPfa49qcx8nnlUrj7VVq3wn8t2yVy1ZAVqyZI1mzenjlIVAMMmPTUKBWHou0REQtA/sBkT9DlCODARjdJAYWoj/c+C9eSDtU2c8pg8PDKQ+1i/dhznrsfWhXpsLLuR27l2tdsgDssqy1y9bzeUhWWMZM/psIQxEqI0ftTAgKpS2AhIaXGgLIDje6H4QCJ41kRtg/4zaoYCNDg1k1vDJDRtuDg/PKhTezZ37/kPtWm1ZInGv+izxvV4oAZC5hrWqAjiWTJw4ccmSJU5uTV8tRKGelLI0F4cBAbUHgp5eeoHjHSI9NL4XgWBIVRkzAON9XSdKDdzcsOHklpMDhWuF9Zvnzdu3b/AbABkCW3kO09g3y1k2Bjh8zbHshX0EotqGp18jkUtS1gEQEyJ0xicQhytJiQxEK+umng4ECSo21htO2dAagTQkY7SdsmOpjcBJU/5eWwq37gxIKjV9gE9ahUJhQE28eQ9KPH5ZffO9VqvdB5/+3Vp1+9lq4OHL0Ob0ccpCYTrwdkBU1VsLkvGF4R1cGPqyXCihiiHtGsv9GCPCLNVGC7Gkn4OLJLWQBLMiNZAcQdI5kGsF0LXaD3zze9V77wtPD80FIIa9bGxoxUTUGntO3ywkiGOnSxlpCURzsuI/QWBsJGTrBMNpGZZoCpPi2w1KhePaKQPB8dVMykBU12QggahDRuV5NjIQDIP3FuqVSuU8uBCbAxm7tRiBLJ26dPJfApJz9DZAbOFyWm8u4lMUOV9iYwTOr3obgUguJovXS0CCWYVwEVLu1EDYdB9IqnZYHoFnlWrGU/WWYSx7NnarslgG8vemLLVMWgGxCWUEvloCwUUBXqqZNJhX0a9HIBgR4hIQmhgC0dGto4/ndEhnOnj42qfUNa5a6n1C1puxlz+ZO/vflsIojrOUKjqLaQQhMS9B+OVqSVqqtKnq7UVYvQTbNAvF0JdtnWlTVS8VWtsoMTLdaCMVZUtkRPxvzrlP26fP3PXey1a+xHrdrt3O555znpdzT9FH8tlhrfZbcTyfyWygQBoastptqHY2+0oDoaFaDgjZRiF9mSiQLvfvLxOsBeKR6FXH1wKp9bK9+JgCVqgLZ4XXqDDyYDUGwkvyuwcedyRayzw2arWNTOqWg0dQh5wuxuiSQPBKVLUfguBtFEjQRjOyxH5IrYHpD+qhQMhKF71t5AhzS70yxQq2bxf274DfdjbxWq0NiBQMG8vDXq126b9YXGT67kkDwdypGki7JBCmLkINEDp0dj1zMg2vlcgEQOhkU1oWrfaGZaxjekeVx8oGL52Q/Si6auE0zg8QyQ7VcL5+yHJRIDTNk0TDrC0o1NHD9WiMlV3kRnH88IYKD+2if7G4yHYWnR8ge9mkzi4O0l6M9H3IjVQMkNoey1UnV3EhXjaM1QFSwMxi+QYQvpkRyEbksbbxi4uo2vavdYDUJnWbOiCSw16X5LDXKT3sZX9O5ozSkHXd/3l3sTg2C5W3hrFisWMciWg3gbSER6NDFpGRVwKEiukdC5IFgh5Ak0T9iWFXZWLY/rvZgxI9nZRr/3QHqiiF5POD0wXx7GdtRSsxXjU0ZO2tJnULndUpA8LXzhblPYRZOukSl07gPSkQ+oq40C+1dDLDq+iPq0IX/UgEkfyeQc6+eUNOjpvPrly5ybmJ7uA2bnHRSe6dOc9XbXNDIRBqGDesTjqNskBoW304dp2/4XLXW1y8cd7DW6QCE+VKx9AqtM/wsYNoppMUHlyZKIzjmYIBRlaL9tParAbO1C1E7Ie2KMghjPlIopYBomD5HWcWrCQ8hN1VcXNqddRQIEDGmbg19jl3emLdx49A5KPBAJFqjW5y66rNixroIdLi9yqch7Dbfx5ZIEo2qM7X26Di2M1NOuZVTwSsTlRN78WC//Sbl7CMhQHLsAIMvvXMVCkeX798roGY1AHBaa8MEDpQVgVEdgtXipibnYfQBa6/uWv6ZshMkXQUQRClzIUt/unxjvHxj2bDNuxRNnHG0RqJ5FcvamzIoqIhWQ4ITevyQGy1QPCl6hQ5sC9J9lrYmToNluqXsWq6cl3fFzJPUyYAYdowLX4tFA4bQuE1Cxatike25BLZSARcZE6B3OkNcBKaBQgv+odMDqGCmh0VQAgRW90yIEqElgFRIHR+L7N1K1t2IoRDfvP0dAGEDPx+gxlkMJwMhWKBgG5r87psJNuaiAAQtR5iAvB14tVdaPigMGTZXE6O7ocQ1fUQLB5y2SzKQxYS6fK0V/fD9rKFckTO6jaXCzYmZ3rIH27d3gkIQu/du7kSbuBOkn3c8P4LIbP5cGj/9OeiKxb7kvsS+yI4AunBwYBDACARXy4fSaT+xENmbxc1+nUxApG/g+rEwUPBmkLcE06iIB4Ey0cHJWKfMXiIfK46HuIjVJC+z4nyy9MtDmPwhAfGyZ4TXTicq7xRV01tI3SLBznxYoCyUqJDzHCiOmhHjPLCOqxMJp7IJzIjE70BwQE4dDohMLjLttv1Tg/QXZPC1KOpqalHDuCR1gUGXkKtb+4LFvyuUgckvXPnzjRzw+beV7RG/Wlm6O6A0nsMKdjZiq2lwnL5pNTz2P+SKqaWP8/NPM9uinDK9CmeheiTzecj+dRIbxrcBaAE0uld7ZY2vb7FYvnuEByiBHQQITAxEs++PePPRyIJVUBM3M7t27fvrLkb1vj+xw+xxzbieDI8/HCWSn2TxB+J0+xRnRdiHrPnJV4bxVGxTyVPkHhvGgfVbd2aAEgkkYjEoZo3kr30cgBMDrEJXGEXz3v0LZ7d7klBR4DoAgAkMDAxkkmUzrwFIHGVHkKAgCiPH6/Ei2vg1tDQixfP/8MONaKFq1Jbmcx+VrEyBS5lIEHjnnk2khrJpRGIAEC+u/g2fRvvdkIQg912AIKBLJAWgeSgli6fz6gEwg3uxM7V2CMIf89XP9BBsGXt8xdDQ0P/R09GEyP29hYq63WvNxqOhTkZsaUnCrUuH4FhUxw9JDVSQiA6IQ0e4nLpAYhHAHXpOePo5KQAoQw8BEpNc2emplLHUptVAaGuDh+UjEmSfJoJtKwdRnV3pxsExET+ziDAZiVaa+BNR8PhWCgU8vv9Pl+yp6enT6PR9Pd3dnY2ebl6Ul+uiBpIAA1wElD80kgpIAKB4DToaUMgu+DQ6ub1zndtLZyAAiCXRu6XPh2DnK4GCJ3tYPeTDPxeS3r8IW/vbfAO+Pz77uGH+F3zYXvJix5lrP1iBXnR9jHR9EkwfR+avqnpamc/UWdFVzV9PUmfPyx/W6LKrVvMIZAM8vEEEEmkRia+CGSUBfnb2QJAbsChscXNt/AeN//KIaDuT5A7c9eRUa9qD4n6+o4d639st586dfxedzeEK+gWNNf9aWaanx3/WK95y7YPwVXfiqbvE00vCi0OJPr6enqSSR+CIQ4BXBCEPxSLeq3IUUbMNhanGAigyGQxaqXWlUoCSudAF3mn1+vfpeHI6HG7cLTNv2omxaZTjvsv163LrVmgHoiJ8yb7j9urujcsCrB0D81HBye86r3RqHjZo+3pdU+udFBTU5MGeEAoavX5/GDtMJgb5YVA5Uv2wVOvNgGIVn8oHL1G4FaIyxnXTfcdFetLCsquSMAqNYs0HM0OAYikAcgdtL/eZeOh3Jh3caZRggTmj7rmrQvUAzFxIY2d0QsSrlCDc0nC39oKJq5e950oNKxGNH1SNH0oBsaPer3XrYwTWaMxv68HQMB3NWkwNMWi16ys88mNtWhpnfrmf58upcBDIvnMS51IA9ZPEEx6EHngFKRL/66lraWNbxO7km7VIROHbs0i9UBMnL+TcDhlPwWCfzVDe0A46O2eS//waq6i7SHAVGwfDkcve2kSxsvcyGQTUzQcEkFcRWn6kugRXsYhFFCQnBSqbP4HzUzwts5LpclmoIEaRTcIpO8AINTkqBEU1O8VGykvXbN14ULEoQ4Iy4MKsghJI7fmNlahpCfkM9K71VsB0Ulikw9yhJUOtehzVaqmrFXtsmIv9s7I0eNmnYByMJriVHS2niVedVZwHADhP0gkOyzq6ZymEGPV+hJ5npjaG41VPaJfQ5M1HX5ITfnVTAot7aJsB1U3u7vT2zvAUTnKuZ1R818CwTjST3gQGmU9tschXkEKmb9ZCLOicb0SmiClo0e0okdcY6kRcDOWZFTrSFlB7i81qpsPICYuSXgcOGU/QAXHdg2ErMVRvJrnT1brNeIR6BIaMnwNg0NUAppRTlwjxbpmsyDKMadA0EGIfyz7cO7DsjKOZRPw+JTdrjl27K3158/5+q29PjqXAEHGhrETyKdCoT/1zL/3/GaHFBCHciBrKRA2o6N/LHmDIkQqj5FU8ufP69y8yMSFcbLBqkmlrib/4UrbKJkAPmJ4jCKQtYqALP3Vzh2+NBHGARx/NnZw3G1z5TxFEUZaKBOCgzGKUOq3Fb3JC/G6EbKCkBrWi8y9imL0VI6FgQgDN1AUYW8c7dYb/7ue5+bu1rxqKt4kfp8dx/N6X37bPbttrs/KihUEPvO/K6/u8R7AFux4CroVRL04rxfPTe2jZMrgMYyUw2ionER6IcSTJ3vMrgEXqFZqUKu8Ah6ktf5iBcnuXIIPey+rotFizUjRilNUOYn0xOcyIO/9AEApFUWY00V5jpNFdhJlnQUpZQcvMkii+3CWHY+Ow+XUP9tGsWjwKMcne0R8pDeS2+9PckCPzXXTS/KD9CeckL8E4QmYlF2kmFLtATn9dRYPkgWN0kKhQCl099BX2PcPIs9U9K8gphPE2E76SK+kePJkkMJWgRY+ugWhzzNHR/cjKnIXbqYY3qKRMriUaRab4bhAzlyEB7ke+s5GpP2SJdfs3Ujp8WwufW8BR+QPEg3DbJim4QQx63vlzbGx6JRwxiJ8L5CD/dAQpe0BqVUqFfF4QuBhJh1ZwiBu+BtrvXx4eLjb5EHCBtMsL1vW18eDvRfputRaDNBvW18p3xu2yGK11h6R9J39TCaCb+quVgc35rmNsaYR5lfA9c3llnF7RHpMEleTbQl1jR4cUJbDxoIA8AWApq0N/dxXk+ikl/O2jb1GYtuos8mwYgTJaUmSz6FkSxroutOj8uTdzMzqj9VHzNHdyIQPuRgd7sTuRd2IDkd5jHMb8ecBfitSre/s7L5llhYyt2MEeUmYuPbmltZZBMRqucQXJUb7MEWQl4SbE1cLGjhFxGqlKlq7QmDyikCQ1xT7Di5rIpf5PkRngELuygBBngsqebBYSXQrBwDQ6RdXRgjymiDZRXQ+JlYOpkSnp6MEeW405BThTdo0FoQg7wmhkEBILAA2nWfJ+5WpSYL6QApJ7ByMBfLQls/6FazRNwKxBEeGFTng9wf8ihILEnQZCAOTkwNB3HsghBBCCCGEEELoP/cLoEBEqwRkrqYAAAAASUVORK5CYII=\" />\r\n\r\nTo celebrate, we’re running a sale with as much as <strong>65% off our paid plans</strong>.\r\n<br><br>\r\nGrab it while the party lasts! (<strong>Hurry! This offer won\'t last long!</strong>) 🎉', 'success', '[\"4-x\",\"lite\"]', 346, NULL, '2022-06-28 14:12:59', '2022-06-30 00:00:00', 'Get AIOSEO Pro NOW! (65% OFF)', 'https://aioseo.com/pricing-lite/?utm_source=WordPress&utm_campaign=15th-birthday-sale-v4-lite&utm_medium=plugin-notification&utm_content=Get AIOSEO Pro NOW! (65% OFF)', NULL, NULL, 0, 1, '2022-06-23 14:32:35', '2022-06-28 14:39:11'),
(6, '62bb128fc2307', 'LAST CHANCE: Our Birthday Celebration is Almost Over! ⌛', 'AIOSEO just turned <strong>15 years old</strong> and we\'ve been celebrating all week with as much as <strong>65% off our paid plans</strong>! 🥳\r\n<br><br>\r\nThe party’s almost over and you’re about to miss out on this amazing birthday celebration deal.\r\n<br><br>\r\nMake sure to grab yours ASAP because it <strong>expires today!</strong> 🎉 🎉', 'success', '[\"4-x\",\"lite\"]', 399, NULL, '2022-06-29 00:00:00', '2022-06-30 00:00:00', 'Get AIOSEO Pro NOW! (65% OFF)', 'https://aioseo.com/pricing-lite/?utm_source=WordPress&utm_campaign=15th-birthday-sale-last-chance-v4-lite&utm_medium=plugin-notification&utm_content=Get%20AIOSEO%20Pro%20NOW!%20(65%%20OFF)', NULL, NULL, 0, 1, '2022-06-28 14:39:11', '2022-06-28 14:39:11');

-- --------------------------------------------------------

--
-- Table structure for table `wp_aioseo_posts`
--

CREATE TABLE `wp_aioseo_posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keyphrases` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_analysis` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `canonical_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_object_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `og_image_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `og_image_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image_width` int(11) DEFAULT NULL,
  `og_image_height` int(11) DEFAULT NULL,
  `og_image_custom_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_custom_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_article_section` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_article_tags` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_use_og` tinyint(1) DEFAULT 0,
  `twitter_card` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `twitter_image_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `twitter_image_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_custom_url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_title` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_score` int(11) NOT NULL DEFAULT 0,
  `schema_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `schema_type_options` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pillar_content` tinyint(1) DEFAULT NULL,
  `robots_default` tinyint(1) NOT NULL DEFAULT 1,
  `robots_noindex` tinyint(1) NOT NULL DEFAULT 0,
  `robots_noarchive` tinyint(1) NOT NULL DEFAULT 0,
  `robots_nosnippet` tinyint(1) NOT NULL DEFAULT 0,
  `robots_nofollow` tinyint(1) NOT NULL DEFAULT 0,
  `robots_noimageindex` tinyint(1) NOT NULL DEFAULT 0,
  `robots_noodp` tinyint(1) NOT NULL DEFAULT 0,
  `robots_notranslate` tinyint(1) NOT NULL DEFAULT 0,
  `robots_max_snippet` int(11) DEFAULT NULL,
  `robots_max_videopreview` int(11) DEFAULT NULL,
  `robots_max_imagepreview` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'large',
  `tabs` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_scan_date` datetime DEFAULT NULL,
  `priority` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequency` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `videos` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_thumbnail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_scan_date` datetime DEFAULT NULL,
  `local_seo` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `limit_modified_date` tinyint(1) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_aioseo_posts`
--

INSERT INTO `wp_aioseo_posts` (`id`, `post_id`, `title`, `description`, `keywords`, `keyphrases`, `page_analysis`, `canonical_url`, `og_title`, `og_description`, `og_object_type`, `og_image_type`, `og_image_url`, `og_image_width`, `og_image_height`, `og_image_custom_url`, `og_image_custom_fields`, `og_video`, `og_custom_url`, `og_article_section`, `og_article_tags`, `twitter_use_og`, `twitter_card`, `twitter_image_type`, `twitter_image_url`, `twitter_image_custom_url`, `twitter_image_custom_fields`, `twitter_title`, `twitter_description`, `seo_score`, `schema_type`, `schema_type_options`, `pillar_content`, `robots_default`, `robots_noindex`, `robots_noarchive`, `robots_nosnippet`, `robots_nofollow`, `robots_noimageindex`, `robots_noodp`, `robots_notranslate`, `robots_max_snippet`, `robots_max_videopreview`, `robots_max_imagepreview`, `tabs`, `images`, `image_scan_date`, `priority`, `frequency`, `videos`, `video_thumbnail`, `video_scan_date`, `local_seo`, `limit_modified_date`, `created`, `updated`) VALUES
(1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, NULL, '2022-05-27 04:43:05', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-05-27 04:43:05', '2022-05-27 04:43:05'),
(2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, NULL, '2022-05-27 04:43:05', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-05-27 04:43:05', '2022-05-27 04:43:05'),
(3, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, NULL, '2022-05-27 04:43:05', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-05-27 04:43:05', '2022-05-27 04:43:05'),
(4, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, 'default', NULL, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, NULL, '2022-05-27 04:43:05', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-05-27 04:43:05', '2022-05-27 04:43:05'),
(5, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, 'default', NULL, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, NULL, '2022-05-27 04:43:05', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-05-27 04:43:05', '2022-05-27 04:43:05'),
(6, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, 'default', NULL, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, NULL, '2022-05-27 04:43:05', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-05-27 04:43:05', '2022-05-27 04:43:05'),
(7, 12, NULL, NULL, '[]', '{\"focus\":{\"keyphrase\":\"\",\"score\":0,\"analysis\":{\"keyphraseInTitle\":{\"score\":0,\"maxScore\":9,\"error\":1}}},\"additional\":[]}', '{\"analysis\":{\"basic\":{\"lengthContent\":{\"error\":1,\"title\":\"No content yet\",\"description\":\"Please add some content first.\",\"score\":1,\"maxScore\":5}},\"title\":{\"titleLength\":{\"title\":\"SEO Title length\",\"description\":\"The title is too short.\",\"score\":6,\"maxScore\":9,\"error\":1},\"errors\":1},\"readability\":{\"contentHasAssets\":{\"error\":1,\"title\":\"No content yet\",\"description\":\"Please add some content first.\",\"score\":1,\"maxScore\":5}}}}', NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '[]', 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 67, 'default', '{\"article\":{\"articleType\":\"BlogPosting\"},\"course\":{\"name\":\"\",\"description\":\"\",\"provider\":\"\"},\"faq\":{\"pages\":[]},\"product\":{\"reviews\":[]},\"recipe\":{\"ingredients\":[],\"instructions\":[],\"keywords\":[]},\"software\":{\"reviews\":[],\"operatingSystems\":[]},\"webPage\":{\"webPageType\":\"WebPage\"}}', 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, -1, 'large', '{\"tab\":\"general\",\"tab_social\":\"facebook\",\"tab_sidebar\":\"general\",\"tab_modal\":\"general\",\"tab_modal_social\":\"facebook\"}', '[{\"image:loc\":\"http:\\/\\/upmsmemart.com\\/wp-content\\/uploads\\/2022\\/05\\/boutique_48-1.jpg\",\"image:title\":\"boutique_48-1\",\"image:caption\":\"\"},{\"image:loc\":\"http:\\/\\/upmsmemart.com\\/wp-content\\/uploads\\/2022\\/05\\/boutique_49-1.jpg\",\"image:title\":\"boutique_49-1\",\"image:caption\":\"\"},{\"image:loc\":\"http:\\/\\/upmsmemart.com\\/wp-content\\/uploads\\/2022\\/05\\/boutique_49.jpg\",\"image:title\":\"boutique_49\",\"image:caption\":\"\"},{\"image:loc\":\"http:\\/\\/upmsmemart.com\\/wp-content\\/uploads\\/2022\\/05\\/boutique_04.jpg\",\"image:title\":\"boutique_04\",\"image:caption\":\"\"},{\"image:loc\":\"http:\\/\\/upmsmemart.com\\/wp-content\\/uploads\\/2022\\/05\\/boutique_47.png\",\"image:title\":\"boutique_47\",\"image:caption\":\"\"}]', '2022-05-27 07:56:42', 'default', 'default', NULL, NULL, NULL, NULL, 0, '2022-05-27 04:58:36', '2022-05-27 07:56:42'),
(8, 24, NULL, '#post_title #separator_sa #taxonomy_title', '[]', '{\"focus\":{\"keyphrase\":\"\",\"score\":0,\"analysis\":{\"keyphraseInTitle\":{\"score\":0,\"maxScore\":9,\"error\":1}}},\"additional\":[]}', '{\"analysis\":{\"basic\":{\"metadescriptionLength\":{\"title\":\"Meta description length\",\"description\":\"The meta description is too short.\",\"score\":6,\"maxScore\":9,\"error\":1},\"lengthContent\":{\"title\":\"Content length\",\"description\":\"This is far below the recommended minimum of words.\",\"score\":-20,\"maxScore\":9,\"error\":1},\"isInternalLink\":{\"title\":\"Internal links\",\"description\":\"We couldn\'t find any internal links in your content. Add internal links in your content.\",\"score\":3,\"maxScore\":9,\"error\":1},\"isExternalLink\":{\"title\":\"External links\",\"description\":\"No outbound links were found. Link out to external resources.\",\"score\":3,\"maxScore\":9,\"error\":1},\"errors\":4},\"title\":{\"titleLength\":{\"title\":\"SEO Title length\",\"description\":\"The title is too short.\",\"score\":6,\"maxScore\":9,\"error\":1},\"errors\":1},\"readability\":{\"contentHasAssets\":{\"error\":1,\"title\":\"Images\\/videos in content\",\"description\":\"You are not using rich media like images or videos.\",\"score\":1,\"maxScore\":5},\"paragraphLength\":{\"title\":\"Paragraphs length\",\"description\":\"You are using short paragraphs.\",\"score\":5,\"maxScore\":5,\"error\":0},\"sentenceLength\":{\"title\":\"Sentences length\",\"description\":\"Sentence length is looking great!\",\"score\":9,\"maxScore\":9,\"error\":0},\"passiveVoice\":{\"title\":\"Passive voice\",\"description\":\"You\'re using enough active voice. That\'s great!\",\"score\":9,\"maxScore\":9,\"error\":0},\"transitionWords\":[],\"consecutiveSentences\":{\"title\":\"Consecutive sentences\",\"description\":\"There is enough variety in your sentences. That\'s great!\",\"score\":9,\"maxScore\":9,\"error\":0},\"subheadingsDistribution\":{\"title\":\"Subheading distribution\",\"description\":\"You are not using any subheadings, but your text is short enough and probably doesn\'t need them.\",\"score\":9,\"maxScore\":9,\"error\":0},\"calculateFleschReading\":{\"title\":\"Flesch reading ease\",\"description\":\"The copy scores 0 in the test, which is considered very difficult to read. Try to make shorter sentences, using less difficult words to improve readability.\",\"score\":3,\"maxScore\":9,\"error\":1},\"errors\":2}}}', NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '[]', 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 64, 'default', '{\"article\":{\"articleType\":\"BlogPosting\"},\"course\":{\"name\":\"\",\"description\":\"\",\"provider\":\"\"},\"faq\":{\"pages\":[]},\"product\":{\"reviews\":[]},\"recipe\":{\"ingredients\":[],\"instructions\":[],\"keywords\":[]},\"software\":{\"reviews\":[],\"operatingSystems\":[]},\"webPage\":{\"webPageType\":\"WebPage\"}}', 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, -1, 'large', '{\"tab\":\"general\",\"tab_social\":\"facebook\",\"tab_sidebar\":\"general\",\"tab_modal\":\"general\",\"tab_modal_social\":\"facebook\"}', '[{\"image:loc\":\"http:\\/\\/upmsmemart.com\\/wp-content\\/uploads\\/2022\\/05\\/boutique_49-1.jpg\",\"image:title\":\"boutique_49-1\",\"image:caption\":\"\"}]', '2022-05-27 07:56:42', 'default', 'default', NULL, NULL, NULL, NULL, 0, '2022-05-27 07:41:47', '2022-05-27 07:56:42');

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-05-27 04:18:25', '2022-05-27 04:18:25', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_litespeed_url`
--

CREATE TABLE `wp_litespeed_url` (
  `id` bigint(20) NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cache_tags` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_litespeed_url_file`
--

CREATE TABLE `wp_litespeed_url_file` (
  `id` bigint(20) NOT NULL,
  `url_id` bigint(20) NOT NULL,
  `vary` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5 of final vary',
  `filename` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5 of file content',
  `type` tinyint(4) NOT NULL COMMENT 'css=1,js=2,ccss=3,ucss=4',
  `expired` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://upmsmemart.com', 'yes'),
(2, 'home', 'http://upmsmemart.com', 'yes'),
(3, 'blogname', 'UP MSME Mart', 'yes'),
(4, 'blogdescription', 'Online store', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'upmsmemart@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:19:\"Hostinger/index.php\";i:1;s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";i:2;s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";i:3;s:50:\"google-analytics-for-wordpress/googleanalytics.php\";i:4;s:35:\"litespeed-cache/litespeed-cache.php\";i:5;s:37:\"optinmonster/optin-monster-wp-api.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:24:\"wpforms-lite/wpforms.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'Divi', 'yes'),
(41, 'stylesheet', 'Divi', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '51917', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:3:{s:35:\"litespeed-cache/litespeed-cache.php\";s:47:\"LiteSpeed\\Activation::uninstall_litespeed_cache\";s:37:\"optinmonster/optin-monster-wp-api.php\";s:32:\"optin_monster_api_uninstall_hook\";s:50:\"google-analytics-for-wordpress/googleanalytics.php\";s:35:\"monsterinsights_lite_uninstall_hook\";}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '12', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1669177104', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:121:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:17:\"aioseo_manage_seo\";b:1;s:17:\"et_support_center\";b:1;s:24:\"et_support_center_system\";b:1;s:31:\"et_support_center_remote_access\";b:1;s:31:\"et_support_center_documentation\";b:1;s:27:\"et_support_center_safe_mode\";b:1;s:22:\"et_support_center_logs\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '1', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:9:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:9:\"sidebar-3\";a:0:{}s:9:\"sidebar-4\";a:0:{}s:9:\"sidebar-5\";a:0:{}s:9:\"sidebar-6\";a:0:{}s:9:\"sidebar-7\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:20:{i:1656907432;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1656907465;a:2:{s:27:\"litespeed_task_imgoptm_pull\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:16:\"litespeed_filter\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}s:19:\"litespeed_task_lqip\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:16:\"litespeed_filter\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1656908306;a:6:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1656908333;a:1:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1656908343;a:2:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1656908605;a:1:{s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1656909719;a:2:{s:21:\"ai1wm_storage_cleanup\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1656909724;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1656909743;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1656909746;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1656911017;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1656919133;a:2:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:31:\"woocommerce_cleanup_rate_limits\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1656929933;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1656943200;a:1:{s:28:\"wpforms_email_summaries_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:30:\"wpforms_email_summaries_weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1656979200;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1657340306;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1657411503;a:1:{s:35:\"monsterinsights_usage_tracking_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1657513193;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}i:1658811459;a:1:{s:32:\"et_core_page_resource_auto_clear\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2592000;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(120, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.0.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.0.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-6.0-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-6.0-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"6.0\";s:7:\"version\";s:3:\"6.0\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.9\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1656865678;s:15:\"version_checked\";s:3:\"6.0\";s:12:\"translations\";a:0:{}}', 'no'),
(125, 'litespeed.conf.__activation', '-1', 'yes'),
(126, 'litespeed.purge.queue', '-1', 'yes'),
(127, 'litespeed.purge.queue2', '-1', 'yes'),
(128, 'recently_activated', 'a:2:{s:35:\"litespeed-cache/litespeed-cache.php\";i:1653625116;i:0;b:0;}', 'yes'),
(129, 'litespeed.cloud._summary', '{\"curr_request.ver\":0,\"last_request.ver\":1653625403}', 'yes'),
(130, 'litespeed.conf._version', '4.6', 'yes'),
(131, 'litespeed.conf.hash', 'YlbuVK726gU8pReXHcUwMRe0DQ7kgoHH', 'yes'),
(132, 'litespeed.conf.auto_upgrade', '', 'yes'),
(133, 'litespeed.conf.api_key', '', 'yes'),
(134, 'litespeed.conf.server_ip', '', 'yes'),
(135, 'litespeed.conf.guest', '', 'yes'),
(136, 'litespeed.conf.guest_optm', '', 'yes'),
(137, 'litespeed.conf.news', '1', 'yes'),
(138, 'litespeed.conf.guest_uas', '[\"Lighthouse\",\"GTmetrix\",\"Google\",\"Pingdom\",\"bot\",\"PTST\",\"HeadlessChrome\"]', 'yes'),
(139, 'litespeed.conf.guest_ips', '[\"208.70.247.157\",\"172.255.48.130\",\"172.255.48.131\",\"172.255.48.132\",\"172.255.48.133\",\"172.255.48.134\",\"172.255.48.135\",\"172.255.48.136\",\"172.255.48.137\",\"172.255.48.138\",\"172.255.48.139\",\"172.255.48.140\",\"172.255.48.141\",\"172.255.48.142\",\"172.255.48.143\",\"172.255.48.144\",\"172.255.48.145\",\"172.255.48.146\",\"172.255.48.147\",\"52.229.122.240\",\"104.214.72.101\",\"13.66.7.11\",\"13.85.24.83\",\"13.85.24.90\",\"13.85.82.26\",\"40.74.242.253\",\"40.74.243.13\",\"40.74.243.176\",\"104.214.48.247\",\"157.55.189.189\",\"104.214.110.135\",\"70.37.83.240\",\"65.52.36.250\",\"13.78.216.56\",\"52.162.212.163\",\"23.96.34.105\",\"65.52.113.236\",\"172.255.61.34\",\"172.255.61.35\",\"172.255.61.36\",\"172.255.61.37\",\"172.255.61.38\",\"172.255.61.39\",\"172.255.61.40\",\"104.41.2.19\",\"191.235.98.164\",\"191.235.99.221\",\"191.232.194.51\",\"52.237.235.185\",\"52.237.250.73\",\"52.237.236.145\",\"104.211.143.8\",\"104.211.165.53\",\"52.172.14.87\",\"40.83.89.214\",\"52.175.57.81\",\"20.188.63.151\",\"20.52.36.49\",\"52.246.165.153\",\"51.144.102.233\",\"13.76.97.224\",\"102.133.169.66\",\"52.231.199.170\",\"13.53.162.7\",\"40.123.218.94\"]', 'yes'),
(140, 'litespeed.conf.cache', '1', 'yes'),
(141, 'litespeed.conf.cache-priv', '1', 'yes'),
(142, 'litespeed.conf.cache-commenter', '1', 'yes'),
(143, 'litespeed.conf.cache-rest', '1', 'yes'),
(144, 'litespeed.conf.cache-page_login', '1', 'yes'),
(145, 'litespeed.conf.cache-favicon', '1', 'yes'),
(146, 'litespeed.conf.cache-resources', '1', 'yes'),
(147, 'litespeed.conf.cache-mobile', '', 'yes'),
(148, 'litespeed.conf.cache-mobile_rules', '[\"Mobile\",\"Android\",\"Silk\\/\",\"Kindle\",\"BlackBerry\",\"Opera Mini\",\"Opera Mobi\"]', 'yes'),
(149, 'litespeed.conf.cache-browser', '', 'yes'),
(150, 'litespeed.conf.cache-exc_useragents', '[]', 'yes'),
(151, 'litespeed.conf.cache-exc_cookies', '[]', 'yes'),
(152, 'litespeed.conf.cache-exc_qs', '[]', 'yes'),
(153, 'litespeed.conf.cache-exc_cat', '[]', 'yes'),
(154, 'litespeed.conf.cache-exc_tag', '[]', 'yes'),
(155, 'litespeed.conf.cache-force_uri', '[]', 'yes'),
(156, 'litespeed.conf.cache-force_pub_uri', '[]', 'yes'),
(157, 'litespeed.conf.cache-priv_uri', '[]', 'yes'),
(158, 'litespeed.conf.cache-exc', '[]', 'yes'),
(159, 'litespeed.conf.cache-exc_roles', '[]', 'yes'),
(160, 'litespeed.conf.cache-drop_qs', '[\"fbclid\",\"gclid\",\"utm*\",\"_ga\"]', 'yes'),
(161, 'litespeed.conf.cache-ttl_pub', '604800', 'yes'),
(162, 'litespeed.conf.cache-ttl_priv', '1800', 'yes'),
(163, 'litespeed.conf.cache-ttl_frontpage', '604800', 'yes'),
(164, 'litespeed.conf.cache-ttl_feed', '604800', 'yes'),
(165, 'litespeed.conf.cache-ttl_rest', '604800', 'yes'),
(166, 'litespeed.conf.cache-ttl_browser', '31557600', 'yes'),
(167, 'litespeed.conf.cache-ttl_status', '[\"403 3600\",\"404 3600\",\"500 3600\"]', 'yes'),
(168, 'litespeed.conf.cache-login_cookie', '', 'yes'),
(169, 'litespeed.conf.cache-vary_group', '[]', 'yes'),
(170, 'litespeed.conf.purge-upgrade', '1', 'yes'),
(171, 'litespeed.conf.purge-stale', '', 'yes'),
(172, 'litespeed.conf.purge-post_all', '', 'yes'),
(173, 'litespeed.conf.purge-post_f', '1', 'yes'),
(174, 'litespeed.conf.purge-post_h', '1', 'yes'),
(175, 'litespeed.conf.purge-post_p', '1', 'yes'),
(176, 'litespeed.conf.purge-post_pwrp', '1', 'yes'),
(177, 'litespeed.conf.purge-post_a', '1', 'yes'),
(178, 'litespeed.conf.purge-post_y', '', 'yes'),
(179, 'litespeed.conf.purge-post_m', '1', 'yes'),
(180, 'litespeed.conf.purge-post_d', '', 'yes'),
(181, 'litespeed.conf.purge-post_t', '1', 'yes'),
(182, 'litespeed.conf.purge-post_pt', '1', 'yes'),
(183, 'litespeed.conf.purge-timed_urls', '[]', 'yes'),
(184, 'litespeed.conf.purge-timed_urls_time', '', 'yes'),
(185, 'litespeed.conf.purge-hook_all', '[\"switch_theme\",\"wp_create_nav_menu\",\"wp_update_nav_menu\",\"wp_delete_nav_menu\",\"create_term\",\"edit_terms\",\"delete_term\",\"add_link\",\"edit_link\",\"delete_link\"]', 'yes'),
(186, 'litespeed.conf.esi', '', 'yes'),
(187, 'litespeed.conf.esi-cache_admbar', '1', 'yes'),
(188, 'litespeed.conf.esi-cache_commform', '1', 'yes'),
(189, 'litespeed.conf.esi-nonce', '[\"stats_nonce\",\"subscribe_nonce\"]', 'yes'),
(190, 'litespeed.conf.util-instant_click', '', 'yes'),
(191, 'litespeed.conf.util-no_https_vary', '', 'yes'),
(192, 'litespeed.conf.debug-disable_all', '', 'yes'),
(193, 'litespeed.conf.debug', '', 'yes'),
(194, 'litespeed.conf.debug-ips', '[\"127.0.0.1\"]', 'yes'),
(195, 'litespeed.conf.debug-level', '', 'yes'),
(196, 'litespeed.conf.debug-filesize', '3', 'yes'),
(197, 'litespeed.conf.debug-cookie', '', 'yes'),
(198, 'litespeed.conf.debug-collaps_qs', '', 'yes'),
(199, 'litespeed.conf.debug-inc', '[]', 'yes'),
(200, 'litespeed.conf.debug-exc', '[]', 'yes'),
(201, 'litespeed.conf.db_optm-revisions_max', '0', 'yes'),
(202, 'litespeed.conf.db_optm-revisions_age', '0', 'yes'),
(203, 'litespeed.conf.optm-css_min', '', 'yes'),
(204, 'litespeed.conf.optm-css_comb', '', 'yes'),
(205, 'litespeed.conf.optm-css_comb_ext_inl', '1', 'yes'),
(206, 'litespeed.conf.optm-ucss', '', 'yes'),
(207, 'litespeed.conf.optm-ucss_inline', '', 'yes'),
(208, 'litespeed.conf.optm-ucss_whitelist', '[]', 'yes'),
(209, 'litespeed.conf.optm-ucss_exc', '[]', 'yes'),
(210, 'litespeed.conf.optm-css_exc', '[]', 'yes'),
(211, 'litespeed.conf.optm-js_min', '', 'yes'),
(212, 'litespeed.conf.optm-js_comb', '', 'yes'),
(213, 'litespeed.conf.optm-js_comb_ext_inl', '1', 'yes'),
(214, 'litespeed.conf.optm-js_exc', '[\"jquery.js\",\"jquery.min.js\"]', 'yes'),
(215, 'litespeed.conf.optm-html_min', '', 'yes'),
(216, 'litespeed.conf.optm-html_lazy', '[]', 'yes'),
(217, 'litespeed.conf.optm-qs_rm', '', 'yes'),
(218, 'litespeed.conf.optm-ggfonts_rm', '', 'yes'),
(219, 'litespeed.conf.optm-css_async', '', 'yes'),
(220, 'litespeed.conf.optm-ccss_per_url', '', 'yes'),
(221, 'litespeed.conf.optm-ccss_sep_posttype', '[\"page\"]', 'yes'),
(222, 'litespeed.conf.optm-ccss_sep_uri', '[]', 'yes'),
(223, 'litespeed.conf.optm-css_async_inline', '1', 'yes'),
(224, 'litespeed.conf.optm-css_font_display', '', 'yes'),
(225, 'litespeed.conf.optm-js_defer', '', 'yes'),
(226, 'litespeed.conf.optm-emoji_rm', '', 'yes'),
(227, 'litespeed.conf.optm-noscript_rm', '', 'yes'),
(228, 'litespeed.conf.optm-ggfonts_async', '', 'yes'),
(229, 'litespeed.conf.optm-exc_roles', '[]', 'yes'),
(230, 'litespeed.conf.optm-ccss_con', '', 'yes'),
(231, 'litespeed.conf.optm-js_defer_exc', '[\"jquery.js\",\"jquery.min.js\",\"gtm.js\",\"analytics.js\"]', 'yes'),
(232, 'litespeed.conf.optm-gm_js_exc', '[]', 'yes'),
(233, 'litespeed.conf.optm-dns_prefetch', '[]', 'yes'),
(234, 'litespeed.conf.optm-dns_prefetch_ctrl', '', 'yes'),
(235, 'litespeed.conf.optm-exc', '[]', 'yes'),
(236, 'litespeed.conf.optm-guest_only', '1', 'yes'),
(237, 'litespeed.conf.object', '', 'yes'),
(238, 'litespeed.conf.object-kind', '', 'yes'),
(239, 'litespeed.conf.object-host', 'localhost', 'yes'),
(240, 'litespeed.conf.object-port', '11211', 'yes'),
(241, 'litespeed.conf.object-life', '360', 'yes'),
(242, 'litespeed.conf.object-persistent', '1', 'yes'),
(243, 'litespeed.conf.object-admin', '1', 'yes'),
(244, 'litespeed.conf.object-transients', '1', 'yes'),
(245, 'litespeed.conf.object-db_id', '0', 'yes'),
(246, 'litespeed.conf.object-user', '', 'yes'),
(247, 'litespeed.conf.object-pswd', '', 'yes'),
(248, 'litespeed.conf.object-global_groups', '[\"users\",\"userlogins\",\"useremail\",\"userslugs\",\"usermeta\",\"user_meta\",\"site-transient\",\"site-options\",\"site-lookup\",\"site-details\",\"blog-lookup\",\"blog-details\",\"blog-id-cache\",\"rss\",\"global-posts\",\"global-cache-test\"]', 'yes'),
(249, 'litespeed.conf.object-non_persistent_groups', '[\"comment\",\"counts\",\"plugins\",\"wc_session_id\"]', 'yes'),
(250, 'litespeed.conf.discuss-avatar_cache', '', 'yes'),
(251, 'litespeed.conf.discuss-avatar_cron', '', 'yes'),
(252, 'litespeed.conf.discuss-avatar_cache_ttl', '604800', 'yes'),
(253, 'litespeed.conf.optm-localize', '', 'yes'),
(254, 'litespeed.conf.optm-localize_domains', '[\"### Popular scripts ###\",\"https:\\/\\/platform.twitter.com\\/widgets.js\",\"https:\\/\\/connect.facebook.net\\/en_US\\/fbevents.js\"]', 'yes'),
(255, 'litespeed.conf.media-lazy', '', 'yes'),
(256, 'litespeed.conf.media-lazy_placeholder', '', 'yes'),
(257, 'litespeed.conf.media-placeholder_resp', '', 'yes'),
(258, 'litespeed.conf.media-placeholder_resp_color', '#cfd4db', 'yes'),
(259, 'litespeed.conf.media-placeholder_resp_svg', '<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\"><rect width=\"100%\" height=\"100%\" style=\"fill:{color};fill-opacity: 0.1;\"/></svg>', 'yes'),
(260, 'litespeed.conf.media-lqip', '', 'yes'),
(261, 'litespeed.conf.media-lqip_qual', '4', 'yes'),
(262, 'litespeed.conf.media-lqip_min_w', '150', 'yes'),
(263, 'litespeed.conf.media-lqip_min_h', '150', 'yes'),
(264, 'litespeed.conf.media-placeholder_resp_async', '1', 'yes'),
(265, 'litespeed.conf.media-iframe_lazy', '', 'yes'),
(266, 'litespeed.conf.media-add_missing_sizes', '', 'yes'),
(267, 'litespeed.conf.media-lazy_exc', '[]', 'yes'),
(268, 'litespeed.conf.media-lazy_cls_exc', '[\"wmu-preview-img\"]', 'yes'),
(269, 'litespeed.conf.media-lazy_parent_cls_exc', '[]', 'yes'),
(270, 'litespeed.conf.media-iframe_lazy_cls_exc', '[]', 'yes'),
(271, 'litespeed.conf.media-iframe_lazy_parent_cls_exc', '[]', 'yes'),
(272, 'litespeed.conf.media-lazy_uri_exc', '[]', 'yes'),
(273, 'litespeed.conf.media-lqip_exc', '[]', 'yes'),
(274, 'litespeed.conf.img_optm-auto', '', 'yes'),
(275, 'litespeed.conf.img_optm-cron', '1', 'yes'),
(276, 'litespeed.conf.img_optm-ori', '1', 'yes'),
(277, 'litespeed.conf.img_optm-rm_bkup', '', 'yes'),
(278, 'litespeed.conf.img_optm-webp', '1', 'yes'),
(279, 'litespeed.conf.img_optm-lossless', '', 'yes'),
(280, 'litespeed.conf.img_optm-exif', '1', 'yes'),
(281, 'litespeed.conf.img_optm-webp_replace', '', 'yes'),
(282, 'litespeed.conf.img_optm-webp_attr', '[\"img.src\",\"div.data-thumb\",\"img.data-src\",\"div.data-large_image\",\"img.retina_logo_url\",\"div.data-parallax-image\",\"video.poster\"]', 'yes'),
(283, 'litespeed.conf.img_optm-webp_replace_srcset', '', 'yes'),
(284, 'litespeed.conf.img_optm-jpg_quality', '82', 'yes'),
(285, 'litespeed.conf.crawler', '', 'yes'),
(286, 'litespeed.conf.crawler-usleep', '500', 'yes'),
(287, 'litespeed.conf.crawler-run_duration', '400', 'yes'),
(288, 'litespeed.conf.crawler-run_interval', '600', 'yes'),
(289, 'litespeed.conf.crawler-crawl_interval', '302400', 'yes'),
(290, 'litespeed.conf.crawler-threads', '3', 'yes'),
(291, 'litespeed.conf.crawler-timeout', '30', 'yes'),
(292, 'litespeed.conf.crawler-load_limit', '1', 'yes'),
(293, 'litespeed.conf.crawler-sitemap', '', 'yes'),
(294, 'litespeed.conf.crawler-drop_domain', '1', 'yes'),
(295, 'litespeed.conf.crawler-map_timeout', '120', 'yes'),
(296, 'litespeed.conf.crawler-roles', '[]', 'yes'),
(297, 'litespeed.conf.crawler-cookies', '[]', 'yes'),
(298, 'litespeed.conf.misc-heartbeat_front', '', 'yes'),
(299, 'litespeed.conf.misc-heartbeat_front_ttl', '60', 'yes'),
(300, 'litespeed.conf.misc-heartbeat_back', '', 'yes'),
(301, 'litespeed.conf.misc-heartbeat_back_ttl', '60', 'yes'),
(302, 'litespeed.conf.misc-heartbeat_editor', '', 'yes'),
(303, 'litespeed.conf.misc-heartbeat_editor_ttl', '15', 'yes'),
(304, 'litespeed.conf.cdn', '', 'yes'),
(305, 'litespeed.conf.cdn-ori', '[]', 'yes'),
(306, 'litespeed.conf.cdn-ori_dir', '[\"wp-content\",\"wp-includes\"]', 'yes'),
(307, 'litespeed.conf.cdn-exc', '[]', 'yes'),
(308, 'litespeed.conf.cdn-quic', '', 'yes'),
(309, 'litespeed.conf.cdn-cloudflare', '', 'yes'),
(310, 'litespeed.conf.cdn-cloudflare_email', '', 'yes'),
(311, 'litespeed.conf.cdn-cloudflare_key', '', 'yes'),
(312, 'litespeed.conf.cdn-cloudflare_name', '', 'yes'),
(313, 'litespeed.conf.cdn-cloudflare_zone', '', 'yes'),
(314, 'litespeed.conf.cdn-mapping', '[{\"url\":\"\",\"inc_img\":\"1\",\"inc_css\":\"1\",\"inc_js\":\"1\",\"filetype\":[\".aac\",\".css\",\".eot\",\".gif\",\".jpeg\",\".jpg\",\".js\",\".less\",\".mp3\",\".mp4\",\".ogg\",\".otf\",\".pdf\",\".png\",\".svg\",\".ttf\",\".webp\",\".woff\",\".woff2\"]}]', 'yes'),
(315, 'litespeed.conf.cdn-attr', '[\".src\",\".data-src\",\".href\",\".poster\",\"source.srcset\"]', 'yes'),
(318, 'action_scheduler_hybrid_store_demarkation', '4', 'yes'),
(319, 'schema-ActionScheduler_StoreSchema', '6.0.1653625132', 'yes'),
(320, 'schema-ActionScheduler_LoggerSchema', '3.0.1653625132', 'yes'),
(325, 'woocommerce_schema_version', '430', 'yes'),
(326, 'woocommerce_store_address', '', 'yes'),
(327, 'woocommerce_store_address_2', '', 'yes'),
(328, 'woocommerce_store_city', '', 'yes'),
(329, 'woocommerce_default_country', 'US:CA', 'yes'),
(330, 'woocommerce_store_postcode', '', 'yes'),
(331, 'woocommerce_allowed_countries', 'all', 'yes'),
(332, 'woocommerce_all_except_countries', '', 'yes'),
(333, 'woocommerce_specific_allowed_countries', '', 'yes'),
(334, 'woocommerce_ship_to_countries', '', 'yes'),
(335, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(336, 'woocommerce_default_customer_address', 'base', 'yes'),
(337, 'woocommerce_calc_taxes', 'no', 'yes'),
(338, 'woocommerce_enable_coupons', 'yes', 'yes'),
(339, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(340, 'woocommerce_currency', 'USD', 'yes'),
(341, 'woocommerce_currency_pos', 'left', 'yes'),
(342, 'woocommerce_price_thousand_sep', ',', 'yes'),
(343, 'woocommerce_price_decimal_sep', '.', 'yes'),
(344, 'woocommerce_price_num_decimals', '2', 'yes'),
(345, 'woocommerce_shop_page_id', '5', 'yes'),
(346, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(347, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(348, 'woocommerce_placeholder_image', '4', 'yes'),
(349, 'woocommerce_weight_unit', 'kg', 'yes'),
(350, 'woocommerce_dimension_unit', 'cm', 'yes'),
(351, 'woocommerce_enable_reviews', 'yes', 'yes'),
(352, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(353, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(354, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(355, 'woocommerce_review_rating_required', 'yes', 'no'),
(356, 'woocommerce_manage_stock', 'yes', 'yes'),
(357, 'woocommerce_hold_stock_minutes', '60', 'no'),
(358, 'woocommerce_notify_low_stock', 'yes', 'no'),
(359, 'woocommerce_notify_no_stock', 'yes', 'no'),
(360, 'woocommerce_stock_email_recipient', 'upmsmemart@gmail.com', 'no'),
(361, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(362, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(363, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(364, 'woocommerce_stock_format', '', 'yes'),
(365, 'woocommerce_file_download_method', 'force', 'no'),
(366, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(367, 'woocommerce_downloads_require_login', 'no', 'no'),
(368, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(369, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(370, 'woocommerce_attribute_lookup_enabled', 'yes', 'yes'),
(371, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(372, 'woocommerce_prices_include_tax', 'no', 'yes'),
(373, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(374, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(375, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(376, 'woocommerce_tax_classes', '', 'yes'),
(377, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(378, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(379, 'woocommerce_price_display_suffix', '', 'yes'),
(380, 'woocommerce_tax_total_display', 'itemized', 'no'),
(381, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(382, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(383, 'woocommerce_ship_to_destination', 'billing', 'no'),
(384, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(385, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(386, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(387, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(388, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(389, 'woocommerce_registration_generate_username', 'yes', 'no'),
(390, 'woocommerce_registration_generate_password', 'yes', 'no'),
(391, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(392, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(393, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(394, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(395, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(396, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(397, 'woocommerce_trash_pending_orders', '', 'no'),
(398, 'woocommerce_trash_failed_orders', '', 'no'),
(399, 'woocommerce_trash_cancelled_orders', '', 'no'),
(400, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(401, 'woocommerce_email_from_name', 'UP MSME Mart', 'no'),
(402, 'woocommerce_email_from_address', 'upmsmemart@gmail.com', 'no'),
(403, 'woocommerce_email_header_image', '', 'no'),
(404, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(405, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(406, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(407, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(408, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(409, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(410, 'woocommerce_cart_page_id', '6', 'no'),
(411, 'woocommerce_checkout_page_id', '7', 'no'),
(412, 'woocommerce_myaccount_page_id', '8', 'no'),
(413, 'woocommerce_terms_page_id', '', 'no'),
(414, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(415, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(416, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(417, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(418, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(419, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(420, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(421, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(422, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(423, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(424, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(425, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(426, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(427, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(428, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(429, 'woocommerce_api_enabled', 'no', 'yes'),
(430, 'woocommerce_allow_tracking', 'no', 'no'),
(431, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(432, 'woocommerce_single_image_width', '600', 'yes'),
(433, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(434, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(435, 'woocommerce_demo_store', 'no', 'no'),
(436, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(437, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(438, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(439, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(440, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(442, 'default_product_cat', '15', 'yes'),
(444, 'woocommerce_refund_returns_page_id', '9', 'yes'),
(447, 'woocommerce_paypal_settings', 'a:23:{s:7:\"enabled\";s:2:\"no\";s:5:\"title\";s:6:\"PayPal\";s:11:\"description\";s:85:\"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.\";s:5:\"email\";s:20:\"upmsmemart@gmail.com\";s:8:\"advanced\";s:0:\"\";s:8:\"testmode\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:16:\"ipn_notification\";s:3:\"yes\";s:14:\"receiver_email\";s:20:\"upmsmemart@gmail.com\";s:14:\"identity_token\";s:0:\"\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:13:\"send_shipping\";s:3:\"yes\";s:16:\"address_override\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:9:\"image_url\";s:0:\"\";s:11:\"api_details\";s:0:\"\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";s:12:\"_should_load\";s:2:\"no\";}', 'yes'),
(448, 'woocommerce_version', '6.5.1', 'yes'),
(449, 'woocommerce_db_version', '6.5.1', 'yes'),
(450, 'woocommerce_admin_install_timestamp', '1653625135', 'yes'),
(451, 'woocommerce_inbox_variant_assignment', '3', 'yes'),
(455, '_transient_jetpack_autoloader_plugin_paths', 'a:1:{i:0;s:29:\"{{WP_PLUGIN_DIR}}/woocommerce\";}', 'yes'),
(456, 'woocommerce_admin_notices', 'a:2:{i:0;s:20:\"no_secure_connection\";i:1;s:32:\"uploads_directory_is_unprotected\";}', 'yes'),
(459, 'ai1wm_secret_key', 'QFwuVWvaCgQK', 'yes'),
(462, 'wpforms_version', '1.7.4.2', 'yes'),
(463, 'wpforms_version_lite', '1.7.4.2', 'yes'),
(464, 'wpforms_activated', 'a:1:{s:4:\"lite\";i:1653625154;}', 'yes'),
(471, 'aioseo_options_internal', '{\"internal\":{\"validLicenseKey\":null,\"lastActiveVersion\":\"4.2.1.1\",\"migratedVersion\":null,\"siteAnalysis\":{\"connectToken\":null,\"score\":0,\"results\":null,\"competitors\":[]},\"headlineAnalysis\":{\"headlines\":[]},\"wizard\":null,\"category\":null,\"categoryOther\":null,\"deprecatedOptions\":[]},\"integrations\":{\"semrush\":{\"accessToken\":null,\"tokenType\":null,\"expires\":null,\"refreshToken\":null}},\"database\":{\"installedTables\":\"{\\\"wp_aioseo_posts\\\":[\\\"id\\\",\\\"post_id\\\",\\\"title\\\",\\\"description\\\",\\\"keywords\\\",\\\"keyphrases\\\",\\\"page_analysis\\\",\\\"canonical_url\\\",\\\"og_title\\\",\\\"og_description\\\",\\\"og_object_type\\\",\\\"og_image_type\\\",\\\"og_image_url\\\",\\\"og_image_width\\\",\\\"og_image_height\\\",\\\"og_image_custom_url\\\",\\\"og_image_custom_fields\\\",\\\"og_video\\\",\\\"og_custom_url\\\",\\\"og_article_section\\\",\\\"og_article_tags\\\",\\\"twitter_use_og\\\",\\\"twitter_card\\\",\\\"twitter_image_type\\\",\\\"twitter_image_url\\\",\\\"twitter_image_custom_url\\\",\\\"twitter_image_custom_fields\\\",\\\"twitter_title\\\",\\\"twitter_description\\\",\\\"seo_score\\\",\\\"schema_type\\\",\\\"schema_type_options\\\",\\\"pillar_content\\\",\\\"robots_default\\\",\\\"robots_noindex\\\",\\\"robots_noarchive\\\",\\\"robots_nosnippet\\\",\\\"robots_nofollow\\\",\\\"robots_noimageindex\\\",\\\"robots_noodp\\\",\\\"robots_notranslate\\\",\\\"robots_max_snippet\\\",\\\"robots_max_videopreview\\\",\\\"robots_max_imagepreview\\\",\\\"tabs\\\",\\\"images\\\",\\\"image_scan_date\\\",\\\"priority\\\",\\\"frequency\\\",\\\"videos\\\",\\\"video_thumbnail\\\",\\\"video_scan_date\\\",\\\"local_seo\\\",\\\"limit_modified_date\\\",\\\"created\\\",\\\"updated\\\"],\\\"wp_actionscheduler_actions\\\":[],\\\"wp_actionscheduler_logs\\\":[],\\\"wp_actionscheduler_groups\\\":[],\\\"wp_actionscheduler_claims\\\":[],\\\"wp_aioseo_notifications\\\":[]}\"}}', 'yes'),
(472, 'aioseo_options_internal_lite', '{\"internal\":{\"activated\":1653625164,\"firstActivated\":1653625164,\"installed\":0,\"connect\":{\"key\":null,\"time\":0,\"network\":false,\"token\":null}}}', 'yes'),
(475, 'optin_monster_api', 'a:11:{s:3:\"api\";a:0:{}s:10:\"is_expired\";b:0;s:11:\"is_disabled\";b:0;s:10:\"is_invalid\";b:0;s:9:\"installed\";i:1653625174;s:9:\"connected\";s:0:\"\";s:4:\"beta\";b:0;s:12:\"auto_updates\";s:0:\"\";s:14:\"usage_tracking\";b:0;s:18:\"hide_announcements\";b:0;s:7:\"welcome\";a:1:{s:6:\"status\";s:4:\"none\";}}', 'yes'),
(476, 'omapi_review', 'a:2:{s:4:\"time\";i:1653625174;s:9:\"dismissed\";b:0;}', 'yes'),
(483, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:\"database_prefix\";s:32:\"Kw1iq5jHKCRYrWgC4dQncNuGDeOA4rMC\";}', 'yes'),
(484, '_transient_woocommerce_webhook_ids_status_active', 'a:0:{}', 'yes'),
(485, 'widget_aioseo-breadcrumb-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(486, 'widget_aioseo-html-sitemap-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(487, 'widget_optin-monster-api', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(488, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(489, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(490, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(491, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(492, 'widget_woocommerce_product_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(493, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(494, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(495, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(496, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(497, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(498, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(499, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(500, 'widget_wpforms-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(501, 'widget_monsterinsights-popular-posts-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(502, 'aioseo_options_dynamic_localized', 'a:8:{s:42:\"searchAppearance_taxonomies_category_title\";s:41:\"#taxonomy_title #separator_sa #site_title\";s:52:\"searchAppearance_taxonomies_category_metaDescription\";s:21:\"#taxonomy_description\";s:42:\"searchAppearance_taxonomies_post_tag_title\";s:41:\"#taxonomy_title #separator_sa #site_title\";s:52:\"searchAppearance_taxonomies_post_tag_metaDescription\";s:21:\"#taxonomy_description\";s:45:\"searchAppearance_taxonomies_product_cat_title\";s:41:\"#taxonomy_title #separator_sa #site_title\";s:55:\"searchAppearance_taxonomies_product_cat_metaDescription\";s:21:\"#taxonomy_description\";s:45:\"searchAppearance_taxonomies_product_tag_title\";s:41:\"#taxonomy_title #separator_sa #site_title\";s:55:\"searchAppearance_taxonomies_product_tag_metaDescription\";s:21:\"#taxonomy_description\";}', 'yes'),
(504, 'monsterinsights_over_time', 'a:4:{s:17:\"installed_version\";s:5:\"8.5.3\";s:14:\"installed_date\";i:1653625405;s:13:\"installed_pro\";b:0;s:14:\"installed_lite\";i:1653625405;}', 'no'),
(505, 'monsterinsights_db_version', '7.4.0', 'yes'),
(506, 'monsterinsights_current_version', '8.5.3', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(507, 'monsterinsights_settings', 'a:40:{s:22:\"enable_affiliate_links\";b:1;s:15:\"affiliate_links\";a:2:{i:0;a:2:{s:4:\"path\";s:4:\"/go/\";s:5:\"label\";s:9:\"affiliate\";}i:1;a:2:{s:4:\"path\";s:11:\"/recommend/\";s:5:\"label\";s:9:\"affiliate\";}}s:12:\"demographics\";i:1;s:12:\"ignore_users\";a:2:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";}s:19:\"dashboards_disabled\";i:0;s:13:\"anonymize_ips\";i:0;s:19:\"extensions_of_files\";s:34:\"doc,pdf,ppt,zip,xls,docx,pptx,xlsx\";s:18:\"subdomain_tracking\";s:0:\"\";s:16:\"link_attribution\";b:1;s:16:\"tag_links_in_rss\";b:1;s:12:\"allow_anchor\";i:0;s:16:\"add_allow_linker\";i:0;s:13:\"save_settings\";a:1:{i:0;s:13:\"administrator\";}s:12:\"view_reports\";a:2:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";}s:11:\"events_mode\";s:2:\"js\";s:13:\"tracking_mode\";s:4:\"gtag\";s:15:\"email_summaries\";s:2:\"on\";s:23:\"summaries_html_template\";s:3:\"yes\";s:25:\"summaries_email_addresses\";a:1:{i:0;a:1:{s:5:\"email\";s:20:\"upmsmemart@gmail.com\";}}s:17:\"automatic_updates\";s:4:\"none\";s:26:\"popular_posts_inline_theme\";s:5:\"alpha\";s:26:\"popular_posts_widget_theme\";s:5:\"alpha\";s:28:\"popular_posts_products_theme\";s:5:\"alpha\";s:30:\"popular_posts_inline_placement\";s:6:\"manual\";s:34:\"popular_posts_widget_theme_columns\";s:1:\"2\";s:36:\"popular_posts_products_theme_columns\";s:1:\"2\";s:26:\"popular_posts_widget_count\";s:1:\"4\";s:28:\"popular_posts_products_count\";s:1:\"4\";s:38:\"popular_posts_widget_theme_meta_author\";s:2:\"on\";s:36:\"popular_posts_widget_theme_meta_date\";s:2:\"on\";s:40:\"popular_posts_widget_theme_meta_comments\";s:2:\"on\";s:39:\"popular_posts_products_theme_meta_price\";s:2:\"on\";s:40:\"popular_posts_products_theme_meta_rating\";s:2:\"on\";s:39:\"popular_posts_products_theme_meta_image\";s:2:\"on\";s:32:\"popular_posts_inline_after_count\";s:3:\"150\";s:36:\"popular_posts_inline_multiple_number\";s:1:\"3\";s:38:\"popular_posts_inline_multiple_distance\";s:3:\"250\";s:39:\"popular_posts_inline_multiple_min_words\";s:3:\"100\";s:31:\"popular_posts_inline_post_types\";a:1:{i:0;s:4:\"post\";}s:31:\"popular_posts_widget_post_types\";a:1:{i:0;s:4:\"post\";}}', 'yes'),
(508, 'aioseo_dynamic_settings_backup', '{}', 'yes'),
(511, 'theme_mods_twentytwentytwo', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1653627457;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(514, 'aioseo_options', '{\"internal\":[],\"webmasterTools\":{\"google\":null,\"bing\":null,\"yandex\":null,\"baidu\":null,\"pinterest\":null,\"microsoftClarityProjectId\":null,\"norton\":null,\"miscellaneousVerification\":null},\"breadcrumbs\":{\"enable\":true,\"separator\":\"&raquo;\",\"homepageLink\":true,\"homepageLabel\":\"Home\",\"breadcrumbPrefix\":null,\"archiveFormat\":\"Archives for #breadcrumb_archive_post_type_name\",\"searchResultFormat\":\"Search Results for \'#breadcrumb_search_string\'\",\"errorFormat404\":\"404 - Page Not Found\",\"showCurrentItem\":true,\"linkCurrentItem\":false,\"categoryFullHierarchy\":false,\"showBlogHome\":false},\"rssContent\":{\"before\":null,\"after\":\"&lt;p&gt;The post #post_link first appeared on #site_link.&lt;\\/p&gt;\"},\"advanced\":{\"truSeo\":true,\"headlineAnalyzer\":true,\"seoAnalysis\":true,\"dashboardWidgets\":true,\"announcements\":true,\"postTypes\":{\"all\":true,\"included\":[\"post\",\"page\",\"product\"]},\"taxonomies\":{\"all\":true,\"included\":[\"category\",\"post_tag\",\"product_cat\",\"product_tag\"]},\"uninstall\":false},\"sitemap\":{\"general\":{\"enable\":true,\"filename\":\"sitemap\",\"indexes\":true,\"linksPerIndex\":1000,\"postTypes\":{\"all\":true,\"included\":[\"post\",\"page\",\"attachment\",\"product\"]},\"taxonomies\":{\"all\":true,\"included\":[\"category\",\"post_tag\",\"product_cat\",\"product_tag\"]},\"author\":false,\"date\":false,\"additionalPages\":{\"enable\":false,\"pages\":[]},\"advancedSettings\":{\"enable\":false,\"excludeImages\":false,\"excludePosts\":[],\"excludeTerms\":[],\"priority\":{\"homePage\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"postTypes\":{\"grouped\":true,\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"taxonomies\":{\"grouped\":true,\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"archive\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"author\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"}}}},\"rss\":{\"enable\":true,\"linksPerIndex\":50,\"postTypes\":{\"all\":true,\"included\":[\"post\",\"page\",\"product\"]}},\"html\":{\"enable\":true,\"pageUrl\":\"\",\"postTypes\":{\"all\":true,\"included\":[\"post\",\"page\",\"product\"]},\"taxonomies\":{\"all\":true,\"included\":[\"category\",\"post_tag\",\"product_cat\",\"product_tag\"]},\"sortOrder\":\"publish_date\",\"sortDirection\":\"asc\",\"publicationDate\":true,\"compactArchives\":false,\"advancedSettings\":{\"enable\":false,\"nofollowLinks\":false,\"excludePosts\":[],\"excludeTerms\":[]}}},\"social\":{\"profiles\":{\"sameUsername\":{\"enable\":false,\"username\":null,\"included\":[\"facebookPageUrl\",\"twitterUrl\",\"pinterestUrl\",\"instagramUrl\",\"youtubeUrl\",\"linkedinUrl\"]},\"urls\":{\"facebookPageUrl\":null,\"twitterUrl\":null,\"instagramUrl\":null,\"pinterestUrl\":null,\"youtubeUrl\":null,\"linkedinUrl\":null,\"tumblrUrl\":null,\"yelpPageUrl\":null,\"soundCloudUrl\":null,\"wikipediaUrl\":null,\"myspaceUrl\":null,\"googlePlacesUrl\":null}},\"siteSocialProfiles\":null,\"facebook\":{\"general\":{\"enable\":true,\"defaultImageSourcePosts\":\"default\",\"customFieldImagePosts\":null,\"defaultImagePosts\":\"\",\"defaultImagePostsWidth\":\"\",\"defaultImagePostsHeight\":\"\",\"showAuthor\":true,\"siteName\":\"#site_title #separator_sa #tagline\"},\"homePage\":{\"image\":\"\",\"title\":\"\",\"description\":\"\",\"imageWidth\":\"\",\"imageHeight\":\"\",\"objectType\":\"website\"},\"advanced\":{\"enable\":false,\"adminId\":\"\",\"appId\":\"\",\"authorUrl\":\"\",\"generateArticleTags\":false,\"useKeywordsInTags\":true,\"useCategoriesInTags\":true,\"usePostTagsInTags\":true}},\"twitter\":{\"general\":{\"enable\":true,\"useOgData\":false,\"defaultCardType\":\"summary\",\"defaultImageSourcePosts\":\"default\",\"customFieldImagePosts\":null,\"defaultImagePosts\":\"\",\"showAuthor\":true,\"additionalData\":false},\"homePage\":{\"image\":\"\",\"title\":\"\",\"description\":\"\",\"cardType\":\"summary\"}}},\"searchAppearance\":{\"global\":{\"separator\":\"&#45;\",\"siteTitle\":\"#site_title #separator_sa #tagline\",\"metaDescription\":\"#tagline\",\"keywords\":null,\"schema\":{\"siteRepresents\":\"organization\",\"person\":null,\"organizationName\":\"UP MSME Mart\",\"organizationLogo\":\"\",\"personName\":null,\"personLogo\":null,\"phone\":null,\"contactType\":null,\"contactTypeManual\":null}},\"advanced\":{\"globalRobotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noindexPaginated\":true,\"nofollowPaginated\":true,\"noindexFeed\":true,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"sitelinks\":true,\"noIndexEmptyCat\":true,\"removeStopWords\":false,\"noPaginationForCanonical\":true,\"useKeywords\":false,\"keywordsLooking\":true,\"useCategoriesForMetaKeywords\":false,\"useTagsForMetaKeywords\":false,\"dynamicallyGenerateKeywords\":false,\"pagedFormat\":\"- Page #page_number\",\"runShortcodes\":false,\"crawlCleanup\":{\"enable\":false,\"feeds\":{\"global\":true,\"globalComments\":false,\"staticBlogPage\":true,\"authors\":true,\"postComments\":false,\"search\":false,\"attachments\":false,\"archives\":{\"all\":false,\"included\":[]},\"taxonomies\":{\"all\":false,\"included\":[\"category\"]},\"atom\":false,\"rdf\":false,\"paginated\":false},\"removeUnrecognizedQueryArgs\":true,\"allowedQueryArgs\":\"\\/^utm_*\\/\"}},\"archives\":{\"author\":{\"show\":true,\"title\":\"#author_name #separator_sa #site_title\",\"metaDescription\":\"#author_bio\",\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"keywords\":null}},\"date\":{\"show\":true,\"title\":\"#archive_date #separator_sa #site_title\",\"metaDescription\":\"\",\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"keywords\":null}},\"search\":{\"show\":false,\"title\":\"#search_term #separator_sa #site_title\",\"metaDescription\":\"\",\"advanced\":{\"robotsMeta\":{\"default\":false,\"noindex\":true,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"keywords\":null}}}},\"tools\":{\"robots\":{\"enable\":false,\"rules\":[],\"robotsDetected\":true},\"importExport\":{\"backup\":{\"lastTime\":null,\"data\":null}}},\"deprecated\":{\"webmasterTools\":{\"googleAnalytics\":{\"id\":null,\"advanced\":false,\"trackingDomain\":null,\"multipleDomains\":false,\"additionalDomains\":null,\"anonymizeIp\":false,\"displayAdvertiserTracking\":false,\"excludeUsers\":[],\"trackOutboundLinks\":false,\"enhancedLinkAttribution\":false,\"enhancedEcommerce\":false}},\"searchAppearance\":{\"global\":{\"descriptionFormat\":null,\"schema\":{\"enableSchemaMarkup\":true}},\"advanced\":{\"autogenerateDescriptions\":true,\"runShortcodesInDescription\":true,\"useContentForAutogeneratedDescriptions\":false,\"excludePosts\":[],\"excludeTerms\":[]}},\"sitemap\":{\"general\":{\"advancedSettings\":{\"dynamic\":true}}},\"tools\":{\"blocker\":{\"blockBots\":null,\"blockReferer\":null,\"track\":null,\"custom\":{\"enable\":null,\"bots\":\"Abonti\\naggregator\\nAhrefsBot\\nasterias\\nBDCbot\\nBLEXBot\\nBuiltBotTough\\nBullseye\\nBunnySlippers\\nca-crawler\\nCCBot\\nCegbfeieh\\nCheeseBot\\nCherryPicker\\nCopyRightCheck\\ncosmos\\nCrescent\\ndiscobot\\nDittoSpyder\\nDotBot\\nDownload Ninja\\nEasouSpider\\nEmailCollector\\nEmailSiphon\\nEmailWolf\\nEroCrawler\\nExtractorPro\\nFasterfox\\nFeedBooster\\nFoobot\\nGenieo\\ngrub-client\\nHarvest\\nhloader\\nhttplib\\nHTTrack\\nhumanlinks\\nieautodiscovery\\nInfoNaviRobot\\nIstellaBot\\nJava\\/1.\\nJennyBot\\nk2spider\\nKenjin Spider\\nKeyword Density\\/0.9\\nlarbin\\nLexiBot\\nlibWeb\\nlibwww\\nLinkextractorPro\\nlinko\\nLinkScan\\/8.1a Unix\\nLinkWalker\\nLNSpiderguy\\nlwp-trivial\\nmagpie\\nMata Hari\\nMaxPointCrawler\\nMegaIndex\\nMicrosoft URL Control\\nMIIxpc\\nMippin\\nMissigua Locator\\nMister PiX\\nMJ12bot\\nmoget\\nMSIECrawler\\nNetAnts\\nNICErsPRO\\nNiki-Bot\\nNPBot\\nNutch\\nOffline Explorer\\nOpenfind\\npanscient.com\\nPHP\\/5.{\\nProPowerBot\\/2.14\\nProWebWalker\\nPython-urllib\\nQueryN Metasearch\\nRepoMonkey\\nSISTRIX\\nsitecheck.Internetseer.com\\nSiteSnagger\\nSnapPreviewBot\\nSogou\\nSpankBot\\nspanner\\nspbot\\nSpinn3r\\nsuzuran\\nSzukacz\\/1.4\\nTeleport\\nTelesoft\\nThe Intraformant\\nTheNomad\\nTightTwatBot\\nTitan\\ntoCrawl\\/UrlDispatcher\\nTrue_Robot\\nturingos\\nTurnitinBot\\nUbiCrawler\\nUnisterBot\\nURLy Warning\\nVCI\\nWBSearchBot\\nWeb Downloader\\/6.9\\nWeb Image Collector\\nWebAuto\\nWebBandit\\nWebCopier\\nWebEnhancer\\nWebmasterWorldForumBot\\nWebReaper\\nWebSauger\\nWebsite Quester\\nWebster Pro\\nWebStripper\\nWebZip\\nWotbox\\nwsr-agent\\nWWW-Collector-E\\nXenu\\nZao\\nZeus\\nZyBORG\\ncoccoc\\nIncutio\\nlmspider\\nmemoryBot\\nserf\\nUnknown\\nuptime files\",\"referer\":\"semalt.com\\nkambasoft.com\\nsavetubevideo.com\\nbuttons-for-website.com\\nsharebutton.net\\nsoundfrost.org\\nsrecorder.com\\nsoftomix.com\\nsoftomix.net\\nmyprintscreen.com\\njoinandplay.me\\nfbfreegifts.com\\nopenmediasoft.com\\nzazagames.org\\nextener.org\\nopenfrost.com\\nopenfrost.net\\ngooglsucks.com\\nbest-seo-offer.com\\nbuttons-for-your-website.com\\nwww.Get-Free-Traffic-Now.com\\nbest-seo-solution.com\\nbuy-cheap-online.info\\nsite3.free-share-buttons.com\\nwebmaster-traffic.com\"}}}}}', 'yes'),
(515, 'aioseo_options_lite', '{\"advanced\":{\"usageTracking\":false}}', 'yes'),
(516, 'aioseo_options_dynamic', '{\"sitemap\":{\"priority\":{\"postTypes\":{\"post\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"page\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"attachment\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"},\"product\":{\"priority\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\",\"frequency\":\"{\\\"label\\\":\\\"default\\\",\\\"value\\\":\\\"default\\\"}\"}},\"taxonomies\":[]}},\"social\":{\"facebook\":{\"general\":{\"postTypes\":{\"post\":{\"objectType\":\"article\"},\"page\":{\"objectType\":\"article\"},\"attachment\":{\"objectType\":\"article\"},\"product\":{\"objectType\":\"article\"}}}}},\"searchAppearance\":{\"postTypes\":{\"post\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"bulkEditing\":\"enabled\"},\"title\":\"#post_title #separator_sa #site_title\",\"metaDescription\":\"#post_excerpt\",\"schemaType\":\"Article\",\"webPageType\":\"WebPage\",\"articleType\":\"BlogPosting\",\"customFields\":null},\"page\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"bulkEditing\":\"enabled\"},\"title\":\"#post_title #separator_sa #site_title\",\"metaDescription\":\"#post_content\",\"schemaType\":\"WebPage\",\"webPageType\":\"WebPage\",\"articleType\":\"BlogPosting\",\"customFields\":null},\"attachment\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"bulkEditing\":\"enabled\"},\"title\":\"#post_title #separator_sa #site_title\",\"metaDescription\":\"#attachment_caption\",\"schemaType\":\"ItemPage\",\"webPageType\":\"ItemPage\",\"articleType\":\"BlogPosting\",\"customFields\":null,\"redirectAttachmentUrls\":\"attachment\"},\"product\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true,\"bulkEditing\":\"enabled\"},\"title\":\"#post_title #separator_sa #site_title\",\"metaDescription\":\"#post_excerpt\",\"schemaType\":\"WebPage\",\"webPageType\":\"ItemPage\",\"articleType\":\"BlogPosting\",\"customFields\":null}},\"taxonomies\":{\"category\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true},\"title\":\"#taxonomy_title #separator_sa #site_title\",\"metaDescription\":\"#taxonomy_description\"},\"post_tag\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true},\"title\":\"#taxonomy_title #separator_sa #site_title\",\"metaDescription\":\"#taxonomy_description\"},\"product_cat\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true},\"title\":\"#taxonomy_title #separator_sa #site_title\",\"metaDescription\":\"#taxonomy_description\"},\"product_tag\":{\"show\":true,\"advanced\":{\"robotsMeta\":{\"default\":true,\"noindex\":false,\"nofollow\":false,\"noarchive\":false,\"noimageindex\":false,\"notranslate\":false,\"nosnippet\":false,\"noodp\":false,\"maxSnippet\":-1,\"maxVideoPreview\":-1,\"maxImagePreview\":\"large\"},\"showDateInGooglePreview\":true,\"showPostThumbnailInSearch\":true,\"showMetaBox\":true},\"title\":\"#taxonomy_title #separator_sa #site_title\",\"metaDescription\":\"#taxonomy_description\"}},\"archives\":[]}}', 'yes'),
(526, 'om_notifications', 'a:4:{s:7:\"updated\";i:1653626514;s:4:\"feed\";a:0:{}s:6:\"events\";a:0:{}s:9:\"dismissed\";a:0:{}}', 'no'),
(527, 'optinmonster_upgrade_completed', '2.7.0', 'yes'),
(528, 'monsterinsights_usage_tracking_config', 'a:6:{s:3:\"day\";i:0;s:4:\"hour\";i:0;s:6:\"minute\";i:5;s:6:\"second\";i:3;s:6:\"offset\";i:303;s:8:\"initsend\";i:1653782703;}', 'yes'),
(529, 'recovery_keys', 'a:0:{}', 'yes'),
(530, 'https_detection_errors', 'a:1:{s:20:\"https_request_failed\";a:1:{i:0;s:21:\"HTTPS request failed.\";}}', 'yes'),
(537, '_site_transient_ai1wm_last_check_for_updates', '1656865678', 'no'),
(538, 'ai1wm_updater', 'a:0:{}', 'yes'),
(539, 'action_scheduler_migration_status', 'complete', 'yes'),
(540, '_transient_timeout_woocommerce_admin_remote_inbox_notifications_specs', '1657426847', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(541, '_transient_woocommerce_admin_remote_inbox_notifications_specs', 'a:33:{s:27:\"new_in_app_marketplace_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:27:\"new_in_app_marketplace_2021\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:36:\"Customize your store with extensions\";s:7:\"content\";s:164:\"Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:17:\"browse_extensions\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:17:\"Browse extensions\";}}s:3:\"url\";s:15:\"&page=wc-addons\";s:18:\"url_is_admin_query\";b:1;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:14:23\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"5.7\";}}}s:21:\"wayflyer_bnpl_q4_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:21:\"wayflyer_bnpl_q4_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:48:\"Grow your business with funding through Wayflyer\";s:7:\"content\";s:261:\"Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:21:\"wayflyer_bnpl_q4_2021\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:21:\"Level up with funding\";}}s:3:\"url\";s:118:\"https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-11-17 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-12-18 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:7:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"AU\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"BE\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"CA\";}i:3;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"IE\";}i:4;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"NL\";}i:5;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"GB\";}i:6;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"US\";}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:26:\"woocommerce-gateway-affirm\";}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:32:\"afterpay-gateway-for-woocommerce\";}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:31:\"klarna-payments-for-woocommerce\";}}}}}}s:35:\"wc_shipping_mobile_app_usps_q4_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:35:\"wc_shipping_mobile_app_usps_q4_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:94:\"Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App\";s:7:\"content\";s:210:\"Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href=\"https://woocommerce.com/woocommerce-shipping/\">WooCommerce Shipping</a> – all directly from your mobile device!\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:35:\"wc_shipping_mobile_app_usps_q4_2021\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Get WooCommerce Shipping\";}}s:3:\"url\";s:135:\"https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:5:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-11-12 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-11-27 00:00:00\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"US\";}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:25:\"woocommerce-shipping-usps\";}}i:4;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}}}}}s:30:\"wc_shipping_mobile_app_q4_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:30:\"wc_shipping_mobile_app_q4_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:69:\"Print and manage your shipping labels with the WooCommerce Mobile App\";s:7:\"content\";s:210:\"Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href=\"https://woocommerce.com/woocommerce-shipping/\">WooCommerce Shipping</a> – all directly from your mobile device!\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"wc_shipping_mobile_app_q4_2021\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:30:\"Get the WooCommerce Mobile App\";}}s:3:\"url\";s:116:\"https://woocommerce.com/mobile/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_q4_2021\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-11-12 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-11-27 00:00:00\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"US\";}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}}}s:37:\"ecomm-need-help-setting-up-your-store\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"ecomm-need-help-setting-up-your-store\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:32:\"Need help setting up your Store?\";s:7:\"content\";s:350:\"Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:16:\"set-up-concierge\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:21:\"Schedule free session\";}}s:3:\"url\";s:34:\"https://wordpress.com/me/concierge\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:16:48\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}}}s:20:\"woocommerce-services\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"woocommerce-services\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"WooCommerce Shipping & Tax\";s:7:\"content\";s:251:\"WooCommerce Shipping & Tax helps get your store \"ready to sell\" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:84:\"https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:17:25\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:32:\"ecomm-unique-shopping-experience\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"ecomm-unique-shopping-experience\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"For a shopping experience as unique as your customers\";s:7:\"content\";s:270:\"Product Add-Ons allow your customers to personalize products while they\'re shopping on your online store. No more follow-up email requests—customers get what they want, before they\'re done checking out. Learn more about this extension that comes included in your plan.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:43:\"learn-more-ecomm-unique-shopping-experience\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:71:\"https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:18:01\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:37:\"wc-admin-getting-started-in-ecommerce\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-getting-started-in-ecommerce\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Getting Started in eCommerce - webinar\";s:7:\"content\";s:174:\"We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:17:\"watch-the-webinar\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:17:\"Watch the webinar\";}}s:3:\"url\";s:28:\"https://youtu.be/V_2XtCOyZ7o\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:18:37\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:12:\"setup_client\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:1;}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_count\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:1:\"0\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:4:\"none\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:10:\"up-to-2500\";}}}}}s:18:\"your-first-product\";O:8:\"stdClass\":8:{s:4:\"slug\";s:18:\"your-first-product\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:18:\"Your first product\";s:7:\"content\";s:467:\"That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br/><br/>Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:130:\"https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:5:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:19:13\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_were_no_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_are_now_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:3;O:8:\"stdClass\":3:{s:4:\"type\";s:13:\"product_count\";s:9:\"operation\";s:2:\">=\";s:5:\"value\";i:1;}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_types\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"physical\";s:7:\"default\";a:0:{}}}}s:37:\"wc-admin-optimizing-the-checkout-flow\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-optimizing-the-checkout-flow\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:28:\"Optimizing the checkout flow\";s:7:\"content\";s:177:\"It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:28:\"optimizing-the-checkout-flow\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:144:\"https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:19:49\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:3;}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"payments\";s:7:\"default\";a:0:{}}}}s:39:\"wc-admin-first-five-things-to-customize\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-admin-first-five-things-to-customize\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"The first 5 things to customize in your store\";s:7:\"content\";s:175:\"Deciding what to start with first is tricky. To help you properly prioritize, we’ve put together this short list of the first few things you should customize in WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:130:\"https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:20:31\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:2;}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:5:\"value\";s:9:\"NOT EMPTY\";s:7:\"default\";s:9:\"NOT EMPTY\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wc-payments-qualitative-feedback\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wc-payments-qualitative-feedback\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"WooCommerce Payments setup - let us know what you think\";s:7:\"content\";s:146:\"Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:35:\"qualitative-feedback-from-new-users\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:39:\"https://automattic.survey.fm/wc-pay-new\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:21:13\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:20:\"woocommerce-payments\";s:7:\"default\";a:0:{}}}}s:29:\"share-your-feedback-on-paypal\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"share-your-feedback-on-paypal\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:29:\"Share your feedback on PayPal\";s:7:\"content\";s:127:\"Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:14:\"share-feedback\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:43:\"http://automattic.survey.fm/paypal-feedback\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:21:50\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:26:\"woocommerce-gateway-stripe\";}}}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}}}s:31:\"google_listings_and_ads_install\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"google_listings_and_ads_install\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:35:\"Drive traffic and sales with Google\";s:7:\"content\";s:123:\"Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:11:\"get-started\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:11:\"Get started\";}}s:3:\"url\";s:122:\"https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-06-09 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:23:\"google_listings_and_ads\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:11:\"order_count\";s:9:\"operation\";s:1:\">\";s:5:\"value\";i:10;}}}s:39:\"wc-subscriptions-security-update-3-0-15\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-subscriptions-security-update-3-0-15\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:42:\"WooCommerce Subscriptions security update!\";s:7:\"content\";s:738:\"We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br/><br/>Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br/><br/>We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br/><br/>If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"update-wc-subscriptions-3-0-15\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"View latest version\";}}s:3:\"url\";s:30:\"&page=wc-addons&section=helper\";s:18:\"url_is_admin_query\";b:1;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:30:32\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:25:\"woocommerce-subscriptions\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:6:\"3.0.15\";}}}s:29:\"woocommerce-core-update-5-4-0\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"woocommerce-core-update-5-4-0\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:31:\"Update to WooCommerce 5.4.1 now\";s:7:\"content\";s:140:\"WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:20:\"update-wc-core-5-4-0\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:25:\"How to update WooCommerce\";}}s:3:\"url\";s:64:\"https://docs.woocommerce.com/document/how-to-update-woocommerce/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:31:08\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.0\";}}}s:19:\"wcpay-promo-2020-11\";O:8:\"stdClass\":8:{s:4:\"slug\";s:19:\"wcpay-promo-2020-11\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:19:\"wcpay-promo-2020-11\";s:7:\"content\";s:19:\"wcpay-promo-2020-11\";}}s:7:\"actions\";a:0:{}s:5:\"rules\";a:0:{}}s:19:\"wcpay-promo-2020-12\";O:8:\"stdClass\":8:{s:4:\"slug\";s:19:\"wcpay-promo-2020-12\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:19:\"wcpay-promo-2020-12\";s:7:\"content\";s:19:\"wcpay-promo-2020-12\";}}s:7:\"actions\";a:0:{}s:5:\"rules\";a:0:{}}s:34:\"ppxo-pps-upgrade-paypal-payments-1\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"ppxo-pps-upgrade-paypal-payments-1\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:47:\"Get the latest PayPal extension for WooCommerce\";s:7:\"content\";s:442:\"Heads up! There’s a new PayPal on the block!<br/><br/>Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br/><br/>Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"ppxo-pps-install-paypal-payments-1\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:18:\"View upgrade guide\";}}s:3:\"url\";s:96:\"https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:5:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:33:53\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"5.5\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":6:{s:4:\"type\";s:6:\"option\";s:12:\"transformers\";a:1:{i:0;O:8:\"stdClass\":2:{s:3:\"use\";s:12:\"dot_notation\";s:9:\"arguments\";O:8:\"stdClass\":1:{s:4:\"path\";s:7:\"enabled\";}}}s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;}}}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";i:7;s:7:\"default\";i:1;s:9:\"operation\";s:1:\"<\";}}}s:34:\"ppxo-pps-upgrade-paypal-payments-2\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"ppxo-pps-upgrade-paypal-payments-2\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:31:\"Upgrade your PayPal experience!\";s:7:\"content\";s:358:\"Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">latest PayPal today</a> to continue to receive support and updates.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"ppxo-pps-install-paypal-payments-2\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:18:\"View upgrade guide\";}}s:3:\"url\";s:96:\"https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:5:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:34:30\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"5.5\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":6:{s:4:\"type\";s:6:\"option\";s:12:\"transformers\";a:1:{i:0;O:8:\"stdClass\":2:{s:3:\"use\";s:12:\"dot_notation\";s:9:\"arguments\";O:8:\"stdClass\":1:{s:4:\"path\";s:7:\"enabled\";}}}s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;}}}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";i:6;s:7:\"default\";i:1;s:9:\"operation\";s:1:\">\";}}}s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";O:8:\"stdClass\":8:{s:4:\"slug\";s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:56:\"Action required: Critical vulnerabilities in WooCommerce\";s:7:\"content\";s:574:\"In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:137:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";s:0:\"\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:59:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:35:06\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.3.6\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.4.8\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.5.9\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.6.6\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.7.2\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.8.2\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.9.4\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.0.2\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.0.3\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.1.2\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.1.3\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.2.3\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.2.4\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.3.4\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.3.5\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.4.2\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.4.3\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.5.3\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.5.4\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.6.3\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.6.4\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.7.2\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.7.3\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.8.1\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.8.2\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.9.3\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.9.4\";}i:28;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.0.1\";}i:29;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.0.2\";}i:30;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.1.1\";}i:31;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.1.2\";}i:32;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.2.3\";}i:33;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.2.4\";}i:34;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.3.1\";}i:35;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.3.2\";}i:36;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.4.2\";}i:37;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.4.3\";}i:38;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:5:\"5.5.1\";}i:39;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:6:\"3.5.10\";}i:40;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.6.7\";}i:41;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.7.3\";}i:42;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.8.3\";}i:43;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.9.5\";}i:44;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.0.4\";}i:45;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.1.4\";}i:46;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.2.5\";}i:47;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.3.6\";}i:48;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.4.4\";}i:49;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.5.5\";}i:50;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.6.5\";}i:51;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.7.4\";}i:52;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.8.3\";}i:53;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.9.5\";}i:54;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.0.3\";}i:55;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.1.3\";}i:56;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.2.5\";}i:57;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.3.3\";}i:58;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.4.4\";}}}s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";O:8:\"stdClass\":8:{s:4:\"slug\";s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:63:\"Action required: Critical vulnerabilities in WooCommerce Blocks\";s:7:\"content\";s:570:\"In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/>Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br/><br/>For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:137:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:32:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:35:42\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:6:\"2.5.16\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.6.2\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.7.2\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.8.1\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.9.1\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.0.1\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.1.1\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.2.1\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.3.1\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.4.1\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.5.1\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.6.1\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.7.2\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.8.1\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.9.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.0.1\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.1.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.2.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.3.1\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.4.3\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.5.3\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.6.1\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.7.1\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.8.1\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.9.2\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.0.1\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.1.1\";}i:28;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.2.1\";}i:29;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.3.2\";}i:30;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.4.1\";}i:31;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:5:\"5.5.1\";}}}s:45:\"woocommerce-core-sqli-july-2021-store-patched\";O:8:\"stdClass\":8:{s:4:\"slug\";s:45:\"woocommerce-core-sqli-july-2021-store-patched\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"Solved: Critical vulnerabilities patched in WooCommerce\";s:7:\"content\";s:433:\"In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:137:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:36:18\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:23:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.3.6\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.4.8\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.5.9\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.6.6\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.7.2\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.8.2\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.9.4\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.0.2\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.1.2\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.2.3\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.3.4\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.4.2\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.5.3\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.6.3\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.7.2\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.8.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.9.3\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.0.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.1.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.2.3\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.3.1\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.2\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"5.5.1\";}}}}}s:47:\"woocommerce-blocks-sqli-july-2021-store-patched\";O:8:\"stdClass\":8:{s:4:\"slug\";s:47:\"woocommerce-blocks-sqli-july-2021-store-patched\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:62:\"Solved: Critical vulnerabilities patched in WooCommerce Blocks\";s:7:\"content\";s:433:\"In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:137:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:36:54\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:31:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:6:\"2.5.16\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.6.2\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.7.2\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.8.1\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.9.1\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.0.1\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.1.1\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.2.1\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.3.1\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.4.1\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.5.1\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.6.1\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.7.2\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.8.1\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.9.1\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.0.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.1.1\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.2.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.3.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.4.3\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.5.3\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.6.1\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.7.1\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.8.1\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.9.2\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.0.1\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.1.1\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.2.1\";}i:28;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.3.2\";}i:29;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.1\";}i:30;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"5.5.1\";}}}}}s:19:\"habit-moment-survey\";O:8:\"stdClass\":8:{s:4:\"slug\";s:19:\"habit-moment-survey\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:63:\"We’re all ears! Share your experience so far with WooCommerce\";s:7:\"content\";s:136:\"We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:14:\"share-feedback\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:45:\"https://automattic.survey.fm/store-management\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:37:30\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:3;}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:11:\"order_count\";s:9:\"operation\";s:1:\">\";s:5:\"value\";i:30;}i:3;O:8:\"stdClass\":3:{s:4:\"type\";s:13:\"product_count\";s:9:\"operation\";s:1:\">\";s:5:\"value\";i:0;}}}s:26:\"ecomm-wc-navigation-survey\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"ecomm-wc-navigation-survey\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"We’d like your feedback on the WooCommerce navigation\";s:7:\"content\";s:134:\"We’re making improvements to the WooCommerce navigation and would love your feedback. Share your experience in this 2 minute survey.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:32:\"share-navigation-survey-feedback\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:63:\"https://automattic.survey.fm/feedback-on-woocommerce-navigation\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-01-27 20:38:07\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:12:\"is_ecommerce\";s:5:\"value\";b:1;}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:90;}}}s:42:\"woocommerce-core-paypal-march-2022-updated\";O:8:\"stdClass\":8:{s:4:\"slug\";s:42:\"woocommerce-core-paypal-march-2022-updated\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:35:\"Security auto-update of WooCommerce\";s:7:\"content\";s:391:\"<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal Payments</a> to accept PayPal.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:88:\"https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:42:\"woocommerce-core-paypal-march-2022-dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";s:0:\"\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-03-10 18:44:57\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:28:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:6:\"3.5.10\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.6.7\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.7.3\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.8.3\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.9.5\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.0.4\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.1.4\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.2.5\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.3.6\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.4.4\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.5.5\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.6.5\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.7.4\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.8.3\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.9.5\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.0.3\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.1.3\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.2.5\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.3.3\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.4\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.5.4\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.6.2\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.7.2\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.8.1\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.9.1\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"6.0.1\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"6.1.2\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"6.2.2\";}}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:3:\"5.5\";}i:1;a:2:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"5.5\";}i:1;O:8:\"stdClass\":6:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;s:12:\"transformers\";a:1:{i:0;O:8:\"stdClass\":2:{s:3:\"use\";s:12:\"dot_notation\";s:9:\"arguments\";O:8:\"stdClass\":1:{s:4:\"path\";s:7:\"enabled\";}}}}}}}}}s:47:\"woocommerce-core-paypal-march-2022-updated-nopp\";O:8:\"stdClass\":8:{s:4:\"slug\";s:47:\"woocommerce-core-paypal-march-2022-updated-nopp\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:35:\"Security auto-update of WooCommerce\";s:7:\"content\";s:237:\"<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:88:\"https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";s:0:\"\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-03-10 18:45:04\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:28:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:6:\"3.5.10\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.6.7\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.7.3\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.8.3\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.9.5\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.0.4\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.1.4\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.2.5\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.3.6\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.4.4\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.5.5\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.6.5\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.7.4\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.8.3\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.9.5\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.0.3\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.1.3\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.2.5\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.3.3\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.4\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.5.4\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.6.2\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.7.2\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.8.1\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.9.1\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"6.0.1\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"6.1.2\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"6.2.2\";}}}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:42:\"woocommerce-core-paypal-march-2022-updated\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}s:24:\"pinterest_03_2022_update\";O:8:\"stdClass\":8:{s:4:\"slug\";s:24:\"pinterest_03_2022_update\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"Your Pinterest for WooCommerce plugin is out of date!\";s:7:\"content\";s:262:\"Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:24:\"pinterest_03_2022_update\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"Update Instructions\";}}s:3:\"url\";s:148:\"https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-03-23 00:00:39\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:25:\"pinterest-for-woocommerce\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:5:\"1.0.8\";}}}s:36:\"setup_task_initiative_survey_q2_2022\";O:8:\"stdClass\":8:{s:4:\"slug\";s:36:\"setup_task_initiative_survey_q2_2022\";s:4:\"type\";s:6:\"survey\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:40:\"We want to know what matters most to you\";s:7:\"content\";s:144:\"Take 2 minutes to give us your input on what is important for you while setting up your store and help shape the future of WooCommerce together.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:53:\"setup_task_initiative_survey_q2_2022_share_your_input\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:16:\"Share your input\";}}s:3:\"url\";s:26:\"https://t.maze.co/87390007\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-04-26 00:00:37\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:180;}}}s:33:\"store_setup_survey_survey_q2_2022\";O:8:\"stdClass\":8:{s:4:\"slug\";s:33:\"store_setup_survey_survey_q2_2022\";s:4:\"type\";s:6:\"survey\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:30:\"How is your store setup going?\";s:7:\"content\";s:232:\"Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:53:\"store_setup_survey_survey_q2_2022_share_your_thoughts\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Tell us how it’s going\";}}s:3:\"url\";s:52:\"https://automattic.survey.fm/store-setup-survey-2022\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-05-09 08:42:10\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:7;}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:9;}}}s:17:\"wc-admin-wisepad3\";O:8:\"stdClass\":8:{s:4:\"slug\";s:17:\"wc-admin-wisepad3\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:74:\"Take your business on the go in Canada with WooCommerce In-Person Payments\";s:7:\"content\";s:275:\"Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:17:\"wc-admin-wisepad3\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Grow my business offline\";}}s:3:\"url\";s:126:\"https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-06-15 10:00:28\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"CA\";}}}s:14:\"TikTok q2_2022\";O:8:\"stdClass\":8:{s:4:\"slug\";s:14:\"TikTok q2_2022\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:76:\"Give your store a stage on the world’s fastest-growing advertising channel\";s:7:\"content\";s:324:\"With TikTok for WooCommerce, you can sync your catalog, create videos, and track performance in front of TikTok’s one billion global users. Try the Smart Video Generator to make ads using your existing product images – no camera needed. Get $200 in ad credit from TikTok after a $20 spend (terms &amp; conditions apply).\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:14:\"TikTok q2_2022\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:29:\"Promote my products on TikTok\";}}s:3:\"url\";s:125:\"https://woocommerce.com/products/tiktok-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=TikTok q2_2022\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2022-06-21 17:00:39\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2022-07-05 23:59:00\";}}}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(542, 'wc_remote_inbox_notifications_stored_state', 'O:8:\"stdClass\":2:{s:22:\"there_were_no_products\";b:1;s:22:\"there_are_now_products\";b:1;}', 'no'),
(546, 'wc_blocks_surface_cart_checkout_probability', '7', 'yes'),
(547, 'wc_blocks_db_schema_version', '260', 'yes'),
(550, '_transient_wpforms_htaccess_file', 'a:3:{s:4:\"size\";i:737;s:5:\"mtime\";i:1653626519;s:5:\"ctime\";i:1653626519;}', 'yes'),
(551, 'action_scheduler_lock_async-request-runner', '1656822107', 'yes'),
(553, 'wpforms_email_summaries_fetch_info_blocks_last_run', '1656676475', 'yes'),
(554, 'wpforms_process_forms_locator_status', 'completed', 'yes'),
(556, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(559, 'wpforms_admin_notices', 'a:1:{s:14:\"review_request\";a:2:{s:4:\"time\";i:1653626543;s:9:\"dismissed\";b:0;}}', 'yes'),
(568, 'litespeed.gui.lscwp_whm_install', '-1', 'yes'),
(569, 'litespeed.gui.dismiss', '-1', 'yes'),
(570, 'litespeed.gui._summary', '{\"new_version\":1654231345,\"score\":1654836145}', 'yes'),
(571, 'monsterinsights_review', 'a:2:{s:4:\"time\";i:1653626545;s:9:\"dismissed\";b:0;}', 'yes'),
(572, 'litespeed.data.upgrading', '-1', 'yes'),
(573, 'litespeed.admin_display.messages', '-1', 'yes'),
(574, 'litespeed.admin_display.msg_pin', '-1', 'yes'),
(579, '_transient_product_query-transient-version', '1653637409', 'yes'),
(581, '_transient_shipping-transient-version', '1653626553', 'yes'),
(586, 'monsterinsights_notifications', 'a:4:{s:6:\"update\";i:1653626554;s:4:\"feed\";a:0:{}s:6:\"events\";a:0:{}s:9:\"dismissed\";a:0:{}}', 'no'),
(587, 'monsterinsights_notifications_run', 'a:25:{s:37:\"monsterinsights_notification_visitors\";i:1653626554;s:37:\"monsterinsights_notification_audience\";i:1653626554;s:55:\"monsterinsights_notification_mobile_device_high_traffic\";i:1653626554;s:42:\"monsterinsights_notification_mobile_device\";i:1653626554;s:43:\"monsterinsights_notification_upgrade_to_pro\";i:1653626554;s:56:\"monsterinsights_notification_upgrade_to_pro_high_traffic\";i:1653626554;s:40:\"monsterinsights_notification_bounce_rate\";i:1653626554;s:42:\"monsterinsights_notification_dual_tracking\";i:1653626554;s:47:\"monsterinsights_notification_returning_visitors\";i:1653626554;s:45:\"monsterinsights_notification_traffic_dropping\";i:1653626554;s:64:\"monsterinsights_notification_upgrade_for_popular_posts_templates\";i:1653626554;s:57:\"monsterinsights_notification_upgrade_for_events_reporting\";i:1653626554;s:62:\"monsterinsights_notification_upgrade_for_search_console_report\";i:1653626554;s:56:\"monsterinsights_notification_upgrade_for_form_conversion\";i:1653626554;s:56:\"monsterinsights_notification_upgrade_for_email_summaries\";i:1653626554;s:58:\"monsterinsights_notification_upgrade_for_custom_dimensions\";i:1653626554;s:56:\"monsterinsights_notification_upgrade_for_google_optimize\";i:1653626554;s:39:\"monsterinsights_notification_eu_traffic\";i:1653626554;s:56:\"monsterinsights_notification_to_add_more_file_extensions\";i:1653626554;s:53:\"monsterinsights_notification_to_setup_affiliate_links\";i:1653626554;s:46:\"monsterinsights_notification_headline_analyzer\";i:1653626554;s:49:\"monsterinsights_notification_install_optinmonster\";i:1653626554;s:43:\"monsterinsights_notification_install_aioseo\";i:1653626554;s:44:\"monsterinsights_notification_install_wpforms\";i:1653626554;s:43:\"monsterinsights_notification_multiple_gtags\";i:1653626554;}', 'no'),
(588, 'can_compress_scripts', '0', 'no'),
(600, 'wpforms_notifications', 'a:4:{s:6:\"update\";i:1653626585;s:4:\"feed\";a:0:{}s:6:\"events\";a:0:{}s:9:\"dismissed\";a:0:{}}', 'yes'),
(602, 'finished_updating_comment_type', '1', 'yes'),
(621, 'current_theme', 'Divi', 'yes'),
(622, 'theme_mods_Divi', 'a:5:{i:0;b:0;s:18:\"custom_css_post_id\";i:30;s:16:\"et_pb_css_synced\";s:3:\"yes\";s:18:\"nav_menu_locations\";a:1:{s:12:\"primary-menu\";i:19;}s:39:\"et_updated_layouts_built_for_post_types\";s:3:\"yes\";}', 'yes'),
(623, 'theme_switched', '', 'yes'),
(624, 'litespeed.optimize.timestamp_purge_css', '1653637410', 'yes'),
(625, 'et_pb_cache_notice', 'a:1:{s:5:\"4.8.0\";s:6:\"ignore\";}', 'yes'),
(628, '_transient_timeout_et_core_version', '1656953596', 'no'),
(629, '_transient_et_core_version', '4.8.0', 'no'),
(630, 'et_core_version', '4.8.0', 'yes'),
(632, 'et_divi', 'a:153:{s:39:\"static_css_custom_css_safety_check_done\";b:1;s:23:\"2_5_flush_rewrite_rules\";s:4:\"done\";s:30:\"et_flush_rewrite_rules_library\";s:5:\"4.8.0\";s:31:\"divi_previous_installed_version\";s:0:\"\";s:29:\"divi_latest_installed_version\";s:5:\"4.8.0\";s:27:\"divi_skip_font_subset_force\";b:1;s:27:\"et_pb_clear_templates_cache\";b:1;s:23:\"builder_custom_defaults\";O:8:\"stdClass\":0:{}s:33:\"customizer_settings_migrated_flag\";b:1;s:34:\"builder_custom_defaults_unmigrated\";b:0;s:40:\"divi_email_provider_credentials_migrated\";b:1;s:22:\"builder_global_presets\";O:8:\"stdClass\":0:{}s:29:\"custom_defaults_migrated_flag\";b:1;s:15:\"divi_1_3_images\";s:7:\"checked\";s:21:\"et_pb_layouts_updated\";b:1;s:30:\"library_removed_legacy_layouts\";b:1;s:30:\"divi_2_4_documentation_message\";s:9:\"triggered\";s:19:\"product_tour_status\";a:1:{i:1;s:3:\"off\";}s:32:\"et_fb_pref_settings_bar_location\";s:6:\"bottom\";s:28:\"et_fb_pref_builder_animation\";s:4:\"true\";s:41:\"et_fb_pref_builder_display_modal_settings\";s:5:\"false\";s:39:\"et_fb_pref_builder_enable_dummy_content\";s:4:\"true\";s:21:\"et_fb_pref_event_mode\";s:5:\"hover\";s:20:\"et_fb_pref_view_mode\";s:7:\"desktop\";s:32:\"et_fb_pref_hide_disabled_modules\";s:5:\"false\";s:28:\"et_fb_pref_history_intervals\";i:1;s:29:\"et_fb_pref_page_creation_flow\";s:7:\"default\";s:42:\"et_fb_pref_quick_actions_always_start_with\";s:7:\"nothing\";s:44:\"et_fb_pref_quick_actions_show_recent_queries\";s:3:\"off\";s:39:\"et_fb_pref_quick_actions_recent_queries\";s:0:\"\";s:40:\"et_fb_pref_quick_actions_recent_category\";s:0:\"\";s:27:\"et_fb_pref_modal_preference\";s:7:\"default\";s:30:\"et_fb_pref_modal_snap_location\";s:0:\"\";s:21:\"et_fb_pref_modal_snap\";s:5:\"false\";s:27:\"et_fb_pref_modal_fullscreen\";s:5:\"false\";s:32:\"et_fb_pref_modal_dimension_width\";i:400;s:33:\"et_fb_pref_modal_dimension_height\";i:400;s:27:\"et_fb_pref_modal_position_x\";i:30;s:27:\"et_fb_pref_modal_position_y\";i:50;s:24:\"et_fb_pref_toolbar_click\";s:5:\"false\";s:26:\"et_fb_pref_toolbar_desktop\";s:4:\"true\";s:23:\"et_fb_pref_toolbar_grid\";s:5:\"false\";s:24:\"et_fb_pref_toolbar_hover\";s:5:\"false\";s:24:\"et_fb_pref_toolbar_phone\";s:4:\"true\";s:25:\"et_fb_pref_toolbar_tablet\";s:4:\"true\";s:28:\"et_fb_pref_toolbar_wireframe\";s:4:\"true\";s:23:\"et_fb_pref_toolbar_zoom\";s:4:\"true\";s:36:\"et_fb_pref_lv_modal_dimension_height\";i:0;s:35:\"et_fb_pref_lv_modal_dimension_width\";i:0;s:30:\"et_fb_pref_lv_modal_position_x\";i:0;s:30:\"et_fb_pref_lv_modal_position_y\";i:0;s:34:\"et_fb_pref_responsive_tablet_width\";i:768;s:35:\"et_fb_pref_responsive_tablet_height\";i:0;s:33:\"et_fb_pref_responsive_phone_width\";i:400;s:34:\"et_fb_pref_responsive_phone_height\";i:0;s:35:\"et_fb_pref_responsive_minimum_width\";i:320;s:35:\"et_fb_pref_responsive_maximum_width\";i:980;s:24:\"footer_widget_text_color\";s:7:\"#ffffff\";s:24:\"footer_widget_link_color\";s:7:\"#ffffff\";s:13:\"nav_fullwidth\";b:1;s:23:\"secondary_nav_fullwidth\";b:0;s:9:\"divi_logo\";s:62:\"http://upmsmemart.com/wp-content/uploads/2022/05/LOGO_msme.png\";s:14:\"divi_fixed_nav\";s:2:\"on\";s:26:\"divi_gallery_layout_enable\";s:5:\"false\";s:18:\"divi_color_palette\";s:63:\"#000000|#ffffff|#e02b20|#e09900|#edf000|#7cda24|#0c71c3|#8300e9\";s:15:\"divi_grab_image\";s:5:\"false\";s:15:\"divi_blog_style\";s:5:\"false\";s:12:\"divi_sidebar\";s:16:\"et_right_sidebar\";s:22:\"divi_shop_page_sidebar\";s:16:\"et_right_sidebar\";s:23:\"divi_show_facebook_icon\";s:2:\"on\";s:22:\"divi_show_twitter_icon\";s:2:\"on\";s:21:\"divi_show_google_icon\";s:2:\"on\";s:24:\"divi_show_instagram_icon\";s:2:\"on\";s:18:\"divi_show_rss_icon\";s:2:\"on\";s:17:\"divi_facebook_url\";s:1:\"#\";s:16:\"divi_twitter_url\";s:1:\"#\";s:15:\"divi_google_url\";s:1:\"#\";s:18:\"divi_instagram_url\";s:1:\"#\";s:12:\"divi_rss_url\";s:0:\"\";s:34:\"divi_woocommerce_archive_num_posts\";i:9;s:17:\"divi_catnum_posts\";i:6;s:21:\"divi_archivenum_posts\";i:5;s:20:\"divi_searchnum_posts\";i:5;s:17:\"divi_tagnum_posts\";i:5;s:16:\"divi_date_format\";s:6:\"M j, Y\";s:16:\"divi_use_excerpt\";s:5:\"false\";s:26:\"divi_responsive_shortcodes\";s:2:\"on\";s:33:\"divi_gf_enable_all_character_sets\";s:5:\"false\";s:16:\"divi_back_to_top\";s:5:\"false\";s:18:\"divi_smooth_scroll\";s:5:\"false\";s:25:\"divi_disable_translations\";s:5:\"false\";s:29:\"divi_enable_responsive_images\";s:2:\"on\";s:27:\"divi_minify_combine_scripts\";s:2:\"on\";s:26:\"divi_minify_combine_styles\";s:2:\"on\";s:15:\"divi_custom_css\";s:0:\"\";s:21:\"divi_enable_dropdowns\";s:2:\"on\";s:14:\"divi_home_link\";s:2:\"on\";s:15:\"divi_sort_pages\";s:10:\"post_title\";s:15:\"divi_order_page\";s:3:\"asc\";s:22:\"divi_tiers_shown_pages\";i:3;s:32:\"divi_enable_dropdowns_categories\";s:2:\"on\";s:21:\"divi_categories_empty\";s:2:\"on\";s:27:\"divi_tiers_shown_categories\";i:3;s:13:\"divi_sort_cat\";s:4:\"name\";s:14:\"divi_order_cat\";s:3:\"asc\";s:20:\"divi_disable_toptier\";s:5:\"false\";s:27:\"et_pb_post_type_integration\";a:4:{s:4:\"post\";s:2:\"on\";s:4:\"page\";s:2:\"on\";s:7:\"project\";s:2:\"on\";s:7:\"product\";s:2:\"on\";}s:32:\"et_pb_woocommerce_product_layout\";s:16:\"et_right_sidebar\";s:29:\"et_pb_woocommerce_page_layout\";s:21:\"et_build_from_scratch\";s:21:\"et_pb_static_css_file\";s:2:\"on\";s:19:\"et_pb_css_in_footer\";s:3:\"off\";s:25:\"et_pb_product_tour_global\";s:2:\"on\";s:24:\"et_enable_classic_editor\";s:3:\"off\";s:14:\"divi_postinfo2\";a:4:{i:0;s:6:\"author\";i:1;s:4:\"date\";i:2;s:10:\"categories\";i:3;s:8:\"comments\";}s:22:\"divi_show_postcomments\";s:2:\"on\";s:15:\"divi_thumbnails\";s:2:\"on\";s:20:\"divi_page_thumbnails\";s:5:\"false\";s:23:\"divi_show_pagescomments\";s:5:\"false\";s:14:\"divi_postinfo1\";a:3:{i:0;s:6:\"author\";i:1;s:4:\"date\";i:2;s:10:\"categories\";}s:21:\"divi_thumbnails_index\";s:2:\"on\";s:19:\"divi_seo_home_title\";s:5:\"false\";s:25:\"divi_seo_home_description\";s:5:\"false\";s:22:\"divi_seo_home_keywords\";s:5:\"false\";s:23:\"divi_seo_home_canonical\";s:5:\"false\";s:23:\"divi_seo_home_titletext\";s:0:\"\";s:29:\"divi_seo_home_descriptiontext\";s:0:\"\";s:26:\"divi_seo_home_keywordstext\";s:0:\"\";s:22:\"divi_seo_home_separate\";s:3:\" | \";s:21:\"divi_seo_single_title\";s:5:\"false\";s:27:\"divi_seo_single_description\";s:5:\"false\";s:24:\"divi_seo_single_keywords\";s:5:\"false\";s:25:\"divi_seo_single_canonical\";s:5:\"false\";s:27:\"divi_seo_single_field_title\";s:9:\"seo_title\";s:33:\"divi_seo_single_field_description\";s:15:\"seo_description\";s:30:\"divi_seo_single_field_keywords\";s:12:\"seo_keywords\";s:24:\"divi_seo_single_separate\";s:3:\" | \";s:24:\"divi_seo_index_canonical\";s:5:\"false\";s:26:\"divi_seo_index_description\";s:5:\"false\";s:23:\"divi_seo_index_separate\";s:3:\" | \";s:28:\"divi_integrate_header_enable\";s:2:\"on\";s:26:\"divi_integrate_body_enable\";s:2:\"on\";s:31:\"divi_integrate_singletop_enable\";s:2:\"on\";s:34:\"divi_integrate_singlebottom_enable\";s:2:\"on\";s:21:\"divi_integration_head\";s:0:\"\";s:21:\"divi_integration_body\";s:0:\"\";s:27:\"divi_integration_single_top\";s:0:\"\";s:30:\"divi_integration_single_bottom\";s:0:\"\";s:15:\"divi_468_enable\";s:5:\"false\";s:14:\"divi_468_image\";s:0:\"\";s:12:\"divi_468_url\";s:0:\"\";s:16:\"divi_468_adsense\";s:0:\"\";s:21:\"custom_footer_credits\";s:29:\"2022@Copyright, UP MSME MART.\";s:27:\"bottom_bar_social_icon_size\";i:20;}', 'yes'),
(633, 'widget_aboutmewidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(634, 'widget_adsensewidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(635, 'widget_advwidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(636, 'shop_catalog_image_size', 'a:3:{s:5:\"width\";s:3:\"400\";s:6:\"height\";s:3:\"400\";s:4:\"crop\";i:1;}', 'yes'),
(637, 'shop_single_image_size', 'a:3:{s:5:\"width\";s:3:\"510\";s:6:\"height\";s:4:\"9999\";s:4:\"crop\";i:0;}', 'yes'),
(638, 'shop_thumbnail_image_size', 'a:3:{s:5:\"width\";s:3:\"157\";s:6:\"height\";s:3:\"157\";s:4:\"crop\";i:1;}', 'yes'),
(639, 'et_safe_mode_plugins_allowlist', 'a:8:{i:0;s:15:\"etdev/etdev.php\";i:1;s:15:\"bloom/bloom.php\";i:2;s:19:\"monarch/monarch.php\";i:3;s:29:\"divi-builder/divi-builder.php\";i:4;s:27:\"ari-adminer/ari-adminer.php\";i:5;s:31:\"query-monitor/query-monitor.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:47:\"really-simple-ssl/rlrsssl-really-simple-ssl.php\";}', 'yes'),
(640, 'et_support_center_installed', 'true', 'yes'),
(641, 'et_images_temp_folder', '/home/u920553048/domains/upmsmemart.com/public_html/wp-content/uploads/et_temp', 'yes'),
(642, 'et_schedule_clean_images_last_time', '1656676474', 'yes'),
(643, 'et_bfb_settings', 'a:2:{s:10:\"enable_bfb\";s:2:\"on\";s:10:\"toggle_bfb\";s:2:\"on\";}', 'yes'),
(644, '_transient_et_builder_show_bfb_welcome_modal', '1', 'yes'),
(645, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes'),
(650, 'et_support_center_setup_done', 'processed', 'yes'),
(651, 'et_pb_builder_options', 'a:2:{i:0;b:0;s:35:\"email_provider_credentials_migrated\";b:1;}', 'yes'),
(652, '_transient_woocommerce_reports-transient-version', '1653627481', 'yes'),
(672, 'et_automatic_updates_options', 'a:2:{s:8:\"username\";s:5:\"UPICO\";s:7:\"api_key\";s:40:\"799f9c30999565193134c67e0f6298aef1cea001\";}', 'no'),
(673, 'et_account_status', 'active', 'no'),
(674, 'et_support_site_id', '^IY@e(o+T5QlCEBOt0zn', 'yes'),
(681, 'et_pb_signup_67abf27e4c961dd13b8557b77a273334', 'off', 'yes'),
(698, 'woocommerce_task_list_tracked_completed_tasks', 'a:3:{i:0;s:8:\"purchase\";i:1;s:14:\"store_creation\";i:2;s:8:\"products\";}', 'yes'),
(699, 'woocommerce_task_list_completed_lists', 'a:2:{i:0;s:8:\"extended\";i:1;s:19:\"extended_two_column\";}', 'yes'),
(702, 'woocommerce_marketplace_suggestions', 'a:2:{s:11:\"suggestions\";a:27:{i:0;a:4:{s:4:\"slug\";s:28:\"product-edit-meta-tab-header\";s:7:\"context\";s:28:\"product-edit-meta-tab-header\";s:5:\"title\";s:22:\"Recommended extensions\";s:13:\"allow-dismiss\";b:0;}i:1;a:6:{s:4:\"slug\";s:39:\"product-edit-meta-tab-footer-browse-all\";s:7:\"context\";s:28:\"product-edit-meta-tab-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:2;a:9:{s:4:\"slug\";s:46:\"product-edit-mailchimp-woocommerce-memberships\";s:7:\"product\";s:33:\"woocommerce-memberships-mailchimp\";s:14:\"show-if-active\";a:1:{i:0;s:23:\"woocommerce-memberships\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:116:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/mailchimp-for-memberships.svg\";s:5:\"title\";s:25:\"Mailchimp for Memberships\";s:4:\"copy\";s:79:\"Completely automate your email lists by syncing membership changes to Mailchimp\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:67:\"https://woocommerce.com/products/mailchimp-woocommerce-memberships/\";}i:3;a:9:{s:4:\"slug\";s:19:\"product-edit-addons\";s:7:\"product\";s:26:\"woocommerce-product-addons\";s:14:\"show-if-active\";a:2:{i:0;s:25:\"woocommerce-subscriptions\";i:1;s:20:\"woocommerce-bookings\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-add-ons.svg\";s:5:\"title\";s:15:\"Product Add-Ons\";s:4:\"copy\";s:93:\"Offer add-ons like gift wrapping, special messages or other special options for your products\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-add-ons/\";}i:4;a:9:{s:4:\"slug\";s:46:\"product-edit-woocommerce-subscriptions-gifting\";s:7:\"product\";s:33:\"woocommerce-subscriptions-gifting\";s:14:\"show-if-active\";a:1:{i:0;s:25:\"woocommerce-subscriptions\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:116:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/gifting-for-subscriptions.svg\";s:5:\"title\";s:25:\"Gifting for Subscriptions\";s:4:\"copy\";s:70:\"Let customers buy subscriptions for others - they\'re the ultimate gift\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:67:\"https://woocommerce.com/products/woocommerce-subscriptions-gifting/\";}i:5;a:9:{s:4:\"slug\";s:42:\"product-edit-teams-woocommerce-memberships\";s:7:\"product\";s:33:\"woocommerce-memberships-for-teams\";s:14:\"show-if-active\";a:1:{i:0;s:23:\"woocommerce-memberships\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:112:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/teams-for-memberships.svg\";s:5:\"title\";s:21:\"Teams for Memberships\";s:4:\"copy\";s:123:\"Adds B2B functionality to WooCommerce Memberships, allowing sites to sell team, group, corporate, or family member accounts\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:63:\"https://woocommerce.com/products/teams-woocommerce-memberships/\";}i:6;a:8:{s:4:\"slug\";s:29:\"product-edit-variation-images\";s:7:\"product\";s:39:\"woocommerce-additional-variation-images\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:118:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/additional-variation-images.svg\";s:5:\"title\";s:27:\"Additional Variation Images\";s:4:\"copy\";s:72:\"Showcase your products in the best light with a image for each variation\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:73:\"https://woocommerce.com/products/woocommerce-additional-variation-images/\";}i:7;a:9:{s:4:\"slug\";s:47:\"product-edit-woocommerce-subscription-downloads\";s:7:\"product\";s:34:\"woocommerce-subscription-downloads\";s:14:\"show-if-active\";a:1:{i:0;s:25:\"woocommerce-subscriptions\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:113:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscription-downloads.svg\";s:5:\"title\";s:22:\"Subscription Downloads\";s:4:\"copy\";s:57:\"Give customers special downloads with their subscriptions\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:68:\"https://woocommerce.com/products/woocommerce-subscription-downloads/\";}i:8;a:8:{s:4:\"slug\";s:31:\"product-edit-min-max-quantities\";s:7:\"product\";s:30:\"woocommerce-min-max-quantities\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:109:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/min-max-quantities.svg\";s:5:\"title\";s:18:\"Min/Max Quantities\";s:4:\"copy\";s:81:\"Specify minimum and maximum allowed product quantities for orders to be completed\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:52:\"https://woocommerce.com/products/min-max-quantities/\";}i:9;a:8:{s:4:\"slug\";s:28:\"product-edit-name-your-price\";s:7:\"product\";s:27:\"woocommerce-name-your-price\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/name-your-price.svg\";s:5:\"title\";s:15:\"Name Your Price\";s:4:\"copy\";s:70:\"Let customers pay what they want - useful for donations, tips and more\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/name-your-price/\";}i:10;a:8:{s:4:\"slug\";s:42:\"product-edit-woocommerce-one-page-checkout\";s:7:\"product\";s:29:\"woocommerce-one-page-checkout\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:108:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/one-page-checkout.svg\";s:5:\"title\";s:17:\"One Page Checkout\";s:4:\"copy\";s:92:\"Don\'t make customers click around - let them choose products, checkout & pay all on one page\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:63:\"https://woocommerce.com/products/woocommerce-one-page-checkout/\";}i:11;a:4:{s:4:\"slug\";s:19:\"orders-empty-header\";s:7:\"context\";s:24:\"orders-list-empty-header\";s:5:\"title\";s:20:\"Tools for your store\";s:13:\"allow-dismiss\";b:0;}i:12;a:6:{s:4:\"slug\";s:30:\"orders-empty-footer-browse-all\";s:7:\"context\";s:24:\"orders-list-empty-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:13;a:8:{s:4:\"slug\";s:19:\"orders-empty-wc-pay\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-payments\";s:4:\"icon\";s:111:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/woocommerce-payments.svg\";s:5:\"title\";s:20:\"WooCommerce Payments\";s:4:\"copy\";s:125:\"Securely accept payments and manage transactions directly from your WooCommerce dashboard – no setup costs or monthly fees.\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-payments/\";}i:14;a:8:{s:4:\"slug\";s:19:\"orders-empty-zapier\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:18:\"woocommerce-zapier\";s:4:\"icon\";s:97:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/zapier.svg\";s:5:\"title\";s:6:\"Zapier\";s:4:\"copy\";s:88:\"Save time and increase productivity by connecting your store to more than 1000+ services\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:52:\"https://woocommerce.com/products/woocommerce-zapier/\";}i:15;a:8:{s:4:\"slug\";s:30:\"orders-empty-shipment-tracking\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:29:\"woocommerce-shipment-tracking\";s:4:\"icon\";s:108:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipment-tracking.svg\";s:5:\"title\";s:17:\"Shipment Tracking\";s:4:\"copy\";s:86:\"Let customers know when their orders will arrive by adding shipment tracking to emails\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:51:\"https://woocommerce.com/products/shipment-tracking/\";}i:16;a:8:{s:4:\"slug\";s:32:\"orders-empty-table-rate-shipping\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:31:\"woocommerce-table-rate-shipping\";s:4:\"icon\";s:110:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/table-rate-shipping.svg\";s:5:\"title\";s:19:\"Table Rate Shipping\";s:4:\"copy\";s:122:\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:53:\"https://woocommerce.com/products/table-rate-shipping/\";}i:17;a:8:{s:4:\"slug\";s:40:\"orders-empty-shipping-carrier-extensions\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:4:\"icon\";s:118:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipping-carrier-extensions.svg\";s:5:\"title\";s:27:\"Shipping Carrier Extensions\";s:4:\"copy\";s:116:\"Show live rates from FedEx, UPS, USPS and more directly on your store - never under or overcharge for shipping again\";s:11:\"button-text\";s:13:\"Find Carriers\";s:8:\"promoted\";s:26:\"category-shipping-carriers\";s:3:\"url\";s:99:\"https://woocommerce.com/product-category/woocommerce-extensions/shipping-methods/shipping-carriers/\";}i:18;a:8:{s:4:\"slug\";s:32:\"orders-empty-google-product-feed\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:25:\"woocommerce-product-feeds\";s:4:\"icon\";s:110:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/google-product-feed.svg\";s:5:\"title\";s:19:\"Google Product Feed\";s:4:\"copy\";s:76:\"Increase sales by letting customers find you when they\'re shopping on Google\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:53:\"https://woocommerce.com/products/google-product-feed/\";}i:19;a:4:{s:4:\"slug\";s:35:\"products-empty-header-product-types\";s:7:\"context\";s:26:\"products-list-empty-header\";s:5:\"title\";s:23:\"Other types of products\";s:13:\"allow-dismiss\";b:0;}i:20;a:6:{s:4:\"slug\";s:32:\"products-empty-footer-browse-all\";s:7:\"context\";s:26:\"products-list-empty-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:21;a:8:{s:4:\"slug\";s:30:\"products-empty-product-vendors\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:27:\"woocommerce-product-vendors\";s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-vendors.svg\";s:5:\"title\";s:15:\"Product Vendors\";s:4:\"copy\";s:47:\"Turn your store into a multi-vendor marketplace\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-vendors/\";}i:22;a:8:{s:4:\"slug\";s:26:\"products-empty-memberships\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:23:\"woocommerce-memberships\";s:4:\"icon\";s:102:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/memberships.svg\";s:5:\"title\";s:11:\"Memberships\";s:4:\"copy\";s:76:\"Give members access to restricted content or products, for a fee or for free\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:57:\"https://woocommerce.com/products/woocommerce-memberships/\";}i:23;a:9:{s:4:\"slug\";s:35:\"products-empty-woocommerce-deposits\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-deposits\";s:14:\"show-if-active\";a:1:{i:0;s:20:\"woocommerce-bookings\";}s:4:\"icon\";s:99:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/deposits.svg\";s:5:\"title\";s:8:\"Deposits\";s:4:\"copy\";s:75:\"Make it easier for customers to pay by offering a deposit or a payment plan\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-deposits/\";}i:24;a:8:{s:4:\"slug\";s:40:\"products-empty-woocommerce-subscriptions\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:25:\"woocommerce-subscriptions\";s:4:\"icon\";s:104:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg\";s:5:\"title\";s:13:\"Subscriptions\";s:4:\"copy\";s:97:\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:59:\"https://woocommerce.com/products/woocommerce-subscriptions/\";}i:25;a:8:{s:4:\"slug\";s:35:\"products-empty-woocommerce-bookings\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-bookings\";s:4:\"icon\";s:99:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/bookings.svg\";s:5:\"title\";s:8:\"Bookings\";s:4:\"copy\";s:99:\"Allow customers to book appointments, make reservations or rent equipment without leaving your site\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-bookings/\";}i:26;a:8:{s:4:\"slug\";s:30:\"products-empty-product-bundles\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:27:\"woocommerce-product-bundles\";s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-bundles.svg\";s:5:\"title\";s:15:\"Product Bundles\";s:4:\"copy\";s:49:\"Offer customizable bundles and assembled products\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-bundles/\";}}s:7:\"updated\";i:1653628318;}', 'no'),
(708, 'product_cat_children', 'a:0:{}', 'yes'),
(719, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(720, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(726, 'et_pb_signup_2b1b772b9479175d89fa8b3a3a63e54c', 'off', 'yes'),
(731, 'et_google_api_settings', 'a:3:{s:7:\"api_key\";s:0:\"\";s:26:\"enqueue_google_maps_script\";s:2:\"on\";s:16:\"use_google_fonts\";s:2:\"on\";}', 'yes'),
(754, '_transient_product-transient-version', '1653637307', 'yes'),
(759, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(1771, '_transient_health-check-site-status-result', '{\"good\":17,\"recommended\":5,\"critical\":1}', 'yes'),
(17495, '_transient_timeout__omapi_validate', '1656908447', 'no'),
(17496, '_transient__omapi_validate', '1', 'no'),
(18170, 'category_children', 'a:0:{}', 'yes'),
(20042, 'woocommerce_task_list_reminder_bar_hidden', 'yes', 'yes'),
(20251, '_transient_timeout_wc_product_loop_11cdaf508e97c76fbe4c110cd5383515', '1658905738', 'no'),
(20252, '_transient_wc_product_loop_11cdaf508e97c76fbe4c110cd5383515', 'a:2:{s:7:\"version\";s:10:\"1653637409\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:1:{i:0;i:24;}s:5:\"total\";i:1;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:4;s:12:\"current_page\";i:1;}}', 'no'),
(20253, '_transient_timeout_wc_product_loop_704c75c2d82e3590dad0c3ce9e4ee7c5', '1658905739', 'no'),
(20254, '_transient_wc_product_loop_704c75c2d82e3590dad0c3ce9e4ee7c5', 'a:2:{s:7:\"version\";s:10:\"1653637409\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:1:{i:0;i:24;}s:5:\"total\";i:1;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:6;s:12:\"current_page\";i:1;}}', 'no'),
(20554, '_transient_timeout_wc_term_counts', '1659355096', 'no'),
(20555, '_transient_wc_term_counts', 'a:1:{i:17;s:1:\"1\";}', 'no'),
(20556, '_transient_timeout_wc_related_24', '1656849497', 'no'),
(20557, '_transient_wc_related_24', 'a:1:{s:50:\"limit=3&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=24\";a:0:{}}', 'no'),
(20776, '_transient_timeout__woocommerce_helper_subscriptions', '1656866579', 'no'),
(20777, '_transient__woocommerce_helper_subscriptions', 'a:0:{}', 'no'),
(20778, '_site_transient_timeout_theme_roots', '1656867479', 'no'),
(20779, '_site_transient_theme_roots', 'a:4:{s:4:\"Divi\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";s:15:\"twentytwentytwo\";s:7:\"/themes\";}', 'no'),
(20780, '_transient_timeout__woocommerce_helper_updates', '1656908879', 'no'),
(20781, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1656865679;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no'),
(20782, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1656865682;s:7:\"checked\";a:4:{s:4:\"Divi\";s:5:\"4.8.0\";s:12:\"twentytwenty\";s:3:\"2.0\";s:15:\"twentytwentyone\";s:3:\"1.6\";s:15:\"twentytwentytwo\";s:3:\"1.2\";}s:8:\"response\";a:1:{s:4:\"Divi\";a:4:{s:11:\"new_version\";s:6:\"4.17.4\";s:5:\"theme\";s:4:\"Divi\";s:3:\"url\";s:52:\"https://www.elegantthemes.com/api/changelog/divi.txt\";s:7:\"package\";s:139:\"https://www.elegantthemes.com/api/api_downloads.php?api_update=1&theme=Divi&api_key=799f9c30999565193134c67e0f6298aef1cea001&username=UPICO\";}}s:9:\"no_update\";a:3:{s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.2.0.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.6.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}s:15:\"twentytwentytwo\";a:6:{s:5:\"theme\";s:15:\"twentytwentytwo\";s:11:\"new_version\";s:3:\"1.2\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentytwo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentytwo.1.2.zip\";s:8:\"requires\";s:3:\"5.9\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(20783, '_site_transient_et_update_themes', 'O:8:\"stdClass\":3:{s:7:\"checked\";a:4:{s:4:\"Divi\";s:5:\"4.8.0\";s:12:\"twentytwenty\";s:3:\"2.0\";s:15:\"twentytwentyone\";s:3:\"1.6\";s:15:\"twentytwentytwo\";s:3:\"1.2\";}s:8:\"response\";a:1:{s:4:\"Divi\";a:4:{s:11:\"new_version\";s:6:\"4.17.4\";s:5:\"theme\";s:4:\"Divi\";s:3:\"url\";s:52:\"https://www.elegantthemes.com/api/changelog/divi.txt\";s:7:\"package\";s:139:\"https://www.elegantthemes.com/api/api_downloads.php?api_update=1&theme=Divi&api_key=799f9c30999565193134c67e0f6298aef1cea001&username=UPICO\";}}s:12:\"last_checked\";i:1656865682;}', 'no'),
(20784, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1656865683;s:8:\"response\";a:5:{s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:37:\"w.org/plugins/all-in-one-wp-migration\";s:4:\"slug\";s:23:\"all-in-one-wp-migration\";s:6:\"plugin\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:11:\"new_version\";s:4:\"7.62\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/all-in-one-wp-migration/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/all-in-one-wp-migration.7.62.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/all-in-one-wp-migration/assets/icon-256x256.png?rev=2458334\";s:2:\"1x\";s:76:\"https://ps.w.org/all-in-one-wp-migration/assets/icon-128x128.png?rev=2458334\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/all-in-one-wp-migration/assets/banner-1544x500.png?rev=2746234\";s:2:\"1x\";s:78:\"https://ps.w.org/all-in-one-wp-migration/assets/banner-772x250.png?rev=2746234\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.3\";s:6:\"tested\";s:3:\"6.0\";s:12:\"requires_php\";s:6:\"5.2.17\";}s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:33:\"w.org/plugins/all-in-one-seo-pack\";s:4:\"slug\";s:19:\"all-in-one-seo-pack\";s:6:\"plugin\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:11:\"new_version\";s:5:\"4.2.2\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/all-in-one-seo-pack/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/all-in-one-seo-pack.4.2.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:72:\"https://ps.w.org/all-in-one-seo-pack/assets/icon-256x256.png?rev=2443290\";s:2:\"1x\";s:64:\"https://ps.w.org/all-in-one-seo-pack/assets/icon.svg?rev=2443290\";s:3:\"svg\";s:64:\"https://ps.w.org/all-in-one-seo-pack/assets/icon.svg?rev=2443290\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/all-in-one-seo-pack/assets/banner-1544x500.png?rev=2443290\";s:2:\"1x\";s:74:\"https://ps.w.org/all-in-one-seo-pack/assets/banner-772x250.png?rev=2443290\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";s:6:\"tested\";s:3:\"6.0\";s:12:\"requires_php\";s:3:\"5.4\";s:14:\"upgrade_notice\";s:56:\"<p>This update adds major improvements and bugfixes.</p>\";}s:50:\"google-analytics-for-wordpress/googleanalytics.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:44:\"w.org/plugins/google-analytics-for-wordpress\";s:4:\"slug\";s:30:\"google-analytics-for-wordpress\";s:6:\"plugin\";s:50:\"google-analytics-for-wordpress/googleanalytics.php\";s:11:\"new_version\";s:5:\"8.6.0\";s:3:\"url\";s:61:\"https://wordpress.org/plugins/google-analytics-for-wordpress/\";s:7:\"package\";s:79:\"https://downloads.wordpress.org/plugin/google-analytics-for-wordpress.8.6.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:83:\"https://ps.w.org/google-analytics-for-wordpress/assets/icon-256x256.png?rev=1598927\";s:2:\"1x\";s:75:\"https://ps.w.org/google-analytics-for-wordpress/assets/icon.svg?rev=1598927\";s:3:\"svg\";s:75:\"https://ps.w.org/google-analytics-for-wordpress/assets/icon.svg?rev=1598927\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:86:\"https://ps.w.org/google-analytics-for-wordpress/assets/banner-1544x500.png?rev=2159532\";s:2:\"1x\";s:85:\"https://ps.w.org/google-analytics-for-wordpress/assets/banner-772x250.png?rev=2159532\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"4.8.0\";s:6:\"tested\";s:3:\"6.0\";s:12:\"requires_php\";s:3:\"5.5\";}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"6.6.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.6.6.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.8\";s:6:\"tested\";s:3:\"6.0\";s:12:\"requires_php\";s:3:\"7.2\";}s:24:\"wpforms-lite/wpforms.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:26:\"w.org/plugins/wpforms-lite\";s:4:\"slug\";s:12:\"wpforms-lite\";s:6:\"plugin\";s:24:\"wpforms-lite/wpforms.php\";s:11:\"new_version\";s:7:\"1.7.5.1\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wpforms-lite/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wpforms-lite.1.7.5.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:65:\"https://ps.w.org/wpforms-lite/assets/icon-256x256.png?rev=2574201\";s:2:\"1x\";s:57:\"https://ps.w.org/wpforms-lite/assets/icon.svg?rev=2574198\";s:3:\"svg\";s:57:\"https://ps.w.org/wpforms-lite/assets/icon.svg?rev=2574198\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wpforms-lite/assets/banner-1544x500.png?rev=2602491\";s:2:\"1x\";s:67:\"https://ps.w.org/wpforms-lite/assets/banner-772x250.png?rev=2602491\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/wpforms-lite/assets/banner-1544x500-rtl.png?rev=2602491\";s:2:\"1x\";s:71:\"https://ps.w.org/wpforms-lite/assets/banner-772x250-rtl.png?rev=2602491\";}s:8:\"requires\";s:3:\"5.2\";s:6:\"tested\";s:3:\"6.0\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.2.4\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.2.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582\";s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:35:\"litespeed-cache/litespeed-cache.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:29:\"w.org/plugins/litespeed-cache\";s:4:\"slug\";s:15:\"litespeed-cache\";s:6:\"plugin\";s:35:\"litespeed-cache/litespeed-cache.php\";s:11:\"new_version\";s:3:\"4.6\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/litespeed-cache/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/litespeed-cache.4.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/litespeed-cache/assets/icon-256x256.png?rev=2554181\";s:2:\"1x\";s:68:\"https://ps.w.org/litespeed-cache/assets/icon-128x128.png?rev=2554181\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/litespeed-cache/assets/banner-1544x500.png?rev=2554181\";s:2:\"1x\";s:70:\"https://ps.w.org/litespeed-cache/assets/banner-772x250.png?rev=2554181\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.0\";}s:37:\"optinmonster/optin-monster-wp-api.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:26:\"w.org/plugins/optinmonster\";s:4:\"slug\";s:12:\"optinmonster\";s:6:\"plugin\";s:37:\"optinmonster/optin-monster-wp-api.php\";s:11:\"new_version\";s:5:\"2.7.0\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/optinmonster/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/optinmonster.2.7.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/optinmonster/assets/icon-256x256.png?rev=1145864\";s:2:\"1x\";s:65:\"https://ps.w.org/optinmonster/assets/icon-128x128.png?rev=1145864\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/optinmonster/assets/banner-1544x500.png?rev=2311621\";s:2:\"1x\";s:67:\"https://ps.w.org/optinmonster/assets/banner-772x250.png?rev=2311621\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"4.7.0\";}}s:7:\"checked\";a:10:{s:19:\"akismet/akismet.php\";s:5:\"4.2.4\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:4:\"7.61\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:7:\"4.2.1.1\";s:50:\"google-analytics-for-wordpress/googleanalytics.php\";s:5:\"8.5.3\";s:9:\"hello.php\";s:5:\"1.7.2\";s:19:\"Hostinger/index.php\";s:3:\"1.0\";s:35:\"litespeed-cache/litespeed-cache.php\";s:3:\"4.6\";s:37:\"optinmonster/optin-monster-wp-api.php\";s:5:\"2.7.0\";s:27:\"woocommerce/woocommerce.php\";s:5:\"6.5.1\";s:24:\"wpforms-lite/wpforms.php\";s:7:\"1.7.4.2\";}}', 'no'),
(20785, '_site_transient_et_update_all_plugins', 'O:8:\"stdClass\":3:{s:7:\"checked\";a:10:{s:19:\"akismet/akismet.php\";s:5:\"4.2.4\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:4:\"7.61\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:7:\"4.2.1.1\";s:50:\"google-analytics-for-wordpress/googleanalytics.php\";s:5:\"8.5.3\";s:9:\"hello.php\";s:5:\"1.7.2\";s:19:\"Hostinger/index.php\";s:3:\"1.0\";s:35:\"litespeed-cache/litespeed-cache.php\";s:3:\"4.6\";s:37:\"optinmonster/optin-monster-wp-api.php\";s:5:\"2.7.0\";s:27:\"woocommerce/woocommerce.php\";s:5:\"6.5.1\";s:24:\"wpforms-lite/wpforms.php\";s:7:\"1.7.4.2\";}s:8:\"response\";a:0:{}s:12:\"last_checked\";i:1656865683;}', 'no'),
(20786, '_transient_timeout_et_core_path', '1656953596', 'no'),
(20787, '_transient_et_core_path', '/home/u920553048/domains/upmsmemart.com/public_html/wp-content/themes/Divi/core', 'no'),
(20829, '_transient_timeout_global_styles_Divi', '1656907478', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(20830, '_transient_global_styles_Divi', 'body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url(\'#wp-duotone-dark-grayscale\');--wp--preset--duotone--grayscale: url(\'#wp-duotone-grayscale\');--wp--preset--duotone--purple-yellow: url(\'#wp-duotone-purple-yellow\');--wp--preset--duotone--blue-red: url(\'#wp-duotone-blue-red\');--wp--preset--duotone--midnight: url(\'#wp-duotone-midnight\');--wp--preset--duotone--magenta-yellow: url(\'#wp-duotone-magenta-yellow\');--wp--preset--duotone--purple-green: url(\'#wp-duotone-purple-green\');--wp--preset--duotone--blue-orange: url(\'#wp-duotone-blue-orange\');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 4, '_wp_attached_file', 'woocommerce-placeholder.png'),
(4, 4, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:8:\"filesize\";i:102644;s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10546;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1803;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:31893;}s:6:\"medium\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10546;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:84297;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3767;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:49572;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(7, 12, '_edit_lock', '1653628160:1'),
(8, 12, '_edit_last', '1'),
(9, 12, '_aioseo_title', NULL),
(10, 12, '_aioseo_description', NULL),
(11, 12, '_aioseo_keywords', ''),
(12, 12, '_aioseo_og_title', NULL),
(13, 12, '_aioseo_og_description', NULL),
(14, 12, '_aioseo_og_article_section', ''),
(15, 12, '_aioseo_og_article_tags', ''),
(16, 12, '_aioseo_twitter_title', NULL),
(17, 12, '_aioseo_twitter_description', NULL),
(18, 12, '_et_pb_post_hide_nav', 'default'),
(19, 12, '_et_pb_page_layout', 'et_right_sidebar'),
(20, 12, '_et_pb_side_nav', 'off'),
(21, 12, '_et_pb_use_builder', 'on'),
(22, 12, '_et_pb_show_page_creation', 'off'),
(23, 12, '_et_pb_old_content', ''),
(24, 16, '_wp_attached_file', '2022/05/boutique_48-1.jpg'),
(25, 16, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:310;s:6:\"height\";i:558;s:4:\"file\";s:25:\"2022/05/boutique_48-1.jpg\";s:8:\"filesize\";i:60301;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-167x300.jpg\";s:5:\"width\";i:167;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12892;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6537;}s:21:\"et-pb-post-main-image\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-310x250.jpg\";s:5:\"width\";i:310;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17837;}s:21:\"et-pb-portfolio-image\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-310x284.jpg\";s:5:\"width\";i:310;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20723;}s:28:\"et-pb-portfolio-module-image\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-310x382.jpg\";s:5:\"width\";i:310;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29181;}s:35:\"et-pb-gallery-module-image-portrait\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-310x516.jpg\";s:5:\"width\";i:310;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:38277;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:25:\"boutique_48-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19505;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3497;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19505;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:25:\"boutique_48-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3497;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(26, 17, '_wp_attached_file', '2022/05/boutique_49-1.jpg'),
(27, 17, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:695;s:6:\"height\";i:665;s:4:\"file\";s:25:\"2022/05/boutique_49-1.jpg\";s:8:\"filesize\";i:87050;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-300x287.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:287;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11834;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4245;}s:21:\"et-pb-post-main-image\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:17322;}s:21:\"et-pb-portfolio-image\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18019;}s:28:\"et-pb-portfolio-module-image\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-510x382.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27392;}s:35:\"et-pb-gallery-module-image-portrait\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-400x516.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29850;}s:30:\"et-pb-image--responsive--phone\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-480x459.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:459;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25965;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:25:\"boutique_49-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12619;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-600x574.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:574;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:38107;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2427;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12619;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-600x574.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:574;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:38107;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:25:\"boutique_49-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2427;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(28, 18, '_wp_attached_file', '2022/05/boutique_49.jpg'),
(29, 18, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:525;s:6:\"height\";i:788;s:4:\"file\";s:23:\"2022/05/boutique_49.jpg\";s:8:\"filesize\";i:78963;s:5:\"sizes\";a:12:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"boutique_49-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8418;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_49-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4371;}s:21:\"et-pb-post-main-image\";a:5:{s:4:\"file\";s:23:\"boutique_49-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13290;}s:31:\"et-pb-post-main-image-fullwidth\";a:5:{s:4:\"file\";s:23:\"boutique_49-525x675.jpg\";s:5:\"width\";i:525;s:6:\"height\";i:675;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:44454;}s:21:\"et-pb-portfolio-image\";a:5:{s:4:\"file\";s:23:\"boutique_49-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15547;}s:28:\"et-pb-portfolio-module-image\";a:5:{s:4:\"file\";s:23:\"boutique_49-510x382.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:25280;}s:35:\"et-pb-gallery-module-image-portrait\";a:5:{s:4:\"file\";s:23:\"boutique_49-400x516.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24497;}s:30:\"et-pb-image--responsive--phone\";a:5:{s:4:\"file\";s:23:\"boutique_49-480x720.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:720;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:36259;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"boutique_49-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13208;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_49-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2432;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:23:\"boutique_49-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13208;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_49-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2432;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(30, 19, '_wp_attached_file', '2022/05/boutique_04.jpg'),
(31, 19, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:525;s:6:\"height\";i:340;s:4:\"file\";s:23:\"2022/05/boutique_04.jpg\";s:8:\"filesize\";i:25073;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"boutique_04-300x194.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:194;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9765;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_04-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4190;}s:21:\"et-pb-post-main-image\";a:5:{s:4:\"file\";s:23:\"boutique_04-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14604;}s:21:\"et-pb-portfolio-image\";a:5:{s:4:\"file\";s:23:\"boutique_04-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15887;}s:28:\"et-pb-portfolio-module-image\";a:5:{s:4:\"file\";s:23:\"boutique_04-510x340.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:340;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24261;}s:35:\"et-pb-gallery-module-image-portrait\";a:5:{s:4:\"file\";s:23:\"boutique_04-400x340.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:340;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19119;}s:30:\"et-pb-image--responsive--phone\";a:5:{s:4:\"file\";s:23:\"boutique_04-480x311.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:311;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20143;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"boutique_04-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12359;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_04-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2435;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:23:\"boutique_04-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:12359;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_04-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2435;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(32, 20, '_wp_attached_file', '2022/05/boutique_46.jpg'),
(33, 20, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1365;s:6:\"height\";i:667;s:4:\"file\";s:23:\"2022/05/boutique_46.jpg\";s:8:\"filesize\";i:567494;s:5:\"sizes\";a:19:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"boutique_46-300x147.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:147;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11579;}s:5:\"large\";a:5:{s:4:\"file\";s:24:\"boutique_46-1024x500.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:78596;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_46-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7901;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:23:\"boutique_46-768x375.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:49255;}s:21:\"et-pb-post-main-image\";a:5:{s:4:\"file\";s:23:\"boutique_46-400x250.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23404;}s:31:\"et-pb-post-main-image-fullwidth\";a:5:{s:4:\"file\";s:24:\"boutique_46-1080x667.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:667;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:120490;}s:21:\"et-pb-portfolio-image\";a:5:{s:4:\"file\";s:23:\"boutique_46-400x284.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:27314;}s:28:\"et-pb-portfolio-module-image\";a:5:{s:4:\"file\";s:23:\"boutique_46-510x382.jpg\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42296;}s:28:\"et-pb-portfolio-image-single\";a:5:{s:4:\"file\";s:24:\"boutique_46-1080x528.jpg\";s:5:\"width\";i:1080;s:6:\"height\";i:528;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:85524;}s:35:\"et-pb-gallery-module-image-portrait\";a:5:{s:4:\"file\";s:23:\"boutique_46-400x516.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:44364;}s:32:\"et-pb-image--responsive--desktop\";a:5:{s:4:\"file\";s:24:\"boutique_46-1280x625.jpg\";s:5:\"width\";i:1280;s:6:\"height\";i:625;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:113721;}s:31:\"et-pb-image--responsive--tablet\";a:5:{s:4:\"file\";s:23:\"boutique_46-980x479.jpg\";s:5:\"width\";i:980;s:6:\"height\";i:479;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:73029;}s:30:\"et-pb-image--responsive--phone\";a:5:{s:4:\"file\";s:23:\"boutique_46-480x235.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:235;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23945;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"boutique_46-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24020;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:23:\"boutique_46-600x293.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:293;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33787;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_46-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4192;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:23:\"boutique_46-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:24020;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:23:\"boutique_46-600x293.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:293;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33787;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_46-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4192;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(34, 21, '_wp_attached_file', '2022/05/boutique_47.png'),
(35, 21, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:620;s:6:\"height\";i:840;s:4:\"file\";s:23:\"2022/05/boutique_47.png\";s:8:\"filesize\";i:168035;s:5:\"sizes\";a:14:{s:6:\"medium\";a:5:{s:4:\"file\";s:23:\"boutique_47-221x300.png\";s:5:\"width\";i:221;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:97157;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_47-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:36415;}s:21:\"et-pb-post-main-image\";a:5:{s:4:\"file\";s:23:\"boutique_47-400x250.png\";s:5:\"width\";i:400;s:6:\"height\";i:250;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:119846;}s:31:\"et-pb-post-main-image-fullwidth\";a:5:{s:4:\"file\";s:23:\"boutique_47-620x675.png\";s:5:\"width\";i:620;s:6:\"height\";i:675;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:388796;}s:21:\"et-pb-portfolio-image\";a:5:{s:4:\"file\";s:23:\"boutique_47-400x284.png\";s:5:\"width\";i:400;s:6:\"height\";i:284;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:143697;}s:28:\"et-pb-portfolio-module-image\";a:5:{s:4:\"file\";s:23:\"boutique_47-510x382.png\";s:5:\"width\";i:510;s:6:\"height\";i:382;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:243243;}s:35:\"et-pb-gallery-module-image-portrait\";a:5:{s:4:\"file\";s:23:\"boutique_47-400x516.png\";s:5:\"width\";i:400;s:6:\"height\";i:516;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:272462;}s:30:\"et-pb-image--responsive--phone\";a:5:{s:4:\"file\";s:23:\"boutique_47-480x650.png\";s:5:\"width\";i:480;s:6:\"height\";i:650;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:406615;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:23:\"boutique_47-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:125962;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:23:\"boutique_47-600x813.png\";s:5:\"width\";i:600;s:6:\"height\";i:813;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:615729;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_47-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:17873;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:23:\"boutique_47-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:125962;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:23:\"boutique_47-600x813.png\";s:5:\"width\";i:600;s:6:\"height\";i:813;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:615729;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:23:\"boutique_47-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:17873;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(36, 12, '_et_pb_built_for_post_type', 'page'),
(37, 12, '_et_pb_ab_subjects', ''),
(38, 12, '_et_pb_enable_shortcode_tracking', ''),
(39, 12, '_et_pb_ab_current_shortcode', '[et_pb_split_track id=\"12\" /]'),
(40, 12, '_et_pb_custom_css', ''),
(41, 12, '_et_pb_gutter_width', '3'),
(42, 12, '_thumbnail_id', '0'),
(43, 12, '_et_pb_first_image', ''),
(44, 12, '_et_pb_truncate_post', ''),
(45, 12, '_et_pb_truncate_post_date', ''),
(46, 12, '_et_pb_product_page_layout', 'et_build_from_scratch'),
(47, 12, '_et_builder_version', 'VB|Divi|4.8.0'),
(48, 24, '_edit_last', '1'),
(49, 24, '_edit_lock', '1653637326:1'),
(52, 12, 'et_enqueued_post_fonts', 'a:2:{s:6:\"family\";a:1:{s:12:\"et-gf-roboto\";s:91:\"Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic\";}s:6:\"subset\";a:2:{i:0;s:5:\"latin\";i:1;s:9:\"latin-ext\";}}'),
(59, 29, '_wp_attached_file', '2022/05/LOGO_msme.png'),
(60, 29, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:334;s:6:\"height\";i:197;s:4:\"file\";s:21:\"2022/05/LOGO_msme.png\";s:8:\"filesize\";i:23476;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:21:\"LOGO_msme-300x177.png\";s:5:\"width\";i:300;s:6:\"height\";i:177;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:21687;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:21:\"LOGO_msme-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:15334;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:21:\"LOGO_msme-300x197.png\";s:5:\"width\";i:300;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:19188;s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:21:\"LOGO_msme-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:9114;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:21:\"LOGO_msme-300x197.png\";s:5:\"width\";i:300;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:19188;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:21:\"LOGO_msme-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:9114;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(61, 24, '_thumbnail_id', '17'),
(62, 24, '_regular_price', '15'),
(63, 24, '_sale_price', '10'),
(64, 24, 'total_sales', '0'),
(65, 24, '_tax_status', 'taxable'),
(66, 24, '_tax_class', ''),
(67, 24, '_manage_stock', 'no'),
(68, 24, '_backorders', 'no'),
(69, 24, '_sold_individually', 'no'),
(70, 24, '_virtual', 'no'),
(71, 24, '_downloadable', 'no'),
(72, 24, '_download_limit', '-1'),
(73, 24, '_download_expiry', '-1'),
(74, 24, '_stock', NULL),
(75, 24, '_stock_status', 'instock'),
(76, 24, '_wc_average_rating', '0'),
(77, 24, '_wc_review_count', '0'),
(78, 24, '_product_version', '6.5.1'),
(79, 24, '_price', '10'),
(80, 24, '_aioseo_title', NULL),
(81, 24, '_aioseo_description', '#post_title #separator_sa #taxonomy_title'),
(82, 24, '_aioseo_keywords', ''),
(83, 24, '_aioseo_og_title', NULL),
(84, 24, '_aioseo_og_description', NULL),
(85, 24, '_aioseo_og_article_section', ''),
(86, 24, '_aioseo_og_article_tags', ''),
(87, 24, '_aioseo_twitter_title', NULL),
(88, 24, '_aioseo_twitter_description', NULL),
(89, 24, '_et_pb_post_hide_nav', 'default'),
(90, 24, '_et_pb_page_layout', 'et_right_sidebar'),
(91, 24, '_et_pb_side_nav', 'off'),
(92, 24, '_et_pb_use_builder', ''),
(93, 24, '_et_pb_first_image', ''),
(94, 24, '_et_pb_truncate_post', ''),
(95, 24, '_et_pb_truncate_post_date', ''),
(96, 24, '_et_pb_old_content', ''),
(97, 24, 'om_disable_all_campaigns', ''),
(98, 32, '_menu_item_type', 'post_type'),
(99, 32, '_menu_item_menu_item_parent', '0'),
(100, 32, '_menu_item_object_id', '12'),
(101, 32, '_menu_item_object', 'page'),
(102, 32, '_menu_item_target', ''),
(103, 32, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(104, 32, '_menu_item_xfn', ''),
(105, 32, '_menu_item_url', ''),
(107, 33, '_menu_item_type', 'post_type'),
(108, 33, '_menu_item_menu_item_parent', '0'),
(109, 33, '_menu_item_object_id', '6'),
(110, 33, '_menu_item_object', 'page'),
(111, 33, '_menu_item_target', ''),
(112, 33, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(113, 33, '_menu_item_xfn', ''),
(114, 33, '_menu_item_url', ''),
(116, 34, '_menu_item_type', 'post_type'),
(117, 34, '_menu_item_menu_item_parent', '0'),
(118, 34, '_menu_item_object_id', '7'),
(119, 34, '_menu_item_object', 'page'),
(120, 34, '_menu_item_target', ''),
(121, 34, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(122, 34, '_menu_item_xfn', ''),
(123, 34, '_menu_item_url', ''),
(125, 35, '_menu_item_type', 'post_type'),
(126, 35, '_menu_item_menu_item_parent', '0'),
(127, 35, '_menu_item_object_id', '8'),
(128, 35, '_menu_item_object', 'page'),
(129, 35, '_menu_item_target', ''),
(130, 35, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(131, 35, '_menu_item_xfn', ''),
(132, 35, '_menu_item_url', ''),
(134, 36, '_menu_item_type', 'post_type'),
(135, 36, '_menu_item_menu_item_parent', '0'),
(136, 36, '_menu_item_object_id', '5'),
(137, 36, '_menu_item_object', 'page'),
(138, 36, '_menu_item_target', ''),
(139, 36, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(140, 36, '_menu_item_xfn', ''),
(141, 36, '_menu_item_url', ''),
(146, 12, '_et_pb_color_palette', '#000000|#FFFFFF|#E02B20|#E09900|#EDF000|#7CDA24|#0C71C3|#8300E9');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-05-27 04:18:25', '2022-05-27 04:18:25', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2022-05-27 04:18:25', '2022-05-27 04:18:25', '', 0, 'http://upmsmemart.com/?p=1', 0, 'post', '', 1),
(2, 1, '2022-05-27 04:18:25', '2022-05-27 04:18:25', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://upmsmemart.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2022-05-27 04:18:25', '2022-05-27 04:18:25', '', 0, 'http://upmsmemart.com/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-05-27 04:18:25', '2022-05-27 04:18:25', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://upmsmemart.com.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-05-27 04:18:25', '2022-05-27 04:18:25', '', 0, 'http://upmsmemart.com/?page_id=3', 0, 'page', '', 0),
(4, 0, '2022-05-27 04:18:53', '2022-05-27 04:18:53', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2022-05-27 04:18:53', '2022-05-27 04:18:53', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(5, 1, '2022-05-27 04:18:55', '2022-05-27 04:18:55', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2022-05-27 04:18:55', '2022-05-27 04:18:55', '', 0, 'http://upmsmemart.com/?page_id=5', 0, 'page', '', 0),
(6, 1, '2022-05-27 04:18:55', '2022-05-27 04:18:55', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2022-05-27 04:18:55', '2022-05-27 04:18:55', '', 0, 'http://upmsmemart.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-05-27 04:18:55', '2022-05-27 04:18:55', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2022-05-27 04:18:55', '2022-05-27 04:18:55', '', 0, 'http://upmsmemart.com/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-05-27 04:18:55', '2022-05-27 04:18:55', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2022-05-27 04:18:55', '2022-05-27 04:18:55', '', 0, 'http://upmsmemart.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2022-05-27 04:18:55', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'draft', 'closed', 'closed', '', 'refund_returns', '', '', '2022-05-27 04:18:55', '0000-00-00 00:00:00', '', 0, 'http://upmsmemart.com/?page_id=9', 0, 'page', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(12, 1, '2022-05-27 04:58:34', '2022-05-27 04:58:34', '[et_pb_section fb_built=\"1\" admin_label=\"Hero Section\" _builder_version=\"3.22\" background_color=\"#d3dae4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px|0px|110px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" max_width=\"1280px\" custom_padding=\"|||\" use_custom_width=\"on\" custom_width_px=\"1280px\" collapsed=\"off\" column_structure=\"1_2,1_2\"][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_48-1.jpg\" align=\"center\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"right\" animation_intensity_slide=\"4%\" animation=\"off\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"40px||40px|\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Subtitle\" _builder_version=\"3.27.4\" text_font=\"Roboto|on||on|\" text_text_color=\"#2a2a2a\" text_font_size=\"18px\" text_letter_spacing=\"4px\" animation_style=\"zoom\" animation_direction=\"left\" animation_intensity_zoom=\"10%\"]Summer Sale\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_font_size=\"52px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" custom_margin=\"||20px|\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"50ms\" animation_intensity_zoom=\"10%\" header_2_font_size_tablet=\"40px\" header_2_font_size_phone=\"\" header_2_font_size_last_edited=\"on|desktop\"]<h2>Vintage  Collection</h2>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" header_font=\"||||||||\" custom_margin=\"|||\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"100ms\" animation_intensity_zoom=\"10%\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor, sit amet tempor mauris eleifend a. In et bibendum eros c interdum sapien, et sagittis dui. Nunc fringilla mattis dolor\r[/et_pb_text][et_pb_text admin_label=\"Price\" _builder_version=\"3.27.4\" text_font=\"|700|||||||\" text_text_color=\"#2a2a2a\" text_font_size=\"30px\" custom_margin=\"||40px|\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"150ms\" animation_intensity_zoom=\"10%\"]20% OFF\r[/et_pb_text][et_pb_button button_url=\"#\" button_text=\"Shop Now\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"200ms\" animation_intensity_zoom=\"10%\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Features\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" collapsed=\"off\" column_structure=\"1_3,1_3,1_3\"][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\"]01\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Local Makers &amp; Artisans</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\" animation_delay=\"100ms\"]02\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Free Local SHipping</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\" animation_delay=\"200ms\" locked=\"off\"]03\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h4>Money Back Guarantee</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Popular Product Section\" _builder_version=\"3.22\" custom_padding=\"110px|0px|110px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Popular Products Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Trending Products</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" animation_style=\"fade\" custom_css_main_element=\"||\" locked=\"off\"][/et_pb_divider][et_pb_shop posts_number=\"4\" columns_number=\"4\" orderby=\"menu_order\" icon_hover_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" _builder_version=\"3.25.3\" title_font=\"Roboto||||\" title_text_color=\"#000000\" price_font=\"|600|||||||\" price_text_color=\"#ffb500\" hover_enabled=\"0\" sticky_enabled=\"0\"][/et_pb_shop][et_pb_button button_url=\"#\" button_text=\"Browse All\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Featured Items\" _builder_version=\"3.22\" background_color=\"#f4f4f4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|desktop\" custom_padding=\"110px||110px|\" box_shadow_style=\"preset7\" box_shadow_horizontal=\"0px\" box_shadow_vertical=\"-400px\" box_shadow_color=\"#ffffff\" collapsed=\"off\"][et_pb_row use_custom_gutter=\"on\" gutter_width=\"2\" make_equal=\"on\" _builder_version=\"3.25\" custom_padding=\"27px|0px|0px|0px\" column_structure=\"1_2,1_2\"][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"12%|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"left\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h2>Featured Items</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" max_width_tablet=\"\" max_width_phone=\"\" max_width_last_edited=\"on|desktop\" custom_margin=\"||100px|\" animation_style=\"fade\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor, sit amet tempor mauris eleifend a. In et bibendum eros, eget arcu. Nulla nec elit sit amet arcu molestie volutpat volutpat vitae dui.\r[/et_pb_text][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49-1.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"||6%|\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_04.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Products\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" locked=\"off\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_margin=\"|||\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_line_height=\"1.2em\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>New Products</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.23.4\" height=\"50px\" animation_style=\"fade\" custom_css_main_element=\"margin: 0 auto;||width: 100px;||||\" locked=\"off\"][/et_pb_divider][et_pb_shop posts_number=\"6\" columns_number=\"3\" orderby=\"menu_order\" icon_hover_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" _builder_version=\"3.25.3\" title_font=\"Roboto||||\" title_text_color=\"#000000\" price_font=\"|600|||||||\" price_text_color=\"#ffb500\"][/et_pb_shop][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Promo\" _builder_version=\"3.22\" background_color=\"rgba(12,12,12,0.6)\" background_image=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_46.jpg\" background_blend=\"color\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"160px||160px|\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"2%\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||on||||||\" text_font_size=\"30px\" text_orientation=\"center\" background_layout=\"dark\" module_alignment=\"center\" custom_padding=\"||10px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"300ms\" animation_intensity_slide=\"8%\"]Only at <span style=\"color: #ffb500; font-size: 60px; font-style: normal;\"><strong>$19</strong></span>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"52px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" background_layout=\"dark\" module_alignment=\"center\" custom_margin=\"||10px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"200ms\" animation_intensity_slide=\"8%\" header_2_font_size_tablet=\"40px\" header_2_font_size_phone=\"\" header_2_font_size_last_edited=\"on|tablet\"]<h2>Flash Sale!</h2>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"20px\" text_line_height=\"1.6em\" text_orientation=\"center\" background_layout=\"dark\" max_width=\"700px\" module_alignment=\"center\" custom_margin=\"|||\" custom_padding=\"||30px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"100ms\" animation_intensity_slide=\"8%\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam, felis in consectetur rutrum, lectus urna malesuada ligula.\r[/et_pb_text][et_pb_button button_url=\"#\" button_text=\"Shop This Sale\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_bg_color=\"#ffb500\" button_border_color=\"#ffb500\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"Roboto|on||on|\" button_use_icon=\"off\" background_layout=\"dark\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"20%\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffffff\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"rgba(255,181,0,0)\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffffff\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"rgba(255,181,0,0)\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Subscribe\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"0px|||\" column_structure=\"1_4,1_2,1_4\"][et_pb_column type=\"1_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Stay up to date</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" height=\"2px\" custom_margin=\"|||\" custom_padding=\"|||\" animation_style=\"fade\" custom_css_main_element=\"||\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" text_orientation=\"center\" max_width_tablet=\"\" max_width_phone=\"\" max_width_last_edited=\"on|desktop\" custom_margin=\"|||\" animation_style=\"fade\" locked=\"off\"]Get notified about the newest products and upcoming sales\r[/et_pb_text][et_pb_signup mailchimp_list=\"SlavaET|03dac884f0\" name_field=\"on\" _builder_version=\"3.23\" use_background_color=\"off\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"Roboto|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" hover_enabled=\"0\" border_radii_fields=\"on|100px|100px|100px|100px\" border_width_all_fields=\"2px\" border_color_all_fields=\"rgba(0,0,0,0.12)\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"rgba(0,0,0,0)\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"rgba(0,0,0,0)\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\" sticky_enabled=\"0\"][/et_pb_signup][/et_pb_column][et_pb_column type=\"1_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Testimonials\" _builder_version=\"3.22\" background_color=\"#f4f4f4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"27px|0px|0px|0px\" locked=\"off\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Happy Customers</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" animation_style=\"fade\" custom_css_main_element=\"||||\" locked=\"off\"][/et_pb_divider][/et_pb_column][/et_pb_row][et_pb_row use_custom_gutter=\"on\" gutter_width=\"2\" column_padding_mobile=\"on\" custom_padding_last_edited=\"on|tablet\" _builder_version=\"3.25\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" custom_margin=\"0px|||\" custom_padding=\"0px|0px|27px|0px\" custom_padding_tablet=\"49px|||\" custom_padding_phone=\"29px|||\" custom_width_px=\"544px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_slider show_pagination=\"off\" admin_label=\"Testimonial\" _builder_version=\"3.16\" header_font=\"Roboto||||\" header_text_color=\"#ffffff\" header_font_size=\"36\" header_line_height=\"1.4em\" body_font=\"Roboto||||\" body_text_color=\"#ffffff\" body_font_size=\"20\" body_line_height=\"1.5em\" background_position=\"top_left\" custom_padding=\"80px|0px|100px|0px\" custom_padding_tablet=\"|||\" custom_padding_phone=\"|||\" auto=\"on\" top_padding=\"80px\" bottom_padding=\"100px\" remove_inner_shadow=\"on\" show_inner_shadow=\"off\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][et_pb_slide heading=\"%22Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam, felis in consectetur rutrum, lectus urna malesuada ligula, eget pulvinar dui leo at eros.%22\" use_bg_overlay=\"off\" use_text_overlay=\"off\" arrows_custom_color=\"#666666\" _builder_version=\"3.16\" header_font=\"||on||\" header_text_color=\"#666666\" header_font_size=\"22px\" header_line_height=\"1.8em\" body_font=\"Roboto|||on|\" body_text_color=\"#666666\" background_color=\"rgba(255,255,255,0)\" button_icon_placement=\"right\" button_on_hover=\"on\" custom_css_slide_title=\"margin-bottom:32px;||text-shadow: none;||||||\" custom_css_slide_description=\"text-shadow: none;\" sticky_transition=\"on\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"]<strong>Dan Virgillito</strong>\r\n<p style=\"margin-top: -15px;\">Interior Designer</p>\r[/et_pb_slide][et_pb_slide heading=\"“Mauris id fermentum neque. Donec fermentum sapien eget dolor fringilla pharetra. In cursus, arcu vitae dictum fringilla, sapien metus gravida augue.%22\" use_bg_overlay=\"off\" use_text_overlay=\"off\" arrows_custom_color=\"#666666\" _builder_version=\"3.16\" header_font=\"||on||\" header_text_color=\"#666666\" header_font_size=\"22px\" header_line_height=\"1.8em\" body_font=\"Roboto|||on|\" body_text_color=\"#666666\" background_color=\"rgba(255,255,255,0)\" button_icon_placement=\"right\" button_on_hover=\"on\" custom_css_slide_title=\"margin-bottom:32px;||text-shadow: none;||||||\" custom_css_slide_description=\"text-shadow: none;\" sticky_transition=\"on\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"]<strong>Dan Virgillito</strong>\r\n<p style=\"margin-top: -15px;\">Blogger</p>\r[/et_pb_slide][/et_pb_slider][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" disabled_on=\"on|on|on\" admin_label=\"Blog \" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\" disabled=\"on\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"27px|0px|27px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Our Blog</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" animation_style=\"fade\" custom_css_main_element=\"margin: 0 auto;||width: 100px;||||\" locked=\"off\"][/et_pb_divider][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.25\" max_width=\"1440px\" use_custom_width=\"on\" custom_width_px=\"1440px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_blog fullwidth=\"off\" posts_number=\"3\" show_categories=\"off\" show_comments=\"on\" show_pagination=\"off\" masonry_tile_background_color=\"#ffffff\" _builder_version=\"3.0.105\" header_font=\"Roboto|||on|\" header_text_color=\"#000000\" header_font_size=\"20px\" header_line_height=\"1.4em\" body_font=\"Open Sans||||\" body_font_size=\"16px\" body_line_height=\"1.8em\" hover_enabled=\"0\" border_width_all=\"1px\" border_color_all=\"#efefef\" border_style_all=\"solid\" border_width_all_fullwidth=\"1px\" border_color_all_fullwidth=\"#efefef\" border_style_all_fullwidth=\"solid\" use_border_color=\"on\" border_color=\"#efefef\" sticky_enabled=\"0\"][/et_pb_blog][et_pb_button button_url=\"#\" button_text=\"Read More\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" locked=\"off\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Footer\" _builder_version=\"3.22\" background_color=\"#d3dae4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px|0px|0px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" column_structure=\"1_3,1_3,1_3\"][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"40px|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Visit Us</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\"][/et_pb_divider][et_pb_text _builder_version=\"4.8.0\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" hover_enabled=\"0\" sticky_enabled=\"0\"]<p>1235 Summit, Vibhuti Khand</p>\n<p>Gomti Nagar, Lucknow-226010</p>\n[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"40px|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Open Hours</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]M-F: 8am - 6pm\r\n\r\nS &amp; S: closed\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_47.png\" show_bottom_space=\"off\" align=\"center\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"4%\" animation=\"off\"][/et_pb_image][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2022-05-27 07:48:12', '2022-05-27 07:48:12', '', 0, 'http://upmsmemart.com/?page_id=12', 0, 'page', '', 0),
(13, 1, '2022-05-27 04:58:17', '2022-05-27 04:58:17', '{\"version\": 2, \"isGlobalStylesUserThemeJSON\": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-divi', '', '', '2022-05-27 04:58:17', '2022-05-27 04:58:17', '', 0, 'http://upmsmemart.com/?p=13', 0, 'wp_global_styles', '', 0),
(14, 1, '2022-05-27 04:58:34', '2022-05-27 04:58:34', '', 'About', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2022-05-27 04:58:34', '2022-05-27 04:58:34', '', 12, 'http://upmsmemart.com/?p=14', 0, 'revision', '', 0),
(15, 1, '2022-05-27 05:01:18', '2022-05-27 05:01:18', '[et_pb_section admin_label=\"section\"]\n			[et_pb_row admin_label=\"row\"]\n				[et_pb_column type=\"4_4\"][/et_pb_column]\n			[/et_pb_row]\n		[/et_pb_section]', 'About', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2022-05-27 05:01:18', '2022-05-27 05:01:18', '', 12, 'http://upmsmemart.com/?p=15', 0, 'revision', '', 0),
(16, 1, '2022-05-27 05:02:23', '2022-05-27 05:02:23', '', 'boutique_48-1', '', 'inherit', 'open', 'closed', '', 'boutique_48-1', '', '', '2022-05-27 05:02:23', '2022-05-27 05:02:23', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/boutique_48-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2022-05-27 05:02:24', '2022-05-27 05:02:24', '', 'boutique_49-1', '', 'inherit', 'open', 'closed', '', 'boutique_49-1', '', '', '2022-05-27 05:02:24', '2022-05-27 05:02:24', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2022-05-27 05:02:26', '2022-05-27 05:02:26', '', 'boutique_49', '', 'inherit', 'open', 'closed', '', 'boutique_49', '', '', '2022-05-27 05:02:26', '2022-05-27 05:02:26', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2022-05-27 05:02:28', '2022-05-27 05:02:28', '', 'boutique_04', '', 'inherit', 'open', 'closed', '', 'boutique_04', '', '', '2022-05-27 05:02:28', '2022-05-27 05:02:28', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/boutique_04.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2022-05-27 05:02:30', '2022-05-27 05:02:30', '', 'boutique_46', '', 'inherit', 'open', 'closed', '', 'boutique_46', '', '', '2022-05-27 05:02:30', '2022-05-27 05:02:30', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/boutique_46.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2022-05-27 05:02:38', '2022-05-27 05:02:38', '', 'boutique_47', '', 'inherit', 'open', 'closed', '', 'boutique_47', '', '', '2022-05-27 05:02:38', '2022-05-27 05:02:38', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/boutique_47.png', 0, 'attachment', 'image/png', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(23, 1, '2022-05-27 05:10:51', '2022-05-27 05:10:51', '[et_pb_section fb_built=\"1\" admin_label=\"Hero Section\" _builder_version=\"3.22\" background_color=\"#d3dae4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px|0px|110px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" max_width=\"1280px\" custom_padding=\"|||\" use_custom_width=\"on\" custom_width_px=\"1280px\" collapsed=\"off\" column_structure=\"1_2,1_2\"][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_48-1.jpg\" align=\"center\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"right\" animation_intensity_slide=\"4%\" animation=\"off\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"40px||40px|\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Subtitle\" _builder_version=\"3.27.4\" text_font=\"Roboto|on||on|\" text_text_color=\"#2a2a2a\" text_font_size=\"18px\" text_letter_spacing=\"4px\" animation_style=\"zoom\" animation_direction=\"left\" animation_intensity_zoom=\"10%\"]Summer Sale\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_font_size=\"52px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" custom_margin=\"||20px|\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"50ms\" animation_intensity_zoom=\"10%\" header_2_font_size_tablet=\"40px\" header_2_font_size_phone=\"\" header_2_font_size_last_edited=\"on|desktop\"]<h2>Vintage  Collection</h2>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" header_font=\"||||||||\" custom_margin=\"|||\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"100ms\" animation_intensity_zoom=\"10%\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor, sit amet tempor mauris eleifend a. In et bibendum eros c interdum sapien, et sagittis dui. Nunc fringilla mattis dolor\r[/et_pb_text][et_pb_text admin_label=\"Price\" _builder_version=\"3.27.4\" text_font=\"|700|||||||\" text_text_color=\"#2a2a2a\" text_font_size=\"30px\" custom_margin=\"||40px|\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"150ms\" animation_intensity_zoom=\"10%\"]20% OFF\r[/et_pb_text][et_pb_button button_url=\"#\" button_text=\"Shop Now\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"200ms\" animation_intensity_zoom=\"10%\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Features\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" collapsed=\"off\" column_structure=\"1_3,1_3,1_3\"][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\"]01\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Local Makers &amp; Artisans</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\" animation_delay=\"100ms\"]02\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Free Local SHipping</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\" animation_delay=\"200ms\" locked=\"off\"]03\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h4>Money Back Guarantee</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Popular Product Section\" _builder_version=\"3.22\" custom_padding=\"110px|0px|110px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Popular Products Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Trending Products</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" animation_style=\"fade\" custom_css_main_element=\"||\" locked=\"off\"][/et_pb_divider][et_pb_shop posts_number=\"4\" columns_number=\"4\" orderby=\"menu_order\" icon_hover_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" _builder_version=\"3.25.3\" title_font=\"Roboto||||\" title_text_color=\"#000000\" price_font=\"|600|||||||\" price_text_color=\"#ffb500\" hover_enabled=\"0\" sticky_enabled=\"0\"][/et_pb_shop][et_pb_button button_url=\"#\" button_text=\"Browse All\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Featured Items\" _builder_version=\"3.22\" background_color=\"#f4f4f4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|desktop\" custom_padding=\"110px||110px|\" box_shadow_style=\"preset7\" box_shadow_horizontal=\"0px\" box_shadow_vertical=\"-400px\" box_shadow_color=\"#ffffff\" collapsed=\"off\"][et_pb_row use_custom_gutter=\"on\" gutter_width=\"2\" make_equal=\"on\" _builder_version=\"3.25\" custom_padding=\"27px|0px|0px|0px\" column_structure=\"1_2,1_2\"][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"12%|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"left\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h2>Featured Items</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" max_width_tablet=\"\" max_width_phone=\"\" max_width_last_edited=\"on|desktop\" custom_margin=\"||100px|\" animation_style=\"fade\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor, sit amet tempor mauris eleifend a. In et bibendum eros, eget arcu. Nulla nec elit sit amet arcu molestie volutpat volutpat vitae dui.\r[/et_pb_text][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49-1.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"||6%|\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_04.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Products\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" locked=\"off\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_margin=\"|||\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_line_height=\"1.2em\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>New Products</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.23.4\" height=\"50px\" animation_style=\"fade\" custom_css_main_element=\"margin: 0 auto;||width: 100px;||||\" locked=\"off\"][/et_pb_divider][et_pb_shop posts_number=\"6\" columns_number=\"3\" orderby=\"menu_order\" icon_hover_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" _builder_version=\"3.25.3\" title_font=\"Roboto||||\" title_text_color=\"#000000\" price_font=\"|600|||||||\" price_text_color=\"#ffb500\"][/et_pb_shop][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Promo\" _builder_version=\"3.22\" background_color=\"rgba(12,12,12,0.6)\" background_image=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_46.jpg\" background_blend=\"color\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"160px||160px|\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"2%\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||on||||||\" text_font_size=\"30px\" text_orientation=\"center\" background_layout=\"dark\" module_alignment=\"center\" custom_padding=\"||10px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"300ms\" animation_intensity_slide=\"8%\"]Only at <span style=\"color: #ffb500; font-size: 60px; font-style: normal;\"><strong>$19</strong></span>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"52px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" background_layout=\"dark\" module_alignment=\"center\" custom_margin=\"||10px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"200ms\" animation_intensity_slide=\"8%\" header_2_font_size_tablet=\"40px\" header_2_font_size_phone=\"\" header_2_font_size_last_edited=\"on|tablet\"]<h2>Flash Sale!</h2>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"20px\" text_line_height=\"1.6em\" text_orientation=\"center\" background_layout=\"dark\" max_width=\"700px\" module_alignment=\"center\" custom_margin=\"|||\" custom_padding=\"||30px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"100ms\" animation_intensity_slide=\"8%\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam, felis in consectetur rutrum, lectus urna malesuada ligula.\r[/et_pb_text][et_pb_button button_url=\"#\" button_text=\"Shop This Sale\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_bg_color=\"#ffb500\" button_border_color=\"#ffb500\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"Roboto|on||on|\" button_use_icon=\"off\" background_layout=\"dark\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"20%\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffffff\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"rgba(255,181,0,0)\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffffff\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"rgba(255,181,0,0)\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Subscribe\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"0px|||\" column_structure=\"1_4,1_2,1_4\"][et_pb_column type=\"1_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Stay up to date</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" height=\"2px\" custom_margin=\"|||\" custom_padding=\"|||\" animation_style=\"fade\" custom_css_main_element=\"||\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" text_orientation=\"center\" max_width_tablet=\"\" max_width_phone=\"\" max_width_last_edited=\"on|desktop\" custom_margin=\"|||\" animation_style=\"fade\" locked=\"off\"]Get notified about the newest products and upcoming sales\r[/et_pb_text][et_pb_signup mailchimp_list=\"SlavaET|03dac884f0\" name_field=\"on\" _builder_version=\"3.23\" use_background_color=\"off\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"Roboto|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" hover_enabled=\"0\" border_radii_fields=\"on|100px|100px|100px|100px\" border_width_all_fields=\"2px\" border_color_all_fields=\"rgba(0,0,0,0.12)\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"rgba(0,0,0,0)\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"rgba(0,0,0,0)\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\" sticky_enabled=\"0\"][/et_pb_signup][/et_pb_column][et_pb_column type=\"1_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Testimonials\" _builder_version=\"3.22\" background_color=\"#f4f4f4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"27px|0px|0px|0px\" locked=\"off\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Happy Customers</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" animation_style=\"fade\" custom_css_main_element=\"||||\" locked=\"off\"][/et_pb_divider][/et_pb_column][/et_pb_row][et_pb_row use_custom_gutter=\"on\" gutter_width=\"2\" column_padding_mobile=\"on\" custom_padding_last_edited=\"on|tablet\" _builder_version=\"3.25\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" custom_margin=\"0px|||\" custom_padding=\"0px|0px|27px|0px\" custom_padding_tablet=\"49px|||\" custom_padding_phone=\"29px|||\" custom_width_px=\"544px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_slider show_pagination=\"off\" admin_label=\"Testimonial\" _builder_version=\"3.16\" header_font=\"Roboto||||\" header_text_color=\"#ffffff\" header_font_size=\"36\" header_line_height=\"1.4em\" body_font=\"Roboto||||\" body_text_color=\"#ffffff\" body_font_size=\"20\" body_line_height=\"1.5em\" background_position=\"top_left\" custom_padding=\"80px|0px|100px|0px\" custom_padding_tablet=\"|||\" custom_padding_phone=\"|||\" auto=\"on\" top_padding=\"80px\" bottom_padding=\"100px\" remove_inner_shadow=\"on\" show_inner_shadow=\"off\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][et_pb_slide heading=\"%22Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam, felis in consectetur rutrum, lectus urna malesuada ligula, eget pulvinar dui leo at eros.%22\" use_bg_overlay=\"off\" use_text_overlay=\"off\" arrows_custom_color=\"#666666\" _builder_version=\"3.16\" header_font=\"||on||\" header_text_color=\"#666666\" header_font_size=\"22px\" header_line_height=\"1.8em\" body_font=\"Roboto|||on|\" body_text_color=\"#666666\" background_color=\"rgba(255,255,255,0)\" button_icon_placement=\"right\" button_on_hover=\"on\" custom_css_slide_title=\"margin-bottom:32px;||text-shadow: none;||||||\" custom_css_slide_description=\"text-shadow: none;\" sticky_transition=\"on\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"]<strong>Dan Virgillito</strong>\r\n<p style=\"margin-top: -15px;\">Interior Designer</p>\r[/et_pb_slide][et_pb_slide heading=\"“Mauris id fermentum neque. Donec fermentum sapien eget dolor fringilla pharetra. In cursus, arcu vitae dictum fringilla, sapien metus gravida augue.%22\" use_bg_overlay=\"off\" use_text_overlay=\"off\" arrows_custom_color=\"#666666\" _builder_version=\"3.16\" header_font=\"||on||\" header_text_color=\"#666666\" header_font_size=\"22px\" header_line_height=\"1.8em\" body_font=\"Roboto|||on|\" body_text_color=\"#666666\" background_color=\"rgba(255,255,255,0)\" button_icon_placement=\"right\" button_on_hover=\"on\" custom_css_slide_title=\"margin-bottom:32px;||text-shadow: none;||||||\" custom_css_slide_description=\"text-shadow: none;\" sticky_transition=\"on\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"]<strong>Dan Virgillito</strong>\r\n<p style=\"margin-top: -15px;\">Blogger</p>\r[/et_pb_slide][/et_pb_slider][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" disabled_on=\"off|off|off\" admin_label=\"Blog \" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"27px|0px|27px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Our Blog</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" animation_style=\"fade\" custom_css_main_element=\"margin: 0 auto;||width: 100px;||||\" locked=\"off\"][/et_pb_divider][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.25\" max_width=\"1440px\" use_custom_width=\"on\" custom_width_px=\"1440px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_blog fullwidth=\"off\" posts_number=\"3\" show_categories=\"off\" show_comments=\"on\" show_pagination=\"off\" masonry_tile_background_color=\"#ffffff\" _builder_version=\"3.0.105\" header_font=\"Roboto|||on|\" header_text_color=\"#000000\" header_font_size=\"20px\" header_line_height=\"1.4em\" body_font=\"Open Sans||||\" body_font_size=\"16px\" body_line_height=\"1.8em\" hover_enabled=\"0\" border_width_all=\"1px\" border_color_all=\"#efefef\" border_style_all=\"solid\" border_width_all_fullwidth=\"1px\" border_color_all_fullwidth=\"#efefef\" border_style_all_fullwidth=\"solid\" use_border_color=\"on\" border_color=\"#efefef\" sticky_enabled=\"0\"][/et_pb_blog][et_pb_button button_url=\"#\" button_text=\"Read More\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" locked=\"off\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Footer\" _builder_version=\"3.22\" background_color=\"#d3dae4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px|0px|0px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" column_structure=\"1_3,1_3,1_3\"][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"40px|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Visit Us</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\"][/et_pb_divider][et_pb_text _builder_version=\"4.8.0\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" hover_enabled=\"0\" sticky_enabled=\"0\"]<p>1235 Summit, Vibhuti Khand</p>\n<p>Gomti Nagar, Lucknow-226010</p>\n[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"40px|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Open Hours</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]M-F: 8am - 6pm\r\n\r\nS &amp; S: closed\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_47.png\" show_bottom_space=\"off\" align=\"center\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"4%\" animation=\"off\"][/et_pb_image][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2022-05-27 05:10:51', '2022-05-27 05:10:51', '', 12, 'http://upmsmemart.com/?p=23', 0, 'revision', '', 0),
(24, 1, '2022-05-27 07:41:46', '2022-05-27 07:41:46', '', 'Product_1', 'sdfds dfhdfhbd dfbdfgdfg dfvsdgsd', 'publish', 'open', 'closed', '', 'product_1', '', '', '2022-05-27 07:41:47', '2022-05-27 07:41:47', '', 0, 'http://upmsmemart.com/?post_type=product&#038;p=24', 0, 'product', '', 0),
(29, 1, '2022-05-27 06:16:17', '2022-05-27 06:16:17', '', 'LOGO_msme', '', 'inherit', 'open', 'closed', '', 'logo_msme', '', '', '2022-05-27 06:16:17', '2022-05-27 06:16:17', '', 0, 'http://upmsmemart.com/wp-content/uploads/2022/05/LOGO_msme.png', 0, 'attachment', 'image/png', 0),
(30, 1, '2022-05-27 06:16:25', '2022-05-27 06:16:25', '', 'Divi', '', 'publish', 'closed', 'closed', '', 'divi', '', '', '2022-05-27 06:16:25', '2022-05-27 06:16:25', '', 0, 'http://upmsmemart.com/?p=30', 0, 'custom_css', '', 0),
(31, 1, '2022-05-27 06:16:25', '2022-05-27 06:16:25', '', 'Divi', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2022-05-27 06:16:25', '2022-05-27 06:16:25', '', 30, 'http://upmsmemart.com/?p=31', 0, 'revision', '', 0),
(32, 1, '2022-05-27 07:43:29', '2022-05-27 07:43:29', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2022-05-27 07:43:29', '2022-05-27 07:43:29', '', 0, 'http://upmsmemart.com/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2022-05-27 07:43:29', '2022-05-27 07:43:29', ' ', '', '', 'publish', 'closed', 'closed', '', '33', '', '', '2022-05-27 07:43:29', '2022-05-27 07:43:29', '', 0, 'http://upmsmemart.com/?p=33', 4, 'nav_menu_item', '', 0),
(34, 1, '2022-05-27 07:43:29', '2022-05-27 07:43:29', ' ', '', '', 'publish', 'closed', 'closed', '', '34', '', '', '2022-05-27 07:43:29', '2022-05-27 07:43:29', '', 0, 'http://upmsmemart.com/?p=34', 3, 'nav_menu_item', '', 0),
(35, 1, '2022-05-27 07:43:29', '2022-05-27 07:43:29', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2022-05-27 07:43:29', '2022-05-27 07:43:29', '', 0, 'http://upmsmemart.com/?p=35', 5, 'nav_menu_item', '', 0),
(36, 1, '2022-05-27 07:43:29', '2022-05-27 07:43:29', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2022-05-27 07:43:29', '2022-05-27 07:43:29', '', 0, 'http://upmsmemart.com/?p=36', 2, 'nav_menu_item', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(38, 1, '2022-05-27 07:48:12', '2022-05-27 07:48:12', '[et_pb_section fb_built=\"1\" admin_label=\"Hero Section\" _builder_version=\"3.22\" background_color=\"#d3dae4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px|0px|110px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" max_width=\"1280px\" custom_padding=\"|||\" use_custom_width=\"on\" custom_width_px=\"1280px\" collapsed=\"off\" column_structure=\"1_2,1_2\"][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_48-1.jpg\" align=\"center\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"right\" animation_intensity_slide=\"4%\" animation=\"off\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"40px||40px|\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Subtitle\" _builder_version=\"3.27.4\" text_font=\"Roboto|on||on|\" text_text_color=\"#2a2a2a\" text_font_size=\"18px\" text_letter_spacing=\"4px\" animation_style=\"zoom\" animation_direction=\"left\" animation_intensity_zoom=\"10%\"]Summer Sale\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_font_size=\"52px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" custom_margin=\"||20px|\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"50ms\" animation_intensity_zoom=\"10%\" header_2_font_size_tablet=\"40px\" header_2_font_size_phone=\"\" header_2_font_size_last_edited=\"on|desktop\"]<h2>Vintage  Collection</h2>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" header_font=\"||||||||\" custom_margin=\"|||\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"100ms\" animation_intensity_zoom=\"10%\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor, sit amet tempor mauris eleifend a. In et bibendum eros c interdum sapien, et sagittis dui. Nunc fringilla mattis dolor\r[/et_pb_text][et_pb_text admin_label=\"Price\" _builder_version=\"3.27.4\" text_font=\"|700|||||||\" text_text_color=\"#2a2a2a\" text_font_size=\"30px\" custom_margin=\"||40px|\" custom_padding=\"|||\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"150ms\" animation_intensity_zoom=\"10%\"]20% OFF\r[/et_pb_text][et_pb_button button_url=\"#\" button_text=\"Shop Now\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"zoom\" animation_direction=\"left\" animation_delay=\"200ms\" animation_intensity_zoom=\"10%\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Features\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" collapsed=\"off\" column_structure=\"1_3,1_3,1_3\"][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\"]01\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Local Makers &amp; Artisans</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\" animation_delay=\"100ms\"]02\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Free Local SHipping</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Number\" _builder_version=\"3.27.4\" text_font=\"Roboto||||\" text_text_color=\"#2a2a2a\" text_font_size=\"60px\" custom_margin=\"|||\" custom_padding=\"||10px|\" animation_style=\"fade\" animation_delay=\"200ms\" locked=\"off\"]03\r[/et_pb_text][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h4>Money Back Guarantee</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor.\r[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Popular Product Section\" _builder_version=\"3.22\" custom_padding=\"110px|0px|110px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Popular Products Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Trending Products</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" animation_style=\"fade\" custom_css_main_element=\"||\" locked=\"off\"][/et_pb_divider][et_pb_shop posts_number=\"4\" columns_number=\"4\" orderby=\"menu_order\" icon_hover_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" _builder_version=\"3.25.3\" title_font=\"Roboto||||\" title_text_color=\"#000000\" price_font=\"|600|||||||\" price_text_color=\"#ffb500\" hover_enabled=\"0\" sticky_enabled=\"0\"][/et_pb_shop][et_pb_button button_url=\"#\" button_text=\"Browse All\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Featured Items\" _builder_version=\"3.22\" background_color=\"#f4f4f4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|desktop\" custom_padding=\"110px||110px|\" box_shadow_style=\"preset7\" box_shadow_horizontal=\"0px\" box_shadow_vertical=\"-400px\" box_shadow_color=\"#ffffff\" collapsed=\"off\"][et_pb_row use_custom_gutter=\"on\" gutter_width=\"2\" make_equal=\"on\" _builder_version=\"3.25\" custom_padding=\"27px|0px|0px|0px\" column_structure=\"1_2,1_2\"][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"12%|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"left\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h2>Featured Items</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" max_width_tablet=\"\" max_width_phone=\"\" max_width_last_edited=\"on|desktop\" custom_margin=\"||100px|\" animation_style=\"fade\"]Sed ac interdum sapien, et sagittis dui. Nunc fringilla mattis dolor, sit amet tempor mauris eleifend a. In et bibendum eros, eget arcu. Nulla nec elit sit amet arcu molestie volutpat volutpat vitae dui.\r[/et_pb_text][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49-1.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_49.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"||6%|\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_04.jpg\" url=\"#\" use_overlay=\"on\" overlay_icon_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" force_fullwidth=\"on\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"bottom\" animation_intensity_slide=\"2%\"][/et_pb_image][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Products\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" locked=\"off\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_margin=\"|||\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_line_height=\"1.2em\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>New Products</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.23.4\" height=\"50px\" animation_style=\"fade\" custom_css_main_element=\"margin: 0 auto;||width: 100px;||||\" locked=\"off\"][/et_pb_divider][et_pb_shop posts_number=\"6\" columns_number=\"3\" orderby=\"menu_order\" icon_hover_color=\"#ffb500\" hover_overlay_color=\"rgba(0,0,0,0.65)\" hover_icon=\"%%3%%\" _builder_version=\"3.25.3\" title_font=\"Roboto||||\" title_text_color=\"#000000\" price_font=\"|600|||||||\" price_text_color=\"#ffb500\"][/et_pb_shop][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Promo\" _builder_version=\"3.22\" background_color=\"rgba(12,12,12,0.6)\" background_image=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_46.jpg\" background_blend=\"color\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"160px||160px|\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"2%\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"|||\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||on||||||\" text_font_size=\"30px\" text_orientation=\"center\" background_layout=\"dark\" module_alignment=\"center\" custom_padding=\"||10px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"300ms\" animation_intensity_slide=\"8%\"]Only at <span style=\"color: #ffb500; font-size: 60px; font-style: normal;\"><strong>$19</strong></span>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"52px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" background_layout=\"dark\" module_alignment=\"center\" custom_margin=\"||10px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"200ms\" animation_intensity_slide=\"8%\" header_2_font_size_tablet=\"40px\" header_2_font_size_phone=\"\" header_2_font_size_last_edited=\"on|tablet\"]<h2>Flash Sale!</h2>\r[/et_pb_text][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"20px\" text_line_height=\"1.6em\" text_orientation=\"center\" background_layout=\"dark\" max_width=\"700px\" module_alignment=\"center\" custom_margin=\"|||\" custom_padding=\"||30px|\" animation_style=\"slide\" animation_direction=\"left\" animation_delay=\"100ms\" animation_intensity_slide=\"8%\"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam, felis in consectetur rutrum, lectus urna malesuada ligula.\r[/et_pb_text][et_pb_button button_url=\"#\" button_text=\"Shop This Sale\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_bg_color=\"#ffb500\" button_border_color=\"#ffb500\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"Roboto|on||on|\" button_use_icon=\"off\" background_layout=\"dark\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"20%\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffffff\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"rgba(255,181,0,0)\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffffff\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"rgba(255,181,0,0)\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Subscribe\" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"0px|||\" column_structure=\"1_4,1_2,1_4\"][et_pb_column type=\"1_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][/et_pb_column][et_pb_column type=\"1_2\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Stay up to date</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" height=\"2px\" custom_margin=\"|||\" custom_padding=\"|||\" animation_style=\"fade\" custom_css_main_element=\"||\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" text_orientation=\"center\" max_width_tablet=\"\" max_width_phone=\"\" max_width_last_edited=\"on|desktop\" custom_margin=\"|||\" animation_style=\"fade\" locked=\"off\"]Get notified about the newest products and upcoming sales\r[/et_pb_text][et_pb_signup mailchimp_list=\"SlavaET|03dac884f0\" name_field=\"on\" _builder_version=\"3.23\" use_background_color=\"off\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"Roboto|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" hover_enabled=\"0\" border_radii_fields=\"on|100px|100px|100px|100px\" border_width_all_fields=\"2px\" border_color_all_fields=\"rgba(0,0,0,0.12)\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"rgba(0,0,0,0)\" button_bg_color_hover=\"#ffb500\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"rgba(0,0,0,0)\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\" sticky_enabled=\"0\"][/et_pb_signup][/et_pb_column][et_pb_column type=\"1_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Testimonials\" _builder_version=\"3.22\" background_color=\"#f4f4f4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px||110px|\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"27px|0px|0px|0px\" locked=\"off\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Happy Customers</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"100px\" module_alignment=\"center\" animation_style=\"fade\" custom_css_main_element=\"||||\" locked=\"off\"][/et_pb_divider][/et_pb_column][/et_pb_row][et_pb_row use_custom_gutter=\"on\" gutter_width=\"2\" column_padding_mobile=\"on\" custom_padding_last_edited=\"on|tablet\" _builder_version=\"3.25\" background_size=\"initial\" background_position=\"top_left\" background_repeat=\"repeat\" custom_margin=\"0px|||\" custom_padding=\"0px|0px|27px|0px\" custom_padding_tablet=\"49px|||\" custom_padding_phone=\"29px|||\" custom_width_px=\"544px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_slider show_pagination=\"off\" admin_label=\"Testimonial\" _builder_version=\"3.16\" header_font=\"Roboto||||\" header_text_color=\"#ffffff\" header_font_size=\"36\" header_line_height=\"1.4em\" body_font=\"Roboto||||\" body_text_color=\"#ffffff\" body_font_size=\"20\" body_line_height=\"1.5em\" background_position=\"top_left\" custom_padding=\"80px|0px|100px|0px\" custom_padding_tablet=\"|||\" custom_padding_phone=\"|||\" auto=\"on\" top_padding=\"80px\" bottom_padding=\"100px\" remove_inner_shadow=\"on\" show_inner_shadow=\"off\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][et_pb_slide heading=\"%22Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam, felis in consectetur rutrum, lectus urna malesuada ligula, eget pulvinar dui leo at eros.%22\" use_bg_overlay=\"off\" use_text_overlay=\"off\" arrows_custom_color=\"#666666\" _builder_version=\"3.16\" header_font=\"||on||\" header_text_color=\"#666666\" header_font_size=\"22px\" header_line_height=\"1.8em\" body_font=\"Roboto|||on|\" body_text_color=\"#666666\" background_color=\"rgba(255,255,255,0)\" button_icon_placement=\"right\" button_on_hover=\"on\" custom_css_slide_title=\"margin-bottom:32px;||text-shadow: none;||||||\" custom_css_slide_description=\"text-shadow: none;\" sticky_transition=\"on\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"]<strong>Dan Virgillito</strong>\r\n<p style=\"margin-top: -15px;\">Interior Designer</p>\r[/et_pb_slide][et_pb_slide heading=\"“Mauris id fermentum neque. Donec fermentum sapien eget dolor fringilla pharetra. In cursus, arcu vitae dictum fringilla, sapien metus gravida augue.%22\" use_bg_overlay=\"off\" use_text_overlay=\"off\" arrows_custom_color=\"#666666\" _builder_version=\"3.16\" header_font=\"||on||\" header_text_color=\"#666666\" header_font_size=\"22px\" header_line_height=\"1.8em\" body_font=\"Roboto|||on|\" body_text_color=\"#666666\" background_color=\"rgba(255,255,255,0)\" button_icon_placement=\"right\" button_on_hover=\"on\" custom_css_slide_title=\"margin-bottom:32px;||text-shadow: none;||||||\" custom_css_slide_description=\"text-shadow: none;\" sticky_transition=\"on\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"off\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"off\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"off\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"off\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"off\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"]<strong>Dan Virgillito</strong>\r\n<p style=\"margin-top: -15px;\">Blogger</p>\r[/et_pb_slide][/et_pb_slider][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" disabled_on=\"on|on|on\" admin_label=\"Blog \" _builder_version=\"3.22\" custom_padding=\"110px||110px|\" collapsed=\"off\" disabled=\"on\"][et_pb_row _builder_version=\"3.25\" custom_padding=\"27px|0px|27px|0px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"Roboto|700||on|||||\" header_2_text_align=\"center\" header_2_font_size=\"30px\" header_2_letter_spacing=\"4px\" header_2_line_height=\"1.2em\" module_alignment=\"center\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\" locked=\"off\"]<h2>Our Blog</h2>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" animation_style=\"fade\" custom_css_main_element=\"margin: 0 auto;||width: 100px;||||\" locked=\"off\"][/et_pb_divider][/et_pb_column][/et_pb_row][et_pb_row _builder_version=\"3.25\" max_width=\"1440px\" use_custom_width=\"on\" custom_width_px=\"1440px\"][et_pb_column type=\"4_4\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_blog fullwidth=\"off\" posts_number=\"3\" show_categories=\"off\" show_comments=\"on\" show_pagination=\"off\" masonry_tile_background_color=\"#ffffff\" _builder_version=\"3.0.105\" header_font=\"Roboto|||on|\" header_text_color=\"#000000\" header_font_size=\"20px\" header_line_height=\"1.4em\" body_font=\"Open Sans||||\" body_font_size=\"16px\" body_line_height=\"1.8em\" hover_enabled=\"0\" border_width_all=\"1px\" border_color_all=\"#efefef\" border_style_all=\"solid\" border_width_all_fullwidth=\"1px\" border_color_all_fullwidth=\"#efefef\" border_style_all_fullwidth=\"solid\" use_border_color=\"on\" border_color=\"#efefef\" sticky_enabled=\"0\"][/et_pb_blog][et_pb_button button_url=\"#\" button_text=\"Read More\" button_alignment=\"center\" _builder_version=\"3.16\" custom_button=\"on\" button_text_size=\"18px\" button_text_color=\"#2a2a2a\" button_bg_color=\"rgba(0,0,0,0)\" button_border_color=\"#0000002a2a2a\" button_border_radius=\"30px\" button_letter_spacing=\"2px\" button_font=\"|700||on|||||\" button_use_icon=\"off\" animation_style=\"fade\" button_text_color_hover=\"#ffffff\" button_border_color_hover=\"#ffb500\" button_border_radius_hover=\"30px\" button_letter_spacing_hover=\"2px\" button_bg_color_hover=\"#ffb500\" locked=\"off\" button_text_size__hover_enabled=\"off\" button_one_text_size__hover_enabled=\"off\" button_two_text_size__hover_enabled=\"off\" button_text_color__hover_enabled=\"on\" button_text_color__hover=\"#ffffff\" button_one_text_color__hover_enabled=\"off\" button_two_text_color__hover_enabled=\"off\" button_border_width__hover_enabled=\"off\" button_one_border_width__hover_enabled=\"off\" button_two_border_width__hover_enabled=\"off\" button_border_color__hover_enabled=\"on\" button_border_color__hover=\"#ffb500\" button_one_border_color__hover_enabled=\"off\" button_two_border_color__hover_enabled=\"off\" button_border_radius__hover_enabled=\"on\" button_border_radius__hover=\"30px\" button_one_border_radius__hover_enabled=\"off\" button_two_border_radius__hover_enabled=\"off\" button_letter_spacing__hover_enabled=\"on\" button_letter_spacing__hover=\"2px\" button_one_letter_spacing__hover_enabled=\"off\" button_two_letter_spacing__hover_enabled=\"off\" button_bg_color__hover_enabled=\"on\" button_bg_color__hover=\"#ffb500\" button_one_bg_color__hover_enabled=\"off\" button_two_bg_color__hover_enabled=\"off\"][/et_pb_button][/et_pb_column][/et_pb_row][/et_pb_section][et_pb_section fb_built=\"1\" admin_label=\"Footer\" _builder_version=\"3.22\" background_color=\"#d3dae4\" custom_margin=\"60px|60px|60px|60px\" custom_margin_tablet=\"\" custom_margin_phone=\"0px|0px|0px|0px\" custom_margin_last_edited=\"on|phone\" custom_padding=\"110px|0px|0px|0px\" collapsed=\"off\"][et_pb_row _builder_version=\"3.25\" column_structure=\"1_3,1_3,1_3\"][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"40px|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Visit Us</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"on|on|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\"][/et_pb_divider][et_pb_text _builder_version=\"4.8.0\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" hover_enabled=\"0\" sticky_enabled=\"0\"]<p>1235 Summit, Vibhuti Khand</p>\n<p>Gomti Nagar, Lucknow-226010</p>\n[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"40px|||\" custom_padding__hover=\"|||\"][et_pb_text admin_label=\"Title\" _builder_version=\"3.27.4\" text_font=\"||||||||\" header_font=\"||||||||\" header_2_font=\"||||||||\" header_4_font=\"Roboto|700||on|||||\" header_4_letter_spacing=\"1px\" header_4_line_height=\"1.4em\" custom_margin=\"||10px|\" custom_padding=\"|||\" animation_style=\"fade\"]<h4>Open Hours</h4>\r[/et_pb_text][et_pb_divider color=\"#ffb500\" divider_weight=\"2px\" disabled_on=\"off|off|off\" _builder_version=\"3.2\" max_width=\"50px\" animation_style=\"fade\" locked=\"off\"][/et_pb_divider][et_pb_text _builder_version=\"3.27.4\" text_font=\"||||||||\" text_font_size=\"16px\" text_line_height=\"1.8em\" custom_margin=\"-30px|||\" animation_style=\"fade\" locked=\"off\"]M-F: 8am - 6pm\r\n\r\nS &amp; S: closed\r[/et_pb_text][/et_pb_column][et_pb_column type=\"1_3\" _builder_version=\"3.25\" custom_padding=\"|||\" custom_padding__hover=\"|||\"][et_pb_image src=\"http://upmsmemart.com/wp-content/uploads/2022/05/boutique_47.png\" show_bottom_space=\"off\" align=\"center\" align_tablet=\"center\" align_last_edited=\"on|desktop\" _builder_version=\"3.23\" custom_margin=\"|||\" animation_style=\"slide\" animation_direction=\"left\" animation_intensity_slide=\"4%\" animation=\"off\"][/et_pb_image][/et_pb_column][/et_pb_row][/et_pb_section]', 'About', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2022-05-27 07:48:12', '2022-05-27 07:48:12', '', 12, 'http://upmsmemart.com/?p=38', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 17, 'order', '0'),
(2, 17, 'product_count_product_cat', '1'),
(3, 18, 'product_count_product_tag', '1');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Uncategorized', 'uncategorized', 0),
(16, 'Divi', 'divi', 0),
(17, 'Metal', 'metal', 0),
(18, '#upgov', 'upgov', 0),
(19, 'Msme_Mart', 'msme_mart', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(13, 16, 0),
(24, 2, 0),
(24, 17, 0),
(24, 18, 0),
(32, 19, 0),
(33, 19, 0),
(34, 19, 0),
(35, 19, 0),
(36, 19, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 1),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'wp_theme', '', 0, 1),
(17, 17, 'product_cat', '', 0, 1),
(18, 18, 'product_tag', '', 0, 1),
(19, 19, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'msmemart'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"0783580f0a795836ac27b5d4539b6556d2e242a627bea00c1962b4ef92aaa8c4\";a:4:{s:10:\"expiration\";i:1653994750;s:2:\"ip\";s:38:\"2405:201:601d:4100:a165:ca99:6e85:b2b9\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36\";s:5:\"login\";i:1653821950;}}'),
(17, 1, 'wc_last_active', '1653782400'),
(19, 1, '_woocommerce_tracks_anon_id', 'woo:k8CpcrQWYgKlGzHT+v21BJmV'),
(20, 1, 'wp_dashboard_quick_press_last_post_id', '10'),
(21, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:1:{s:32:\"1ff1de774005f8da13f42943881c655f\";a:11:{s:3:\"key\";s:32:\"1ff1de774005f8da13f42943881c655f\";s:10:\"product_id\";i:24;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:10;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:10;s:8:\"line_tax\";i:0;}}}'),
(22, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:20:\"2405:201:600a:f0f5::\";}'),
(23, 1, 'wp_user-settings', 'libraryContent=browse'),
(24, 1, 'wp_user-settings-time', '1653631620'),
(25, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(26, 1, 'metaboxhidden_nav-menus', 'a:8:{i:0;s:21:\"add-post-type-project\";i:1;s:21:\"add-post-type-product\";i:2;s:12:\"add-post_tag\";i:3;s:15:\"add-post_format\";i:4;s:20:\"add-project_category\";i:5;s:15:\"add-project_tag\";i:6;s:15:\"add-product_cat\";i:7;s:15:\"add-product_tag\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'msmemart', '$P$BiIhZSYByFsfZtIof80yY5EJeY3Xlu0', 'msmemart', 'upmsmemart@gmail.com', 'http://upmsmemart.com', '2022-05-27 04:18:25', '', 0, 'msmemart');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_admin_notes`
--

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_admin_notes`
--

INSERT INTO `wp_wc_admin_notes` (`note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'wc-admin-navigation-nudge', 'info', 'en_US', 'You now have access to the WooCommerce navigation', 'We’re introducing a new navigation for a more intuitive and improved user experience. You can enable the beta version of the new experience in the Advanced Settings. Enable it now for your store.', '{}', 'unactioned', 'woocommerce-admin', '2022-05-27 04:41:57', NULL, 0, 'plain', '', 0, 0, 'info'),
(2, 'wc-admin-complete-store-details', 'info', 'en_US', 'Add your store details to complete store setup', 'Complete your store details with important information for setup such as your store’s base address', '{}', 'unactioned', 'woocommerce-admin', '2022-05-27 04:41:57', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'new_in_app_marketplace_2021', 'info', 'en_US', 'Customize your store with extensions', 'Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.', '{}', 'unactioned', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href=\"https://woocommerce.com/woocommerce-shipping/\">WooCommerce Shipping</a> – all directly from your mobile device!', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc_shipping_mobile_app_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href=\"https://woocommerce.com/woocommerce-shipping/\">WooCommerce Shipping</a> – all directly from your mobile device!', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'ecomm-need-help-setting-up-your-store', 'info', 'en_US', 'Need help setting up your Store?', 'Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store \"ready to sell\" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'ecomm-unique-shopping-experience', 'info', 'en_US', 'For a shopping experience as unique as your customers', 'Product Add-Ons allow your customers to personalize products while they\'re shopping on your online store. No more follow-up email requests—customers get what they want, before they\'re done checking out. Learn more about this extension that comes included in your plan.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'wc-admin-getting-started-in-ecommerce', 'info', 'en_US', 'Getting Started in eCommerce - webinar', 'We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'wc-admin-first-five-things-to-customize', 'info', 'en_US', 'The first 5 things to customize in your store', 'Deciding what to start with first is tricky. To help you properly prioritize, we’ve put together this short list of the first few things you should customize in WooCommerce.', '{}', 'unactioned', 'woocommerce.com', '2022-05-29 04:18:59', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">latest PayPal today</a> to continue to receive support and updates.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'ecomm-wc-navigation-survey', 'info', 'en_US', 'We’d like your feedback on the WooCommerce navigation', 'We’re making improvements to the WooCommerce navigation and would love your feedback. Share your experience in this 2 minute survey.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal Payments</a> to accept PayPal.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'setup_task_initiative_survey_q2_2022', 'survey', 'en_US', 'We want to know what matters most to you', 'Take 2 minutes to give us your input on what is important for you while setting up your store and help shape the future of WooCommerce together.', '{}', 'unactioned', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'affirm_q2_2022', 'marketing', 'en_US', 'Boost your business with flexible payments', 'Expand your customer base with smarter payment options for more shoppers. With Affirm,  you can offer the most relevant payment options at every price point – from four interest-free payments every two weeks to longer installments up to 36 months. Fast-track your revenue goals today!', '{}', 'unactioned', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'setup_task_second_survey_q2_2022', 'survey', 'en_US', 'We want to know what matters most to you', 'Take 2 minutes to give us your input on what is important for you while setting up your store and help shape the future of WooCommerce together.', '{}', 'pending', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '{}', 'unactioned', 'woocommerce.com', '2022-06-03 04:25:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'wc-admin-EU-consumer-protection', 'marketing', 'en_US', 'Important changes to EU consumer protection laws', 'New regulations to help modernize and strengthen consumer protection laws in the European Union (EU) take effect on May 28, 2022. These rules impact all merchants selling to the EU, regardless of where their business is located. Further detailed information is available on the European Commission\'s official website.', '{}', 'unactioned', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'wc_ipp_order_creation_GTM_launch_q2_2022', 'marketing', 'en_US', 'Grow your business on the go with WooCommerce In-Person Payments', 'Quickly create new orders, manage transactions, and take secure payments no matter where your business takes you. With automatic inventory sync, WooCommerce In-Person Payments is the only fully integrated solution for taking your WooCommerce store offline.', '{}', 'unactioned', 'woocommerce.com', '2022-05-27 04:41:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '{}', 'unactioned', 'woocommerce-core', '2022-05-27 04:41:59', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to WooCommerce.com', 'Connect to get important product notifications and updates.', '{}', 'unactioned', 'woocommerce-admin', '2022-05-27 04:41:59', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'surface_cart_checkout', 'info', 'en_US', 'Introducing the Cart and Checkout blocks!', 'Increase your store\'s revenue with the conversion optimized Cart &amp; Checkout WooCommerce blocks available in the WooCommerce Blocks extension.', '{}', 'unactioned', 'woo-gutenberg-products-block', '2022-05-27 04:41:59', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'om-wc-grow-revenue', 'info', 'en_US', 'Grow your store revenue with OptinMonster', 'Create high-converting OptinMonster campaigns to promote product sales, reduce cart abandonment and incentivize purchases with time-sensitive coupon offers.', '{}', 'unactioned', 'optinmonster', '2022-05-27 04:41:59', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'wc-admin-launch-checklist', 'info', 'en_US', 'Ready to launch your store?', 'To make sure you never get that sinking \"what did I forget\" feeling, we\'ve put together the essential pre-launch checklist.', '{}', 'unactioned', 'woocommerce-admin', '2022-05-28 04:19:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'wc-admin-choosing-a-theme', 'marketing', 'en_US', 'Choosing a theme?', 'Check out the themes that are compatible with WooCommerce and choose one aligned with your brand and business needs.', '{}', 'unactioned', 'woocommerce-admin', '2022-05-28 04:19:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'wc-admin-insight-first-product-and-payment', 'survey', 'en_US', 'Insight', 'More than 80% of new merchants add the first product and have at least one payment method set up during the first week.<br><br>Do you find this type of insight useful?', '{}', 'unactioned', 'woocommerce-admin', '2022-05-28 04:19:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'wc-admin-mobile-app', 'info', 'en_US', 'Install Woo mobile app', 'Install the WooCommerce mobile app to manage orders, receive sales notifications, and view key metrics — wherever you are.', '{}', 'unactioned', 'woocommerce-admin', '2022-05-29 04:18:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'wc-admin-customizing-product-catalog', 'info', 'en_US', 'How to customize your product catalog', 'You want your product catalog and images to look great and align with your brand. This guide will give you all the tips you need to get your products looking great in your store.', '{}', 'unactioned', 'woocommerce-admin', '2022-05-29 04:18:58', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'wc-admin-onboarding-payments-reminder', 'info', 'en_US', 'Start accepting payments on your store!', 'Take payments with the provider that’s right for you - choose from 100+ payment gateways for WooCommerce.', '{}', 'unactioned', 'woocommerce-admin', '2022-06-01 04:20:53', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'wc-admin-usage-tracking-opt-in', 'info', 'en_US', 'Help WooCommerce improve with usage tracking', 'Gathering usage data allows us to improve WooCommerce. Your store will be considered as we evaluate new features, judge the quality of an update, or determine if an improvement makes sense. You can always visit the <a href=\"http://upmsmemart.com/wp-admin/admin.php?page=wc-settings&#038;tab=advanced&#038;section=woocommerce_com\" target=\"_blank\">Settings</a> and choose to stop sharing data. <a href=\"https://woocommerce.com/usage-tracking?utm_medium=product\" target=\"_blank\">Read more</a> about what data we collect.', '{}', 'unactioned', 'woocommerce-admin', '2022-06-03 04:25:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'wc-admin-woocommerce-payments', 'marketing', 'en_US', 'Try the new way to get paid', 'Securely accept credit and debit cards on your site. Manage transactions without leaving your WordPress dashboard. Only with <strong>WooCommerce Payments</strong>.<br><br>By clicking \"Get started\", you agree to our <a href=\"https://wordpress.com/tos/\" target=\"_blank\">Terms of Service</a>', '{}', 'unactioned', 'woocommerce-admin', '2022-06-03 04:25:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'wc-admin-insight-first-sale', 'survey', 'en_US', 'Did you know?', 'A WooCommerce powered store needs on average 31 days to get the first sale. You\'re on the right track! Do you find this type of insight useful?', '{}', 'unactioned', 'woocommerce-admin', '2022-06-03 04:25:06', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'wc-admin-wisepad3', 'marketing', 'en_US', 'Take your business on the go in Canada with WooCommerce In-Person Payments', 'Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.', '{}', 'pending', 'woocommerce.com', '2022-06-15 10:02:42', NULL, 0, 'plain', '', 0, 0, 'info'),
(52, 'TikTok q2_2022', 'marketing', 'en_US', 'Give your store a stage on the world’s fastest-growing advertising channel', 'With TikTok for WooCommerce, you can sync your catalog, create videos, and track performance in front of TikTok’s one billion global users. Try the Smart Video Generator to make ads using your existing product images – no camera needed. Get $200 in ad credit from TikTok after a $20 spend (terms &amp; conditions apply).', '{}', 'unactioned', 'woocommerce.com', '2022-06-22 06:05:37', NULL, 0, 'plain', '', 0, 0, 'info');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_admin_note_actions`
--

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `note_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_admin_note_actions`
--

INSERT INTO `wp_wc_admin_note_actions` (`action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(1, 1, 'enable-navigation', 'Enable in Settings', 'http://upmsmemart.com/wp-admin/admin.php?page=wc-settings&tab=advanced&section=features', 'actioned', '', NULL, NULL),
(2, 2, 'add-store-details', 'Add store details', 'http://upmsmemart.com/wp-admin/admin.php?page=wc-admin&path=/setup-wizard', 'actioned', '', NULL, NULL),
(38, 34, 'setup_task_second_survey_q2_2022_share_your_input', 'Share your input', 'https://t.maze.co/87390007', 'actioned', '', NULL, NULL),
(42, 38, 'notify-refund-returns-page', 'Edit page', 'http://upmsmemart.com/wp-admin/post.php?post=9&action=edit', 'actioned', '', NULL, NULL),
(43, 39, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(44, 40, 'learn_more', 'Learn More', 'https://woocommerce.com/checkout-blocks/', 'actioned', '', NULL, NULL),
(45, 41, 'om-note-primary', 'Create a campaign', 'admin.php?page=optin-monster-templates', 'unactioned', '', NULL, NULL),
(46, 41, 'om-note-seconday', 'Learn more', 'admin.php?page=optin-monster-about&selectedTab=getting-started', 'unactioned', '', NULL, NULL),
(47, 42, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(48, 43, 'visit-the-theme-marketplace', 'Visit the theme marketplace', 'https://woocommerce.com/product-category/themes/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(49, 44, 'affirm-insight-first-product-and-payment', 'Yes', '', 'actioned', 'Thanks for your feedback', NULL, NULL),
(50, 44, 'affirm-insight-first-product-and-payment', 'No', '', 'actioned', 'Thanks for your feedback', NULL, NULL),
(85, 33, 'affirm_q2_2022', 'Get started for free', 'https://woocommerce.com/products/woocommerce-gateway-affirm/?utm_source=inbox_note&utm_medium=product&utm_campaign=affirm_q2_2022', 'unactioned', '', NULL, NULL),
(89, 45, 'learn-more', 'Learn more', 'https://woocommerce.com/mobile/?utm_medium=product', 'actioned', '', NULL, NULL),
(90, 46, 'day-after-first-product', 'Learn more', 'https://woocommerce.com/document/woocommerce-customizer/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(202, 47, 'view-payment-gateways', 'Learn more', 'https://woocommerce.com/product-category/woocommerce-extensions/payment-gateways/?utm_medium=product', 'actioned', '', NULL, NULL),
(277, 48, 'tracking-opt-in', 'Activate usage tracking', '', 'actioned', '', NULL, NULL),
(278, 49, 'learn-more', 'Learn more', 'https://woocommerce.com/payments/?utm_medium=product', 'unactioned', '', NULL, NULL),
(279, 49, 'get-started', 'Get started', 'http://upmsmemart.com/wp-admin/admin.php?page=wc-admin&action=setup-woocommerce-payments', 'actioned', '', 'setup-woocommerce-payments', ''),
(280, 50, 'affirm-insight-first-sale', 'Yes', '', 'actioned', 'Thanks for your feedback', NULL, NULL),
(281, 50, 'deny-insight-first-sale', 'No', '', 'actioned', 'Thanks for your feedback', NULL, NULL),
(466, 37, 'wc_ipp_order_creation_GTM_launch_q2_2022', 'Grow my business on the go', 'https://woocommerce.com/in-person-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_ipp_order_creation_GTM_launch_q2_2022', 'actioned', '', NULL, NULL),
(1355, 36, 'wc-admin-EU-consumer-protection', 'Learn more about these changes', 'https://ec.europa.eu/info/law/law-topic/consumer-protection-law/review-eu-consumer-law_en#guidance', 'actioned', '', NULL, NULL),
(1395, 3, 'browse_extensions', 'Browse extensions', 'http://upmsmemart.com/wp-admin/admin.php?page=wc-admin&page=wc-addons', 'unactioned', '', NULL, NULL),
(1396, 4, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(1397, 5, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(1398, 6, 'wc_shipping_mobile_app_q4_2021', 'Get the WooCommerce Mobile App', 'https://woocommerce.com/mobile/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_q4_2021', 'actioned', '', NULL, NULL),
(1399, 7, 'set-up-concierge', 'Schedule free session', 'https://wordpress.com/me/concierge', 'actioned', '', NULL, NULL),
(1400, 8, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(1401, 9, 'learn-more-ecomm-unique-shopping-experience', 'Learn more', 'https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox', 'actioned', '', NULL, NULL),
(1402, 10, 'watch-the-webinar', 'Watch the webinar', 'https://youtu.be/V_2XtCOyZ7o', 'actioned', '', NULL, NULL),
(1403, 11, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(1404, 12, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(1405, 13, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1406, 14, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(1407, 15, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(1408, 16, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(1409, 17, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://upmsmemart.com/wp-admin/admin.php?page=wc-admin&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(1410, 18, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(1411, 21, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(1412, 22, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(1413, 23, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1414, 23, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1415, 24, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1416, 24, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1417, 25, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1418, 25, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1419, 26, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(1420, 26, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1421, 27, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(1422, 28, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/feedback-on-woocommerce-navigation', 'actioned', '', NULL, NULL),
(1423, 29, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(1424, 29, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1425, 30, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(1426, 30, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(1427, 31, 'pinterest_03_2022_update', 'Update Instructions', 'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(1428, 32, 'setup_task_initiative_survey_q2_2022_share_your_input', 'Share your input', 'https://t.maze.co/87390007', 'actioned', '', NULL, NULL),
(1429, 35, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(1430, 51, 'wc-admin-wisepad3', 'Grow my business offline', 'https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3', 'actioned', '', NULL, NULL),
(1431, 52, 'TikTok q2_2022', 'Promote my products on TikTok', 'https://woocommerce.com/products/tiktok-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=TikTok%20q2_2022', 'unactioned', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_category_lookup`
--

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_category_lookup`
--

INSERT INTO `wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES
(15, 15),
(17, 17);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_customer_lookup`
--

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_download_log`
--

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_coupon_lookup`
--

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_product_lookup`
--

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variation_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_stats`
--

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_tax_lookup`
--

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT 0,
  `order_tax` double NOT NULL DEFAULT 0,
  `total_tax` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_attributes_lookup`
--

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_download_directories`
--

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_product_download_directories`
--

INSERT INTO `wp_wc_product_download_directories` (`url_id`, `url`, `enabled`) VALUES
(1, 'file:///home/u920553048/domains/upmsmemart.com/public_html/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://upmsmemart.com/wp-content/uploads/woocommerce_uploads/', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

INSERT INTO `wp_wc_product_meta_lookup` (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(24, '', 0, 0, '10.0000', '10.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_rate_limits`
--

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) UNSIGNED NOT NULL,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate_limit_expiry` bigint(20) UNSIGNED NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_reserved_stock`
--

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_tax_rate_classes`
--

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_tax_rate_classes`
--

INSERT INTO `wp_wc_tax_rate_classes` (`tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_webhooks`
--

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT 0,
  `pending_delivery` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_api_keys`
--

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_log`
--

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_sessions`
--

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpforms_tasks_meta`
--

CREATE TABLE `wp_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wpforms_tasks_meta`
--

INSERT INTO `wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES
(1, 'wpforms_process_forms_locator_scan', 'W10=', '2022-05-27 04:41:59'),
(2, 'wpforms_admin_addons_cache_update', 'W10=', '2022-05-27 04:41:59'),
(3, 'wpforms_admin_builder_templates_cache_update', 'W10=', '2022-05-27 04:41:59'),
(4, 'wpforms_admin_notifications_update', 'W10=', '2022-05-27 04:42:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`);

--
-- Indexes for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Indexes for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Indexes for table `wp_aioseo_cache`
--
ALTER TABLE `wp_aioseo_cache`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ndx_aioseo_cache_key` (`key`),
  ADD KEY `ndx_aioseo_cache_expiration` (`expiration`);

--
-- Indexes for table `wp_aioseo_notifications`
--
ALTER TABLE `wp_aioseo_notifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ndx_aioseo_notifications_slug` (`slug`),
  ADD KEY `ndx_aioseo_notifications_dates` (`start`,`end`),
  ADD KEY `ndx_aioseo_notifications_type` (`type`),
  ADD KEY `ndx_aioseo_notifications_dismissed` (`dismissed`);

--
-- Indexes for table `wp_aioseo_posts`
--
ALTER TABLE `wp_aioseo_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ndx_aioseo_posts_post_id` (`post_id`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_litespeed_url`
--
ALTER TABLE `wp_litespeed_url`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`(191)),
  ADD KEY `cache_tags` (`cache_tags`(191));

--
-- Indexes for table `wp_litespeed_url_file`
--
ALTER TABLE `wp_litespeed_url_file`
  ADD PRIMARY KEY (`id`),
  ADD KEY `filename` (`filename`),
  ADD KEY `type` (`type`),
  ADD KEY `url_id_2` (`url_id`,`vary`,`type`),
  ADD KEY `filename_2` (`filename`,`expired`),
  ADD KEY `url_id` (`url_id`,`expired`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wc_admin_notes`
--
ALTER TABLE `wp_wc_admin_notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `wp_wc_admin_note_actions`
--
ALTER TABLE `wp_wc_admin_note_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `note_id` (`note_id`);

--
-- Indexes for table `wp_wc_category_lookup`
--
ALTER TABLE `wp_wc_category_lookup`
  ADD PRIMARY KEY (`category_tree_id`,`category_id`);

--
-- Indexes for table `wp_wc_customer_lookup`
--
ALTER TABLE `wp_wc_customer_lookup`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `wp_wc_order_coupon_lookup`
--
ALTER TABLE `wp_wc_order_coupon_lookup`
  ADD PRIMARY KEY (`order_id`,`coupon_id`),
  ADD KEY `coupon_id` (`coupon_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_wc_order_product_lookup`
--
ALTER TABLE `wp_wc_order_product_lookup`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_wc_order_stats`
--
ALTER TABLE `wp_wc_order_stats`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `date_created` (`date_created`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `status` (`status`(191));

--
-- Indexes for table `wp_wc_order_tax_lookup`
--
ALTER TABLE `wp_wc_order_tax_lookup`
  ADD PRIMARY KEY (`order_id`,`tax_rate_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_wc_product_attributes_lookup`
--
ALTER TABLE `wp_wc_product_attributes_lookup`
  ADD PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  ADD KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`);

--
-- Indexes for table `wp_wc_product_download_directories`
--
ALTER TABLE `wp_wc_product_download_directories`
  ADD PRIMARY KEY (`url_id`),
  ADD KEY `url` (`url`(191));

--
-- Indexes for table `wp_wc_product_meta_lookup`
--
ALTER TABLE `wp_wc_product_meta_lookup`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `virtual` (`virtual`),
  ADD KEY `downloadable` (`downloadable`),
  ADD KEY `stock_status` (`stock_status`),
  ADD KEY `stock_quantity` (`stock_quantity`),
  ADD KEY `onsale` (`onsale`),
  ADD KEY `min_max_price` (`min_price`,`max_price`);

--
-- Indexes for table `wp_wc_rate_limits`
--
ALTER TABLE `wp_wc_rate_limits`
  ADD PRIMARY KEY (`rate_limit_id`),
  ADD UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191));

--
-- Indexes for table `wp_wc_reserved_stock`
--
ALTER TABLE `wp_wc_reserved_stock`
  ADD PRIMARY KEY (`order_id`,`product_id`);

--
-- Indexes for table `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  ADD PRIMARY KEY (`tax_rate_class_id`),
  ADD UNIQUE KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`);

--
-- Indexes for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `session_key` (`session_key`);

--
-- Indexes for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_wpforms_tasks_meta`
--
ALTER TABLE `wp_wpforms_tasks_meta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1672;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  MODIFY `claim_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12817;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  MODIFY `group_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4983;

--
-- AUTO_INCREMENT for table `wp_aioseo_cache`
--
ALTER TABLE `wp_aioseo_cache`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `wp_aioseo_notifications`
--
ALTER TABLE `wp_aioseo_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_aioseo_posts`
--
ALTER TABLE `wp_aioseo_posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_litespeed_url`
--
ALTER TABLE `wp_litespeed_url`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_litespeed_url_file`
--
ALTER TABLE `wp_litespeed_url_file`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20831;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_wc_admin_notes`
--
ALTER TABLE `wp_wc_admin_notes`
  MODIFY `note_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `wp_wc_admin_note_actions`
--
ALTER TABLE `wp_wc_admin_note_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1432;

--
-- AUTO_INCREMENT for table `wp_wc_customer_lookup`
--
ALTER TABLE `wp_wc_customer_lookup`
  MODIFY `customer_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_product_download_directories`
--
ALTER TABLE `wp_wc_product_download_directories`
  MODIFY `url_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_wc_rate_limits`
--
ALTER TABLE `wp_wc_rate_limits`
  MODIFY `rate_limit_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  MODIFY `tax_rate_class_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpforms_tasks_meta`
--
ALTER TABLE `wp_wpforms_tasks_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
