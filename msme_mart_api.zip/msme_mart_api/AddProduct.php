<?php include_once("include/session.php");?>
<?php include_once("include/db_connect.php");?>
<?php include_once("include/functions.php");?>
<?php $token = $_SESSION["token"]; ?>
<?php  
if($token=isset($_POST["token"])){

  $product_name        = test_input($_POST["product_name"]);
  $product_desc        = test_input($_POST["product_desc"]);
  $product_price       = test_input($_POST["product_price"]);
	$product_quantity    = test_input($_POST["product_quantity"]);
  $product_image       = test_input($_POST["product_image"]);
	
	define('UPLOAD_DIR', 'images/products/');

  $image_parts      = explode(";base64,", $product_image);
  $image_type_aux   = explode("image/", $image_parts[0]);
  $image_type       = $image_type_aux[0];
  $image_base64     = base64_decode($image_parts[0]);


  $image_name       =rand(00000000,99999999).'.'.'jpg';
  $s_pic            = UPLOAD_DIR . $image_name;
  file_put_contents($s_pic, $image_base64);
	
  $add    = add_product($con,$product_name,$product_desc,$product_price,$product_quantity,$image_name);

  if($add!=null){           
    $response =true;
    $message  ='Product added successfully';
    $data     =$product_name;
  } 
  else{ 
    $response =false;
    $message  ='Something went wrong';
    $data     =null;
  }

  $response= array('Response'=>$response,'Message'=>$message,'Data'=>$data);
  echo json_encode($response); 

 
}  
                  
?>